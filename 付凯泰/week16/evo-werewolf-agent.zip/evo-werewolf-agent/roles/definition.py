"""角色定义 — 描述每个角色类型的固有属性，不含运行时状态."""

from enum import Enum, auto
from dataclasses import dataclass


class RoleType(Enum):
    """角色类型枚举."""
    VILLAGER = auto()   # 平民
    WEREWOLF = auto()   # 狼人
    SEER = auto()       # 预言家
    WITCH = auto()      # 女巫
    HUNTER = auto()     # 猎人
    GUARD = auto()      # 守卫


class Team(Enum):
    """阵营枚举."""
    WEREWOLF = "werewolf"   # 狼人阵营
    VILLAGER = "villager"   # 好人阵营


class Trait(Enum):
    """决策特质枚举."""
    CAUTIOUS = "cautious"   # 谨慎 — 保守决策，跟风，不易被怀疑
    RANDOM = "random"       # 随机 — 不可预测
    BOLD = "bold"           # 大胆 — 激进决策，强势站边，主动出击

    @property
    def cn(self) -> str:
        return {"cautious": "谨慎", "random": "随机", "bold": "大胆"}[self.value]


@dataclass(frozen=True)
class Role:
    """角色定义 — 描述一个角色类型的固有属性，不含运行时状态."""

    role_type: RoleType          # 角色类型
    team: Team                   # 所属阵营
    name_cn: str                 # 中文名称
    has_night_action: bool       # 是否有夜间行动
    night_priority: int          # 夜间行动优先级，值越小越先行动
    can_kill: bool               # 能否在夜间杀人
    max_night_targets: int       # 每夜最多选择目标数，0 表示不选人
    description: str             # 角色描述
    win_condition: str = ""      # 获胜条件描述
    can_act_after_death: bool = False   # 出局后是否还能行动（猎人开枪）
    immune_to_kill_at_night: bool = False  # 是否免疫夜间被刀


ROLES: dict[RoleType, Role] = {
    RoleType.VILLAGER: Role(
        role_type=RoleType.VILLAGER, team=Team.VILLAGER, name_cn="平民",
        has_night_action=False, night_priority=99, can_kill=False,
        max_night_targets=0,
        description="普通村民，没有特殊能力，依靠白天投票找出狼人。",
        win_condition="所有狼人出局。",
    ),
    RoleType.WEREWOLF: Role(
        role_type=RoleType.WEREWOLF, team=Team.WEREWOLF, name_cn="狼人",
        has_night_action=True, night_priority=1, can_kill=True,
        max_night_targets=1,
        description="夜晚可与同伴商议杀死一名玩家，白天隐藏身份伪装好人。",
        win_condition="狼人人数 ≥ 存活好人人数。",
    ),
    RoleType.SEER: Role(
        role_type=RoleType.SEER, team=Team.VILLAGER, name_cn="预言家",
        has_night_action=True, night_priority=2, can_kill=False,
        max_night_targets=1,
        description="每夜可查验一名玩家的真实身份。",
        win_condition="所有狼人出局。",
    ),
    RoleType.WITCH: Role(
        role_type=RoleType.WITCH, team=Team.VILLAGER, name_cn="女巫",
        has_night_action=True, night_priority=3, can_kill=False,
        max_night_targets=2,
        description="拥有一瓶解药和一瓶毒药。解药可救被狼人杀的玩家，毒药可毒杀任意玩家。每局每瓶药只能用一次。",
        win_condition="所有狼人出局。",
    ),
    RoleType.HUNTER: Role(
        role_type=RoleType.HUNTER, team=Team.VILLAGER, name_cn="猎人",
        has_night_action=False, night_priority=98, can_kill=False,
        max_night_targets=0,
        description="被放逐或夜间被刀出局时可以开枪带走一名玩家。若被女巫毒杀则不能开枪。",
        win_condition="所有狼人出局。", can_act_after_death=True,
    ),
    RoleType.GUARD: Role(
        role_type=RoleType.GUARD, team=Team.VILLAGER, name_cn="守卫",
        has_night_action=True, night_priority=2, can_kill=False,
        max_night_targets=1,
        description="每夜可守护一名玩家，使其免疫当晚狼人刀杀。不能连续两晚守护同一人。",
        win_condition="所有狼人出局。",
    ),
}


def get_role(role_type: RoleType) -> Role:
    """根据角色类型获取角色定义."""
    return ROLES[role_type]


def get_team_roles(team: Team) -> list[Role]:
    """获取指定阵营的所有角色定义."""
    return [r for r in ROLES.values() if r.team == team]


def get_night_actors(priority_max: int = 100) -> list[Role]:
    """获取夜间有行动的角色列表，按优先级排序。"""
    return sorted(
        [r for r in ROLES.values() if r.has_night_action],
        key=lambda r: r.night_priority,
    )
