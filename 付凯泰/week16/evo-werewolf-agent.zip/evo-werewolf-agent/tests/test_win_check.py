"""胜负判定测试 — 验证 engine/win_check.py 的各类胜负场景."""

from roles.definition import RoleType, Team
from engine.state import Player
from engine.win_check import check_win, is_werewolf_victory, is_good_victory


def make_player(player_id: int, role_type: RoleType) -> Player:
    return Player(player_id=player_id, name=f"P{player_id}", role_type=role_type)


# ── 好人胜利场景 ──────────────────────────────────────────

class TestGoodVictory:

    def test_all_wolves_eliminated_simple(self):
        """1狼人出局，剩余均为好人."""
        alive = [
            make_player(1, RoleType.VILLAGER),
            make_player(2, RoleType.VILLAGER),
            make_player(3, RoleType.SEER),
        ]
        over, winner = check_win(alive)
        assert over is True
        assert winner == Team.VILLAGER

    def test_all_wolves_eliminated_mixed_good(self):
        """狼人全灭，剩余各种好人角色."""
        alive = [
            make_player(1, RoleType.VILLAGER),
            make_player(2, RoleType.SEER),
            make_player(3, RoleType.WITCH),
            make_player(4, RoleType.HUNTER),
            make_player(5, RoleType.GUARD),
        ]
        assert is_good_victory(alive) is True
        assert is_werewolf_victory(alive) is False

    def test_no_players_left(self):
        """无存活玩家（极端情况）."""
        over, winner = check_win([])
        assert over is True
        assert winner == Team.VILLAGER


# ── 狼人胜利场景 ──────────────────────────────────────────

class TestWerewolfVictory:

    def test_wolves_equal_good(self):
        """狼人数量 = 好人数量."""
        alive = [
            make_player(1, RoleType.WEREWOLF),
            make_player(2, RoleType.WEREWOLF),
            make_player(3, RoleType.VILLAGER),
            make_player(4, RoleType.VILLAGER),
        ]
        over, winner = check_win(alive)
        assert over is True
        assert winner == Team.WEREWOLF

    def test_wolves_outnumber_good(self):
        """狼人数量 > 好人数量."""
        alive = [
            make_player(1, RoleType.WEREWOLF),
            make_player(2, RoleType.WEREWOLF),
            make_player(3, RoleType.WEREWOLF),
            make_player(4, RoleType.VILLAGER),
        ]
        assert is_werewolf_victory(alive) is True
        assert is_good_victory(alive) is False

    def test_only_wolves_left(self):
        """只剩狼人."""
        alive = [
            make_player(1, RoleType.WEREWOLF),
            make_player(2, RoleType.WEREWOLF),
        ]
        over, winner = check_win(alive)
        assert over is True
        assert winner == Team.WEREWOLF

    def test_single_wolf_vs_one_villager(self):
        """1狼人 vs 1好人."""
        alive = [
            make_player(1, RoleType.WEREWOLF),
            make_player(2, RoleType.VILLAGER),
        ]
        assert is_werewolf_victory(alive) is True


# ── 游戏进行中场景 ────────────────────────────────────────

class TestGameInProgress:

    def test_wolves_alive_good_majority(self):
        """有狼人存活但好人占多数."""
        alive = [
            make_player(1, RoleType.WEREWOLF),
            make_player(2, RoleType.WEREWOLF),
            make_player(3, RoleType.VILLAGER),
            make_player(4, RoleType.VILLAGER),
            make_player(5, RoleType.SEER),
            make_player(6, RoleType.WITCH),
        ]
        over, winner = check_win(alive)
        assert over is False
        assert winner is None

    def test_one_wolf_vs_many_good(self):
        """单狼人存活，好人远多于狼人."""
        alive = [
            make_player(1, RoleType.WEREWOLF),
            make_player(2, RoleType.VILLAGER),
            make_player(3, RoleType.VILLAGER),
            make_player(4, RoleType.SEER),
            make_player(5, RoleType.HUNTER),
        ]
        assert is_werewolf_victory(alive) is False
        assert is_good_victory(alive) is False

    def test_typical_mid_game(self):
        """经典中局：2狼 vs 4好人."""
        alive = [
            make_player(1, RoleType.WEREWOLF),
            make_player(2, RoleType.WEREWOLF),
            make_player(3, RoleType.VILLAGER),
            make_player(4, RoleType.VILLAGER),
            make_player(5, RoleType.SEER),
            make_player(6, RoleType.WITCH),
        ]
        over, winner = check_win(alive)
        assert over is False
        assert winner is None


# ── 边界场景 ──────────────────────────────────────────────

class TestEdgeCases:

    def test_check_win_returns_tuple(self):
        """check_win 返回值格式正确."""
        alive = [make_player(1, RoleType.WEREWOLF), make_player(2, RoleType.VILLAGER)]
        result = check_win(alive)
        assert isinstance(result, tuple)
        assert len(result) == 2
        assert isinstance(result[0], bool)
        assert result[1] in (Team.WEREWOLF, Team.VILLAGER, None)

    def test_type_consistency(self):
        """不同 helper 函数与 check_win 一致."""
        alive = [make_player(1, RoleType.WEREWOLF), make_player(2, RoleType.VILLAGER)]
        over, winner = check_win(alive)
        assert is_werewolf_victory(alive) == (over and winner == Team.WEREWOLF)
        assert is_good_victory(alive) == (over and winner == Team.VILLAGER)

    def test_elimination_sequence(self):
        """模拟逐步淘汰的过程."""
        alive = [
            make_player(1, RoleType.WEREWOLF),
            make_player(2, RoleType.HUNTER),
            make_player(3, RoleType.GUARD),
            make_player(4, RoleType.WITCH),
        ]
        # 1狼 vs 3好 → 继续
        assert check_win(alive) == (False, None)

        # 刀死一个好人 → 1狼 vs 2好 → 继续
        alive[1].is_alive = False
        remaining = [p for p in alive if p.is_alive]
        assert check_win(remaining) == (False, None)

        # 再刀一个好人 → 1狼 vs 1好 → 狼人胜
        alive[2].is_alive = False
        remaining = [p for p in alive if p.is_alive]
        assert check_win(remaining) == (True, Team.WEREWOLF)
