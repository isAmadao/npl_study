"""PlayerAgent 单元测试 — 角色身份、特质、系统提示词和决策能力."""

from __future__ import annotations

import pytest

from agents.player_agent import PlayerAgent
from roles.definition import RoleType, Team, Trait, get_role


class TestPlayerAgentInit:
    """PlayerAgent 初始化与属性."""

    def test_create_with_minimal_args(self):
        agent = PlayerAgent(name="玩家1", role_type=RoleType.VILLAGER)
        assert agent.name == "玩家1"
        assert agent.role_type == RoleType.VILLAGER
        assert agent.trait == Trait.RANDOM  # 默认特质
        assert agent.is_alive is True

    def test_create_with_all_args(self):
        agent = PlayerAgent(
            name="测试狼",
            role_type=RoleType.WEREWOLF,
            trait=Trait.BOLD,
        )
        assert agent.name == "测试狼"
        assert agent.role_type == RoleType.WEREWOLF
        assert agent.trait == Trait.BOLD

    def test_role_and_team_derived_from_role_type(self):
        agent = PlayerAgent(name="S", role_type=RoleType.SEER)
        assert agent.role == get_role(RoleType.SEER)
        assert agent.team == Team.VILLAGER

    def test_wolf_team(self):
        agent = PlayerAgent(name="W", role_type=RoleType.WEREWOLF)
        assert agent.team == Team.WEREWOLF

    def test_default_brain_created(self):
        agent = PlayerAgent(name="P", role_type=RoleType.VILLAGER)
        assert agent.brain is not None
        assert agent.brain.name == "P"
        assert agent.brain.trait == Trait.RANDOM

    def test_custom_brain(self):
        from engine.agent_adapter import FallbackAgent
        custom = FallbackAgent(name="自定义", trait=Trait.CAUTIOUS)
        agent = PlayerAgent(
            name="裹脑", role_type=RoleType.WITCH,
            trait=Trait.BOLD, brain=custom,
        )
        assert agent.brain is custom  # 外部传入，不重新创建


class TestPlayerAgentSystemPrompt:
    """系统提示词内容验证."""

    def _prompt_of(self, role_type: RoleType, trait: Trait = Trait.RANDOM) -> str:
        return PlayerAgent(name="X", role_type=role_type, trait=trait)._build_system_prompt()

    def test_contains_player_name(self):
        prompt = PlayerAgent(name="小A", role_type=RoleType.VILLAGER)._build_system_prompt()
        assert "小A" in prompt

    def test_contains_role_name(self):
        prompt = self._prompt_of(RoleType.SEER)
        assert "预言家" in prompt

    def test_contains_team_cn_good(self):
        prompt = self._prompt_of(RoleType.VILLAGER)
        assert "好人阵营" in prompt
        assert "狼人阵营" not in prompt

    def test_contains_team_cn_wolf(self):
        prompt = self._prompt_of(RoleType.WEREWOLF)
        assert "狼人阵营" in prompt

    def test_contains_trait_description(self):
        prompt = self._prompt_of(RoleType.GUARD, Trait.CAUTIOUS)
        assert "谨慎保守" in prompt

        prompt2 = self._prompt_of(RoleType.GUARD, Trait.BOLD)
        assert "大胆激进" in prompt2

        prompt3 = self._prompt_of(RoleType.GUARD, Trait.RANDOM)
        assert "不可预测" in prompt3

    def test_contains_win_condition(self):
        prompt = self._prompt_of(RoleType.WEREWOLF)
        assert "获胜条件" in prompt

    def test_contains_role_description(self):
        prompt = self._prompt_of(RoleType.WITCH)
        assert "女巫" in prompt or "解药" in prompt or "毒药" in prompt

    def test_each_role_type_has_unique_prompt(self):
        prompts = {}
        for rt in RoleType:
            prompts[rt] = self._prompt_of(rt)
        # 每种角色至少有一个独有的身份关键词
        for rt, prompt in prompts.items():
            assert get_role(rt).name_cn in prompt


class TestPlayerAgentRun:
    """run() 方法测试 — 使用 FallbackAgent 的 mock 能力."""

    @pytest.mark.asyncio
    async def test_run_returns_str(self):
        agent = PlayerAgent(name="小白", role_type=RoleType.VILLAGER)
        result = await agent.run("请发言")
        assert isinstance(result, str)
        assert len(result) > 0

    @pytest.mark.asyncio
    async def test_run_with_vote_prompt(self):
        agent = PlayerAgent(name="选民", role_type=RoleType.VILLAGER)
        result = await agent.run("请投票选择要放逐的玩家，可选目标：1. 玩家A 2. 玩家B")
        # mock 模式下应当返回一个数字
        assert any(c.isdigit() for c in result)

    @pytest.mark.asyncio
    async def test_run_with_target_prompt(self):
        agent = PlayerAgent(name="狼人", role_type=RoleType.WEREWOLF, trait=Trait.BOLD)
        result = await agent.run("请选择今晚要杀的目标，可选：1. A 2. B")
        assert any(c.isdigit() for c in result)

    @pytest.mark.asyncio
    async def test_run_cautious_consistency(self):
        """CAUTIOUS 特质选第一个目标."""
        agent = PlayerAgent(name="保守派", role_type=RoleType.GUARD, trait=Trait.CAUTIOUS)
        result = await agent.run("可选目标：1. 张三 2. 李四 3. 王五")
        # cautious 选第一个出现的数字
        assert "1" in result

    @pytest.mark.asyncio
    async def test_run_bold_consistency(self):
        """BOLD 特质选目标."""
        agent = PlayerAgent(name="激进派", role_type=RoleType.GUARD, trait=Trait.BOLD)
        result = await agent.run("可选目标：1. 张三 2. 李四 3. 王五")
        # bold 倾向选最后一个
        assert any(c.isdigit() for c in result)

    @pytest.mark.asyncio
    async def test_multiple_calls_maintain_history(self):
        """多次调用应当累积对话历史."""
        agent = PlayerAgent(name="话痨", role_type=RoleType.VILLAGER)
        r1 = await agent.run("请说话")
        r2 = await agent.run("再说一句")
        # FallbackAgent 内部维护 _messages 列表，
        # 第二次调用时 system + user(r1) + assistant(r1回复) + user(r2) 应在 brain 中
        assert len(agent.brain._messages) == 4  # system + user1 + asst1 + user2


class TestPlayerAgentEdgeCases:
    """边界情况."""

    def test_name_empty_string(self):
        # 空名字应被允许（尽管不合理）
        agent = PlayerAgent(name="", role_type=RoleType.VILLAGER)
        assert agent.name == ""

    def test_alive_state_toggle(self):
        agent = PlayerAgent(name="死者", role_type=RoleType.VILLAGER)
        assert agent.is_alive is True
        agent.is_alive = False
        assert agent.is_alive is False

    def test_all_role_types_constructable(self):
        for rt in RoleType:
            agent = PlayerAgent(name=f"测试{rt.value}", role_type=rt)
            assert agent.role_type == rt
            assert agent.role.name_cn is not None

    def test_all_traits_constructable(self):
        for trait in Trait:
            agent = PlayerAgent(name="全特质", role_type=RoleType.VILLAGER, trait=trait)
            assert agent.trait == trait
