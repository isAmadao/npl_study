"""Schema 测试 — Pydantic 对局记录模型、配置加载."""

from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime

from schema.record import DialogueRecord, GameRecord
from schema.system_config import load_system_config


# ========================================================================
# DialogueRecord — 单条对局记录
# ========================================================================

class TestDialogueRecord:

    def test_minimal_host_entry(self):
        r = DialogueRecord(seq=0, type="host", message="游戏开始")
        assert r.seq == 0
        assert r.type == "host"
        assert r.message == "游戏开始"
        # 应该有默认值
        assert r.day == 0
        assert r.phase == ""
        assert r.speaker == ""
        assert r.event_type == ""

    def test_host_entry_full(self):
        r = DialogueRecord(
            seq=1, type="host", day=1, phase="night",
            speaker="主持人", message="天黑请闭眼",
        )
        assert r.model_dump()["type"] == "host"
        assert r.model_dump()["day"] == 1

    def test_decision_entry(self):
        r = DialogueRecord(
            seq=2, type="decision", day=1, phase="night",
            speaker="玩家1", role="狼人", trait="bold",
            action="kill", prompt="请选择目标", response="3",
            target="3",
        )
        assert r.type == "decision"
        assert r.speaker == "玩家1"
        assert r.role == "狼人"
        assert r.trait == "bold"

    def test_event_entry(self):
        r = DialogueRecord(
            seq=3, type="event", event_type="eliminated",
            message="玩家2 被放逐",
        )
        assert r.type == "event"
        assert r.event_type == "eliminated"

    def test_default_values(self):
        r = DialogueRecord(seq=0, type="host", message="")
        assert r.day == 0
        assert r.phase == ""
        assert r.speaker == ""
        assert r.role == ""
        assert r.trait == ""
        assert r.action == ""
        assert r.prompt == ""
        assert r.response == ""
        assert r.target is None
        assert r.event_type == ""

    def test_extra_fields_allowed(self):
        """extra='allow' 配置应接受未声明的字段."""
        r = DialogueRecord(seq=0, type="event", message="x", extra_field="hello")
        assert r.extra_field == "hello"

    def test_extra_fields_in_dump(self):
        r = DialogueRecord(seq=0, type="event", message="x", some_meta=42)
        d = r.model_dump()
        assert d["some_meta"] == 42

    def test_host_type_has_speaker_default(self):
        r = DialogueRecord(seq=0, type="host", message="msg")
        # speaker 默认为空，不强制
        assert hasattr(r, "speaker")

    def test_seq_is_required(self):
        import pydantic
        try:
            DialogueRecord(type="host", message="no seq")
            assert False, "应因缺少 seq 校验失败"
        except pydantic.ValidationError:
            pass

    def test_type_is_required(self):
        import pydantic
        try:
            DialogueRecord(seq=0, message="no type")
            assert False, "应因缺少 type 校验失败"
        except pydantic.ValidationError:
            pass

    def test_model_dump_roundtrip(self):
        r = DialogueRecord(
            seq=5, type="decision", day=2, phase="discussion",
            speaker="玩家A", role="预言家", trait="cautious",
            action="speak", prompt="请发言", response="我怀疑3号",
        )
        d = r.model_dump()
        assert d["seq"] == 5
        assert d["speaker"] == "玩家A"
        assert d["response"] == "我怀疑3号"

    def test_model_dump_json_contains_fields(self):
        r = DialogueRecord(seq=0, type="host", message="测试")
        j = r.model_dump_json()
        assert '"seq": 0' in j
        assert '"type": "host"' in j
        assert '"message": "测试"' in j

    def test_all_decision_fields(self):
        """确保 decision 类型的全部字段可通过构造函数设置."""
        r = DialogueRecord(
            seq=10, type="decision", day=3, phase="vote",
            speaker="玩家W", role="狼人", trait="bold",
            action="vote", prompt="投谁？", response="投2号",
            target="2",
        )
        assert r.prompt == "投谁？"
        assert r.response == "投2号"
        assert r.target == "2"

    def test_negative_seq(self):
        """seq 可以是非负整数（Pydantic 无特殊约束）. """
        r = DialogueRecord(seq=-1, type="host", message="异常")
        assert r.seq == -1


# ========================================================================
# GameRecord — 整局游戏记录
# ========================================================================

class TestGameRecord:

    def test_minimal(self):
        r = GameRecord(game_id="test_001", started_at=datetime(2026, 1, 1), entries=[])
        assert r.game_id == "test_001"
        assert r.started_at == datetime(2026, 1, 1)
        assert r.entries == []

    def test_with_entries(self):
        entries = [
            DialogueRecord(seq=0, type="host", message="开始"),
            DialogueRecord(seq=1, type="decision", speaker="P1", role="平民",
                           trait="random", action="speak", day=1, phase="discussion"),
        ]
        r = GameRecord(game_id="g1", started_at=datetime.now(), entries=entries)
        assert len(r.entries) == 2
        assert r.entries[0].message == "开始"
        assert r.entries[1].speaker == "P1"

    def test_model_dump(self):
        r = GameRecord(
            game_id="dump_test",
            started_at=datetime(2026, 5, 28, 12, 0, 0),
            entries=[],
        )
        d = r.model_dump()
        assert d["game_id"] == "dump_test"
        assert d["started_at"] == "2026-05-28T12:00:00"  # datetime → str
        assert d["entries"] == []

    def test_model_dump_json(self):
        r = GameRecord(game_id="json_test", started_at=datetime(2026, 5, 29), entries=[])
        j = r.model_dump_json()
        assert '"game_id": "json_test"' in j
        assert '"entries": []' in j

    def test_model_dump_json_with_nested_entries(self):
        entries = [
            DialogueRecord(seq=0, type="host", message="游戏开始"),
            DialogueRecord(seq=1, type="decision", speaker="P1", role="狼人",
                           trait="bold", action="kill", day=1, phase="night",
                           prompt="选目标", response="3", target="3"),
        ]
        r = GameRecord(game_id="nested", started_at=datetime.now(), entries=entries)
        j = r.model_dump_json(ensure_ascii=False, indent=2)
        assert "游戏开始" in j
        assert "狼人" in j
        assert "bold" in j

    def test_json_serialize_deserialize_roundtrip(self):
        """转为 JSON 后反序列化回 Python 对象."""
        original = GameRecord(
            game_id="rt",
            started_at=datetime(2026, 5, 28),
            entries=[
                DialogueRecord(seq=0, type="host", message="嗨"),
                DialogueRecord(seq=1, type="event", event_type="game_over", message="结束"),
            ],
        )
        json_str = original.model_dump_json()
        loaded = GameRecord.model_validate_json(json_str)
        assert loaded.game_id == "rt"
        assert len(loaded.entries) == 2
        assert loaded.entries[0].type == "host"
        assert loaded.entries[1].event_type == "game_over"

    def test_started_at_iso_in_json(self):
        r = GameRecord(game_id="iso", started_at=datetime(2026, 6, 1, 8, 30, 0), entries=[])
        j = r.model_dump_json()
        assert "2026-06-01T08:30:00" in j

    def test_entries_validation(self):
        """entries 接受空列表和非空列表."""
        r1 = GameRecord(game_id="a", started_at=datetime.now(), entries=[])
        assert r1.entries == []
        r2 = GameRecord(game_id="b", started_at=datetime.now(), entries=[
            DialogueRecord(seq=0, type="host", message="x"),
        ])
        assert len(r2.entries) == 1


# ========================================================================
# load_system_config — JSON 配置文件加载
# ========================================================================

class TestLoadSystemConfig:

    def test_load_real_config(self):
        """读取项目中真实的 config/system_config.json."""
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "config", "system_config.json",
        )
        cfg = load_system_config(config_path)
        assert isinstance(cfg, dict)
        assert "base_url" in cfg
        assert "default_model" in cfg
        assert cfg["default_model"] == "qwen-flash"

    def test_load_with_temp_file(self):
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", encoding="utf-8", delete=False,
        ) as f:
            json.dump({"key": "value", "num": 42}, f)
            tmp_path = f.name
        try:
            cfg = load_system_config(tmp_path)
            assert cfg == {"key": "value", "num": 42}
        finally:
            os.unlink(tmp_path)

    def test_load_empty_object(self):
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", encoding="utf-8", delete=False,
        ) as f:
            f.write("{}")
            tmp_path = f.name
        try:
            cfg = load_system_config(tmp_path)
            assert cfg == {}
        finally:
            os.unlink(tmp_path)

    def test_file_not_found(self):
        import pytest
        with pytest.raises(FileNotFoundError):
            load_system_config("/nonexistent/path/config.json")

    def test_invalid_json(self):
        import pytest
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", encoding="utf-8", delete=False,
        ) as f:
            f.write("{invalid json}")
            tmp_path = f.name
        try:
            with pytest.raises(json.JSONDecodeError):
                load_system_config(tmp_path)
        finally:
            os.unlink(tmp_path)
