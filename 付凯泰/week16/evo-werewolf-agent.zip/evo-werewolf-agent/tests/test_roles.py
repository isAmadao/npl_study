"""角色定义测试 — 验证 roles/definition.py 中每个角色的属性正确性."""

import pytest

from roles.definition import (
    ROLES,
    RoleType,
    Team,
    get_role,
    get_team_roles,
    get_night_actors,
)


class TestRoleType:
    """验证所有角色类型都被定义."""

    def test_all_roles_defined(self):
        assert len(ROLES) == 6
        for rt in RoleType:
            assert rt in ROLES, f"缺少角色 {rt}"

    def test_role_names(self):
        assert ROLES[RoleType.VILLAGER].name_cn == "平民"
        assert ROLES[RoleType.WEREWOLF].name_cn == "狼人"
        assert ROLES[RoleType.SEER].name_cn == "预言家"
        assert ROLES[RoleType.WITCH].name_cn == "女巫"
        assert ROLES[RoleType.HUNTER].name_cn == "猎人"
        assert ROLES[RoleType.GUARD].name_cn == "守卫"


class TestTeamAssignment:
    """验证阵营归属."""

    def test_werewolf_team(self):
        assert ROLES[RoleType.WEREWOLF].team == Team.WEREWOLF

    def test_villager_team_roles(self):
        good_roles = [RoleType.VILLAGER, RoleType.SEER, RoleType.WITCH,
                       RoleType.HUNTER, RoleType.GUARD]
        for rt in good_roles:
            assert ROLES[rt].team == Team.VILLAGER, f"{rt} 应该属于好人阵营"

    def test_only_werewolf_is_wolf_team(self):
        for rt, role in ROLES.items():
            if rt == RoleType.WEREWOLF:
                assert role.team == Team.WEREWOLF
            else:
                assert role.team == Team.VILLAGER, f"{rt} 不应该属于狼人阵营"


class TestNightAction:
    """验证夜间行动相关属性."""

    def test_night_actors(self):
        """有夜间行动的角色：狼人、预言家、女巫、守卫."""
        assert ROLES[RoleType.WEREWOLF].has_night_action is True
        assert ROLES[RoleType.SEER].has_night_action is True
        assert ROLES[RoleType.WITCH].has_night_action is True
        assert ROLES[RoleType.GUARD].has_night_action is True

    def test_non_night_actors(self):
        """无夜间行动的角色：平民、猎人."""
        assert ROLES[RoleType.VILLAGER].has_night_action is False
        assert ROLES[RoleType.HUNTER].has_night_action is False

    def test_night_priority_order(self):
        """夜间行动顺序：狼人(1) < 守卫=预言家(2) < 女巫(3)."""
        assert ROLES[RoleType.WEREWOLF].night_priority == 1
        assert ROLES[RoleType.SEER].night_priority == 2
        assert ROLES[RoleType.GUARD].night_priority == 2
        assert ROLES[RoleType.WITCH].night_priority == 3
        # 无夜间行动的角色优先级应较高（排在后面）
        assert ROLES[RoleType.HUNTER].night_priority > 3
        assert ROLES[RoleType.VILLAGER].night_priority > 3

    def test_only_werewolf_can_kill(self):
        """只有狼人能在夜间杀人."""
        for rt, role in ROLES.items():
            if rt == RoleType.WEREWOLF:
                assert role.can_kill is True
            else:
                assert role.can_kill is False, f"{rt} 不应该能杀人"

    def test_max_night_targets(self):
        """验证每夜目标数."""
        assert ROLES[RoleType.WEREWOLF].max_night_targets == 1
        assert ROLES[RoleType.SEER].max_night_targets == 1
        assert ROLES[RoleType.WITCH].max_night_targets == 2   # 解药+毒药
        assert ROLES[RoleType.GUARD].max_night_targets == 1
        assert ROLES[RoleType.VILLAGER].max_night_targets == 0
        assert ROLES[RoleType.HUNTER].max_night_targets == 0


class TestSpecialAbilities:
    """验证特殊能力属性."""

    def test_only_hunter_can_act_after_death(self):
        """只有猎人出局后还能行动."""
        for rt, role in ROLES.items():
            if rt == RoleType.HUNTER:
                assert role.can_act_after_death is True
            else:
                assert role.can_act_after_death is False, f"{rt} 不应该能在出局后行动"

    def test_no_role_is_immune_by_default(self):
        """默认没有角色静态免疫夜间被刀."""
        for role in ROLES.values():
            assert role.immune_to_kill_at_night is False

    def test_all_roles_have_description(self):
        """每个角色都有描述."""
        for rt, role in ROLES.items():
            assert role.description, f"{rt} 缺少描述"

    def test_all_roles_have_win_condition(self):
        """每个角色都有获胜条件."""
        for rt, role in ROLES.items():
            assert role.win_condition, f"{rt} 缺少获胜条件"

    def test_win_conditions_text(self):
        """好人阵营获胜条件一致，狼人不同."""
        assert ROLES[RoleType.WEREWOLF].win_condition == "狼人人数 ≥ 存活好人人数。"
        for rt in [RoleType.VILLAGER, RoleType.SEER, RoleType.WITCH,
                    RoleType.HUNTER, RoleType.GUARD]:
            assert ROLES[rt].win_condition == "所有狼人出局。"


class TestWinConditionWording:
    """验证获胜条件描述措辞."""

    def test_no_empty_win_condition(self):
        for rt, role in ROLES.items():
            assert len(role.win_condition) > 2, f"{rt} 的获胜条件太短"


class TestConvenienceFunctions:
    """验证便利函数."""

    def test_get_role(self):
        assert get_role(RoleType.WEREWOLF) == ROLES[RoleType.WEREWOLF]
        assert get_role(RoleType.SEER) == ROLES[RoleType.SEER]

    def test_get_team_roles_werewolf(self):
        wolf_roles = get_team_roles(Team.WEREWOLF)
        assert len(wolf_roles) == 1
        assert wolf_roles[0].role_type == RoleType.WEREWOLF

    def test_get_team_roles_villager(self):
        good_roles = get_team_roles(Team.VILLAGER)
        assert len(good_roles) == 5
        types = {r.role_type for r in good_roles}
        assert types == {RoleType.VILLAGER, RoleType.SEER, RoleType.WITCH,
                         RoleType.HUNTER, RoleType.GUARD}

    def test_get_night_actors_order(self):
        actors = get_night_actors()
        # 按优先级升序
        assert actors[0].role_type == RoleType.WEREWOLF   # priority=1
        # priority=2 的有两个：预言家和守卫
        assert {actors[1].role_type, actors[2].role_type} == {RoleType.SEER, RoleType.GUARD}
        assert actors[3].role_type == RoleType.WITCH       # priority=3

    def test_get_night_actors_count(self):
        actors = get_night_actors()
        assert len(actors) == 4  # 狼人、预言家、守卫、女巫

    def test_get_night_actors_with_priority_max(self):
        actors = get_night_actors(priority_max=2)
        assert len(actors) == 3  # 狼人(1) + 预言家(2) + 守卫(2)

    def test_get_night_actors_empty(self):
        actors = get_night_actors(priority_max=0)
        assert actors == []


class TestRoleImmutability:
    """验证 Role 是 frozen dataclass，不允许修改."""

    def test_role_is_frozen(self):
        role = get_role(RoleType.VILLAGER)
        with pytest.raises(AttributeError):
            role.name_cn = "modified"  # type: ignore

    def test_team_enum_values(self):
        assert Team.WEREWOLF.value == "werewolf"
        assert Team.VILLAGER.value == "villager"
