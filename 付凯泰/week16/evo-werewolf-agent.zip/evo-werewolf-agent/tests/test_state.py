"""玩家与游戏状态测试 — 验证 engine/state.py 的数据和行为."""

import pytest

from roles.definition import RoleType, Team
from engine.state import Player, GameState


class TestPlayer:

    def test_create_villager(self):
        p = Player(player_id=1, name="玩家1", role_type=RoleType.VILLAGER)
        assert p.player_id == 1
        assert p.name == "玩家1"
        assert p.role_type == RoleType.VILLAGER
        assert p.is_alive is True
        assert p.is_poisoned is False
        assert p.guarded_last_night is False

    def test_player_team_property(self):
        """验证 team 属性委派到角色定义."""
        assert Player(1, "狼", RoleType.WEREWOLF).team == Team.WEREWOLF
        assert Player(2, "民", RoleType.VILLAGER).team == Team.VILLAGER
        assert Player(3, "预", RoleType.SEER).team == Team.VILLAGER
        assert Player(4, "女", RoleType.WITCH).team == Team.VILLAGER
        assert Player(5, "猎", RoleType.HUNTER).team == Team.VILLAGER
        assert Player(6, "守", RoleType.GUARD).team == Team.VILLAGER

    def test_role_cn_property(self):
        assert Player(1, "狼", RoleType.WEREWOLF).role_cn == "狼人"
        assert Player(2, "民", RoleType.VILLAGER).role_cn == "平民"

    def test_eliminate_normal(self):
        p = Player(1, "玩家1", RoleType.VILLAGER)
        p.eliminate()
        assert p.is_alive is False
        assert p.is_poisoned is False

    def test_eliminate_by_poison(self):
        p = Player(1, "玩家1", RoleType.VILLAGER)
        p.eliminate(by_poison=True)
        assert p.is_alive is False
        assert p.is_poisoned is True

    def test_eliminate_idempotent(self):
        p = Player(1, "玩家1", RoleType.VILLAGER)
        p.eliminate()
        p.eliminate()  # 第二次调用不应报错
        assert p.is_alive is False

    def test_player_default_skill_used(self):
        p = Player(1, "玩家1", RoleType.WITCH)
        assert p.skill_used == {}


class TestGameState:

    def test_initial_state(self):
        gs = GameState()
        assert gs.phase == "init"
        assert gs.day == 0
        assert gs.players == []
        assert gs.winner is None
        assert gs.witch_save_used is False
        assert gs.witch_poison_used is False
        assert gs.guard_last_target is None

    def test_alive_players(self):
        gs = GameState()
        gs.players = [
            Player(1, "P1", RoleType.VILLAGER),
            Player(2, "P2", RoleType.WEREWOLF, is_alive=False),
            Player(3, "P3", RoleType.SEER),
        ]
        alive = gs.alive_players()
        assert len(alive) == 2
        assert all(p.is_alive for p in alive)

    def test_get_player_found(self):
        gs = GameState()
        gs.players = [Player(1, "P1", RoleType.VILLAGER)]
        assert gs.get_player(1) is gs.players[0]

    def test_get_player_not_found(self):
        gs = GameState()
        gs.players = [Player(1, "P1", RoleType.VILLAGER)]
        assert gs.get_player(999) is None

    def test_phase_transitions(self):
        """GameState 阶段字段可正常变更."""
        gs = GameState()
        assert gs.phase == "init"
        gs.phase = "night"
        assert gs.phase == "night"
        gs.day = 1
        assert gs.day == 1
        gs.phase = "discussion"
        assert gs.phase == "discussion"

    def test_eliminated_history(self):
        """出局记录可追加."""
        gs = GameState()
        gs.eliminated_history.append({"day": 1, "player_id": 2, "reason": "vote"})
        gs.eliminated_history.append({"day": 2, "player_id": 5, "reason": "night_kill"})
        assert len(gs.eliminated_history) == 2
