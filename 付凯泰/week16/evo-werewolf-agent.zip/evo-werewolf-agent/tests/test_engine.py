"""引擎核心组件测试 — 阶段管理、事件系统、夜间行动、预设、投票、Agent适配层."""

from __future__ import annotations

import pytest

from roles.definition import RoleType, Team, Trait
from engine.state import Player, GameState


# ========================================================================
# PhaseManager — 阶段流转
# ========================================================================

from engine.phases import Phase, PhaseManager, PHASE_CYCLE


class TestPhaseManager:

    def test_initial_state(self):
        pm = PhaseManager()
        assert pm.phase == Phase.INIT
        assert pm.day == 0

    def test_first_next_phase_starts_night_day1(self):
        pm = PhaseManager()
        phase = pm.next_phase()
        assert phase == Phase.NIGHT
        assert pm.day == 1

    def test_full_cycle(self):
        pm = PhaseManager()
        cycle = []
        pm.next_phase()                             # NIGHT, day=1
        for _ in range(4):
            cycle.append(pm.next_phase())
        assert cycle == [
            Phase.DISCUSSION,
            Phase.VOTE,
            Phase.ELIMINATION,
            Phase.NIGHT,                            # 下一轮 night, day=2
        ]
        assert pm.day == 2

    def test_daily_increment(self):
        pm = PhaseManager()
        pm.next_phase()  # NIGHT day=1
        pm.next_phase()  # DISCUSSION
        pm.next_phase()  # VOTE
        pm.next_phase()  # ELIMINATION
        pm.next_phase()  # NIGHT day=2
        pm.next_phase()  # DISCUSSION
        pm.next_phase()  # VOTE
        pm.next_phase()  # ELIMINATION
        pm.next_phase()  # NIGHT day=3
        assert pm.day == 3

    def test_end_game(self):
        pm = PhaseManager()
        pm.next_phase()
        pm.end_game()
        assert pm.phase == Phase.GAME_OVER

    def test_next_phase_after_game_over(self):
        pm = PhaseManager()
        pm.end_game()
        assert pm.next_phase() == Phase.GAME_OVER  # 保持 game_over

    def test_transition_to(self):
        pm = PhaseManager()
        pm.transition_to(Phase.VOTE)
        assert pm.phase == Phase.VOTE

    def test_reset(self):
        pm = PhaseManager()
        pm.next_phase()
        pm.next_phase()
        pm.reset()
        assert pm.phase == Phase.INIT
        assert pm.day == 0

    def test_phase_cycle_constant_order(self):
        assert PHASE_CYCLE == [
            Phase.NIGHT,
            Phase.DISCUSSION,
            Phase.VOTE,
            Phase.ELIMINATION,
        ]


# ========================================================================
# EventBus — 事件订阅/发布
# ========================================================================

from engine.events import EventBus


class TestEventBus:

    def test_on_and_emit(self):
        bus = EventBus()
        received = []
        bus.on("test:event", lambda **kw: received.append(kw.get("msg")))
        bus.emit("test:event", msg="hello")
        assert received == ["hello"]

    def test_multiple_handlers(self):
        bus = EventBus()
        results = []
        bus.on("evt", lambda **kw: results.append("a"))
        bus.on("evt", lambda **kw: results.append("b"))
        bus.emit("evt")
        assert results == ["a", "b"]

    def test_off_removes_handler(self):
        bus = EventBus()
        results = []

        def handler(**kw):
            results.append("x")

        bus.on("evt", handler)
        bus.emit("evt")
        bus.off("evt", handler)
        bus.emit("evt")
        assert results == ["x"]  # 只触发一次

    def test_off_nonexistent_handler(self):
        """取消未注册的处理函数不应报错."""
        bus = EventBus()

        def h(**kw):
            pass

        bus.off("nonexistent", h)  # 不应 raise

    def test_emit_no_handlers(self):
        bus = EventBus()
        bus.emit("ghost")  # 不应 raise

    def test_clear(self):
        bus = EventBus()
        results = []

        def h(**kw):
            results.append("x")

        bus.on("evt", h)
        bus.clear()
        bus.emit("evt")
        assert results == []

    def test_data_passthrough(self):
        bus = EventBus()
        received = {}

        def h(**kw):
            received.update(kw)

        bus.on("data", h)
        bus.emit("data", a=1, b="two", c=[3])
        assert received == {"a": 1, "b": "two", "c": [3]}


# ========================================================================
# Actions — 夜间行动解析
# ========================================================================

from engine.actions import resolve_night_actions, validate_night_action


def _make_state(**kwargs) -> GameState:
    """快速构造测试用 GameState，带默认玩家."""
    state = GameState(**kwargs)
    state.players = [
        Player(1, "玩家1", RoleType.VILLAGER),
        Player(2, "玩家2", RoleType.WEREWOLF),
        Player(3, "玩家3", RoleType.SEER),
        Player(4, "玩家4", RoleType.WITCH),
        Player(5, "玩家5", RoleType.GUARD),
        Player(6, "玩家6", RoleType.VILLAGER),
    ]
    return state


class TestResolveNightActions:

    def test_no_actions_pending(self):
        state = _make_state()
        events = resolve_night_actions(state, None, None, None, False, None)
        assert events == []
        assert all(p.is_alive for p in state.players)

    def test_wolf_kill_no_intervention(self):
        state = _make_state()
        events = resolve_night_actions(state, kill_target=1, guard_target=None,
                                       seer_target=None, witch_save=False, witch_poison_target=None)
        assert state.get_player(1).is_alive is False
        assert any(e["type"] == "player:killed" and e["player_id"] == 1 for e in events)

    def test_guard_protects_target(self):
        state = _make_state()
        events = resolve_night_actions(state, kill_target=1, guard_target=1,
                                       seer_target=None, witch_save=False, witch_poison_target=None)
        assert state.get_player(1).is_alive is True  # 被守护了
        assert any(e["type"] == "player:guarded" and e["player_id"] == 1 for e in events)

    def test_witch_saves_target(self):
        state = _make_state()
        events = resolve_night_actions(state, kill_target=1, guard_target=None,
                                       seer_target=None, witch_save=True, witch_poison_target=None)
        assert state.get_player(1).is_alive is True
        assert state.witch_save_used is True
        assert any(e["type"] == "player:saved" and e["player_id"] == 1 for e in events)

    def test_guard_and_witch_same_target_guard_wins(self):
        """守卫和女巫救同一人 → 守卫生效，女巫解药保留."""
        state = _make_state()
        events = resolve_night_actions(state, kill_target=1, guard_target=1,
                                       seer_target=None, witch_save=True, witch_poison_target=None)
        assert state.get_player(1).is_alive is True
        assert state.witch_save_used is False  # 女巫解药保留
        assert any(e["type"] == "player:saved" and e["player_id"] == 1 and e["by"] == "guard"
                   for e in events)

    def test_witch_poison_kills(self):
        state = _make_state()
        events = resolve_night_actions(state, kill_target=None, guard_target=None,
                                       seer_target=None, witch_save=False, witch_poison_target=3)
        assert state.get_player(3).is_alive is False
        assert state.get_player(3).is_poisoned is True
        assert state.witch_poison_used is True

    def test_witch_poison_disabled_hunter_shot(self):
        """被毒杀的猎人在淘汰结算时不能开枪."""
        state = _make_state()
        state.players.append(Player(7, "猎人", RoleType.HUNTER))
        resolve_night_actions(state, kill_target=None, guard_target=None,
                              seer_target=None, witch_save=False, witch_poison_target=7)
        hunter = state.get_player(7)
        assert hunter.is_alive is False
        assert hunter.is_poisoned is True  # 标记毒杀，猎人不可开枪

    def test_kill_and_poison_two_deaths(self):
        state = _make_state()
        events = resolve_night_actions(state, kill_target=1, guard_target=None,
                                       seer_target=None, witch_save=False, witch_poison_target=3)
        assert state.get_player(1).is_alive is False
        assert state.get_player(3).is_alive is False
        types = [e["type"] for e in events]
        assert "player:killed" in types
        assert "player:poisoned" in types

    def test_guard_target_already_dead(self):
        """守卫守护已死玩家 → 无效果."""
        state = _make_state()
        state.get_player(5).eliminate()
        events = resolve_night_actions(state, kill_target=1, guard_target=5,
                                       seer_target=None, witch_save=False, witch_poison_target=None)
        assert not any(e["type"] == "player:guarded" for e in events)

    def test_guard_tracking(self):
        state = _make_state()
        resolve_night_actions(state, kill_target=None, guard_target=3,
                              seer_target=None, witch_save=False, witch_poison_target=None)
        assert state.guard_last_target == 3
        assert state.get_player(3).guarded_last_night is True

    def test_win_check_on_wolf_death_triggers_good_win(self):
        """所有狼人死亡 → 好人获胜."""
        state = _make_state()
        # 杀掉唯一的狼人 玩家2
        resolve_night_actions(state, kill_target=None, guard_target=None,
                              seer_target=None, witch_save=False, witch_poison_target=2)
        assert state.winner == Team.VILLAGER

    def test_win_check_not_triggered_mid_game(self):
        """游戏未结束时 winner 为 None."""
        state = _make_state()
        resolve_night_actions(state, kill_target=1, guard_target=None,
                              seer_target=None, witch_save=False, witch_poison_target=None)
        assert state.winner is None


class TestValidateNightAction:

    def test_valid_kill(self):
        state = _make_state()
        err = validate_night_action(state, player_id=2, target_id=1, action_type="kill")
        assert err == ""

    def test_kill_dead_player(self):
        state = _make_state()
        state.get_player(1).eliminate()
        err = validate_night_action(state, player_id=2, target_id=1, action_type="kill")
        assert err != ""

    def test_kill_wolf_comrade(self):
        state = _make_state()
        err = validate_night_action(state, player_id=2, target_id=5, action_type="kill")
        # 玩家5是守卫，不是狼同伴，所以应该合法
        assert err == ""

    def test_kill_wolf_fellow(self):
        state = _make_state()
        # 增加一个狼人
        state.players.append(Player(7, "狼2", RoleType.WEREWOLF))
        err = validate_night_action(state, player_id=2, target_id=7, action_type="kill")
        assert err != ""  # 不能刀同伴

    def test_guard_valid(self):
        state = _make_state()
        err = validate_night_action(state, player_id=5, target_id=1, action_type="guard")
        assert err == ""

    def test_guard_consecutive_same_target(self):
        state = _make_state()
        state.guard_last_target = 1
        err = validate_night_action(state, player_id=5, target_id=1, action_type="guard")
        assert err != ""

    def test_poison_after_used(self):
        state = _make_state()
        state.witch_poison_used = True
        err = validate_night_action(state, player_id=4, target_id=1, action_type="poison")
        assert err != ""

    def test_dead_player_action(self):
        state = _make_state()
        state.get_player(2).eliminate()
        err = validate_night_action(state, player_id=2, target_id=1, action_type="kill")
        assert err != ""


# ========================================================================
# Presets — 经典角色配比
# ========================================================================

from engine.presets import CLASSIC_ROSTERS, DEFAULT_ROSTER, get_roster, validate_roster


class TestPresets:

    def test_classic_rosters_contains_all_sizes(self):
        assert sorted(CLASSIC_ROSTERS.keys()) == [6, 7, 8, 9, 10, 12]

    def test_6_player_roster(self):
        r = CLASSIC_ROSTERS[6]
        assert len(r) == 6
        assert r.count(RoleType.WEREWOLF) == 2
        assert r.count(RoleType.SEER) == 1
        assert r.count(RoleType.WITCH) == 1
        assert r.count(RoleType.VILLAGER) == 2

    def test_9_player_roster_has_all_roles(self):
        r = CLASSIC_ROSTERS[9]
        assert len(r) == 9
        assert r.count(RoleType.WEREWOLF) == 3
        assert r.count(RoleType.SEER) == 1
        assert r.count(RoleType.WITCH) == 1
        assert r.count(RoleType.HUNTER) == 1
        assert r.count(RoleType.GUARD) == 1
        assert r.count(RoleType.VILLAGER) == 2

    def test_default_roster_is_9_player(self):
        assert len(DEFAULT_ROSTER) == 9

    def test_get_roster_shuffles(self):
        """多次调用 get_roster 应当返回不同的顺序."""
        r1 = get_roster(8)
        r2 = get_roster(8)
        # 内容一致
        assert sorted(r1, key=lambda x: x.value) == sorted(r2, key=lambda x: x.value)
        # 顺序大概率不同（不算严格校验，洗牌有极小概率相同）
        assert r1 != r2 or r1 != r2  # 两次至少一次不同（洗牌随机性）

    def test_get_roster_unsupported_size(self):
        with pytest.raises(ValueError, match="不支持"):
            get_roster(5)

    def test_validate_roster_too_few(self):
        with pytest.raises(ValueError, match="至少 4 人"):
            validate_roster([RoleType.VILLAGER, RoleType.VILLAGER, RoleType.VILLAGER])

    def test_validate_roster_no_wolf(self):
        with pytest.raises(ValueError, match="至少需要 1 名狼人"):
            validate_roster([RoleType.VILLAGER] * 4)

    def test_validate_roster_no_good(self):
        with pytest.raises(ValueError, match="至少需要 1 名好人"):
            validate_roster([RoleType.WEREWOLF] * 5)

    def test_validate_roster_valid(self):
        # 不应抛异常
        validate_roster([RoleType.WEREWOLF, RoleType.VILLAGER, RoleType.SEER, RoleType.WITCH])


# ========================================================================
# Vote — 投票系统
# ========================================================================

from engine.vote import hold_vote, format_vote_prompt, format_speech_prompt


class TestHoldVote:

    def _state_with_alive(self) -> GameState:
        state = GameState()
        state.players = [
            Player(1, "P1", RoleType.VILLAGER),
            Player(2, "P2", RoleType.WEREWOLF),
            Player(3, "P3", RoleType.VILLAGER),
        ]
        return state

    def test_normal_vote_eliminates(self):
        state = self._state_with_alive()
        eliminated, ties = hold_vote(state, {1: 2, 3: 2})
        assert eliminated is not None
        assert eliminated.player_id == 2
        assert state.get_player(2).is_alive is False
        assert ties == []

    def test_tie_no_elimination(self):
        state = self._state_with_alive()
        state.players.append(Player(4, "P4", RoleType.VILLAGER))
        # P1→P2, P3→P4, 2票对2票
        eliminated, ties = hold_vote(state, {1: 2, 3: 4})
        assert eliminated is None
        assert 2 in ties
        assert 4 in ties
        # 所有人存活
        assert all(p.is_alive for p in state.players)

    def test_no_votes(self):
        state = self._state_with_alive()
        eliminated, ties = hold_vote(state, {})
        assert eliminated is None
        assert ties == []

    def test_self_vote_allowed(self):
        """自投票不报错，且正常结算."""
        state = self._state_with_alive()
        # 玩家1投自己，玩家2也投1，玩家3投3 → 玩家1出局
        eliminated, ties = hold_vote(state, {1: 1, 2: 1, 3: 3})
        assert eliminated is not None
        assert eliminated.player_id == 1
        assert eliminated.is_alive is False

    def test_eliminated_history_appended(self):
        state = self._state_with_alive()
        hold_vote(state, {1: 2, 3: 2})
        assert len(state.eliminated_history) == 1
        entry = state.eliminated_history[0]
        assert entry["player_id"] == 2
        assert entry["reason"] == "vote"


class TestVotePrompt:

    def test_format_vote_prompt_contains_phase(self):
        state = GameState()
        state.day = 3
        state.players = [Player(1, "A", RoleType.VILLAGER), Player(2, "B", RoleType.WEREWOLF)]
        voter = state.players[0]
        prompt = format_vote_prompt(state, voter, [])
        assert "投票" in prompt
        assert "3" in prompt  # day
        assert "A" in prompt
        assert "B" in prompt

    def test_format_speech_prompt_contains_speaker_name(self):
        state = GameState()
        state.day = 2
        state.players = [Player(1, "发言人", RoleType.VILLAGER)]
        prompt = format_speech_prompt(state, state.players[0], [])
        assert "发言人" in prompt
        assert "讨论" in prompt
        assert "2" in prompt


# ========================================================================
# AgentAdapter — FallbackAgent 特质感知 Mock
# ========================================================================

from engine.agent_adapter import FallbackAgent


class TestFallbackAgent:

    def test_construct_default(self):
        agent = FallbackAgent(name="测试", trait=Trait.RANDOM)
        assert agent.name == "测试"
        assert agent.trait == Trait.RANDOM
        assert len(agent._messages) == 1  # system prompt

    def test_construct_with_instructions(self):
        agent = FallbackAgent(name="指导", instructions="你是好人", trait=Trait.CAUTIOUS)
        assert agent.instructions == "你是好人"
        assert agent._messages[0]["role"] == "system"
        assert agent._messages[0]["content"] == "你是好人"

    @pytest.mark.asyncio
    async def test_run_returns_string(self):
        agent = FallbackAgent(name="测试", trait=Trait.RANDOM)
        result = await agent.run("请发言")
        assert isinstance(result, str)
        assert len(result) > 0

    @pytest.mark.asyncio
    async def test_run_appends_messages(self):
        agent = FallbackAgent(name="消息", trait=Trait.RANDOM)
        await agent.run("你好")
        await agent.run("再说")
        # system + user1 + asst1(mock) + user2
        assert len(agent._messages) == 4

    def test_mock_choose_target_cautious(self):
        """CAUTIOUS 选第一个目标."""
        agent = FallbackAgent(name="保", trait=Trait.CAUTIOUS)
        result = agent._mock_choose_target([3, 7, 1])
        assert result == "3"  # 第一个

    def test_mock_choose_target_bold(self):
        """BOLD 选最后一个目标."""
        agent = FallbackAgent(name="激", trait=Trait.BOLD)
        result = agent._mock_choose_target([3, 7, 1])
        assert result == "1"  # 最后一个

    def test_mock_choose_target_random(self):
        """RANDOM 在可选范围内."""
        agent = FallbackAgent(name="随", trait=Trait.RANDOM)
        ids = [3, 7, 1]
        result = agent._mock_choose_target(ids)
        assert int(result) in ids

    def test_mock_vote_cautious(self):
        agent = FallbackAgent(name="保", trait=Trait.CAUTIOUS)
        r = agent._mock_vote([3, 7, 1], "投票")
        assert r in ("3", "7", "1")

    def test_mock_witch_save_cautious(self):
        agent = FallbackAgent(name="保", trait=Trait.CAUTIOUS)
        assert agent._mock_witch_save() == "否"

    def test_mock_witch_save_bold(self):
        agent = FallbackAgent(name="激", trait=Trait.BOLD)
        assert agent._mock_witch_save() == "是"

    def test_mock_witch_save_random(self):
        agent = FallbackAgent(name="随", trait=Trait.RANDOM)
        assert agent._mock_witch_save() in ("是", "否")

    def test_mock_speech_cautious(self):
        agent = FallbackAgent(name="保", trait=Trait.CAUTIOUS)
        speech = agent._mock_speech("请发言")
        assert "头绪" in speech or "再听听" in speech or "看法" in speech

    def test_mock_speech_bold(self):
        agent = FallbackAgent(name="激", trait=Trait.BOLD)
        speech = agent._mock_speech("请发言")
        assert "怀疑" in speech or "注意" in speech

    @pytest.mark.asyncio
    async def test_mock_fallback_on_api_failure(self):
        """API 不可用时自动降级到 mock."""
        agent = FallbackAgent(name="备用", trait=Trait.RANDOM)
        # 正常调用走 _call_api -> 失败 -> _mock_reply
        result = await agent.run("请选择目标，可选：1. 张三 2. 李四")
        assert isinstance(result, str)

    def test_mock_reply_vote_returns_digit(self):
        agent = FallbackAgent(name="投", trait=Trait.RANDOM)
        result = agent._mock_reply("请投票选择要放逐的玩家，可选：1. 小红 2. 小蓝")
        assert any(c.isdigit() for c in result)

    def test_mock_reply_target_returns_digit(self):
        agent = FallbackAgent(name="选", trait=Trait.RANDOM)
        result = agent._mock_reply("请选择目标，可选：1. A 2. B 3. C")
        assert any(c.isdigit() for c in result)

    def test_mock_reply_speech_returns_text(self):
        agent = FallbackAgent(name="说", trait=Trait.RANDOM)
        result = agent._mock_reply("请发表你的看法")
        assert any(c.isalpha() for c in result)
