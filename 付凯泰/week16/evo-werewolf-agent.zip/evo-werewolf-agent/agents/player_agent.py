"""玩家 Agent — 结合角色身份、特质与 LLM 决策的高层抽象."""

from __future__ import annotations

from typing import Optional

from engine.agent_adapter import FallbackAgent
from roles.definition import RoleType, Team, Trait, get_role


class PlayerAgent:
    """玩家 Agent，承载角色身份、特质和 LLM 决策能力."""

    def __init__(
        self,
        name: str,
        role_type: RoleType,
        trait: Trait = Trait.RANDOM,
        brain: Optional[FallbackAgent] = None,
    ):
        self.name = name
        self.role_type = role_type
        self.trait = trait
        self.role = get_role(role_type)
        self.team = self.role.team
        self.is_alive = True
        self.brain = brain or self._create_brain()

    def _create_brain(self) -> FallbackAgent:
        instructions = self._build_system_prompt()
        return FallbackAgent(
            name=self.name,
            instructions=instructions,
            trait=self.trait,
        )

    def _build_system_prompt(self) -> str:
        team_cn = "狼人阵营" if self.team == Team.WEREWOLF else "好人阵营"
        desc = {
            Trait.CAUTIOUS: "你的风格是谨慎保守的：做决策时倾向于安全选项，发言保持低调。",
            Trait.RANDOM: "你的风格是不可预测的：每次决策都让人捉摸不透。",
            Trait.BOLD: "你的风格是大胆激进的：主动出击，强势站边，敢于冒险。",
        }[self.trait]
        return (
            f"你是{self.name}，你的身份是：{self.role.name_cn}。\n"
            f"所属阵营：{team_cn}\n"
            f"获胜条件：{self.role.win_condition}\n"
            f"角色描述：{self.role.description}\n\n"
            f"{desc}\n\n"
            "请根据你的身份和已知信息做出合理决策。\n"
            "输出格式：只回复你决策的内容，不要包含额外解释。"
        )

    async def run(self, prompt: str) -> str:
        """执行一次 LLM 决策，返回回复."""
        return await self.brain.run(prompt)
