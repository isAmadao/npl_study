"""agents 包兼容层 — 包名与 OpenAI Agents SDK 冲突时提供 fallback."""


class _MockResult:
    """模拟 Runner.run 返回值."""
    def __init__(self, output: str = ""):
        self.final_output = output


class _MockAgent:
    """模拟 Agent 类."""
    def __init__(self, **kwargs):
        self.name = kwargs.get("name", "")
        self.model = kwargs.get("model", "")
        self.instructions = kwargs.get("instructions", "")


class _MockRunner:
    """模拟 Runner 类."""
    @staticmethod
    async def run(agent, input_str: str):
        return _MockResult(input_str)


# 导出 base.py 需要的符号
Agent = _MockAgent
Runner = _MockRunner
def set_default_openai_api(api: str = "chat_completions") -> None:
    _ = api


def set_tracing_disabled(disabled: bool = True) -> None:
    _ = disabled
