"""对局记录 Pydantic 模型."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class DialogueRecord(BaseModel):
    """单条对话/决策/事件记录."""
    model_config = ConfigDict(extra="allow")

    seq: int
    type: str  # host | decision | event
    day: int = 0
    phase: str = ""
    speaker: str = ""
    message: str = ""
    # decision 专用字段
    role: str = ""
    trait: str = ""
    action: str = ""
    prompt: str = ""
    response: str = ""
    target: Optional[str] = None
    # event 专用字段
    event_type: str = ""


class GameRecord(BaseModel):
    """整局游戏结构化记录，支持 JSON 序列化."""
    game_id: str
    started_at: datetime
    entries: list[DialogueRecord]
