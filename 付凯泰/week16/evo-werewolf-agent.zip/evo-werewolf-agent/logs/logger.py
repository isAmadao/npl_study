"""日志配置 — 保存每次比赛的运行过程，支持文件和控制台双输出."""

from __future__ import annotations

import logging
import os
import sys
from datetime import datetime
from typing import Literal

from logs.formatter import GameFormatter

_LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "runs")
Level = Literal["debug", "info", "warning", "error"]

_LEVEL_MAP: dict[str, int] = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warning": logging.WARNING,
    "error": logging.ERROR,
}


def setup_logger(
    name: str = "werewolf",
    level: Level | str = "info",
    log_file: str | None = None,
    console: bool = True,
) -> logging.Logger:
    """配置日志器，同时输出到控制台和文件.

    - 文件保存在 logs/runs/ 目录下，按日期命名
    - 控制台输出彩色级别标记（可选）
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()

    formatter = GameFormatter(datefmt="%H:%M:%S")

    # 文件 handler
    os.makedirs(_LOG_DIR, exist_ok=True)
    if log_file is None:
        log_file = f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    fh = logging.FileHandler(
        os.path.join(_LOG_DIR, log_file),
        encoding="utf-8",
    )
    fh.setLevel(_LEVEL_MAP.get(level, logging.INFO))
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    # 控制台 handler
    if console:
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(_LEVEL_MAP.get(level, logging.INFO))
        ch.setFormatter(formatter)
        logger.addHandler(ch)

    return logger


def get_logger(name: str = "werewolf") -> logging.Logger:
    """获取已配置的日志器。未调用 setup_logger 时会自动初始化."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        return setup_logger(name)
    return logger
