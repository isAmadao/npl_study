"""自定义日志格式器 — 支持游戏上下文（阶段、天数、玩家）. """

from __future__ import annotations

import logging


class GameFormatter(logging.Formatter):
    """日志格式器，显示游戏阶段/天数/玩家等上下文."""

    def format(self, record: logging.LogRecord) -> str:
        ctx = ""
        phase = getattr(record, "phase", None) or ""
        day = getattr(record, "day", None)
        player = getattr(record, "player", None) or ""
        extras = []
        if day is not None:
            extras.append(f"第{day}天")
        if phase:
            extras.append(phase)
        if player:
            extras.append(player)
        if extras:
            ctx = f"[{'/'.join(extras)}] "

        base = f"{self.formatTime(record)} | {record.levelname:<5} | {ctx}{record.getMessage()}"
        return base
