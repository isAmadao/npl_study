"""对局记录器 — 将每局游戏整理为结构化对话日志."""

from __future__ import annotations

import os
from datetime import datetime
from typing import Optional

from engine.events import (
    game_bus,
    EVENT_NIGHT_START,
    EVENT_NIGHT_END,
    EVENT_GAME_OVER,
    EVENT_DISCUSSION_START,
    EVENT_VOTE_RESULT,
    EVENT_PLAYER_ELIMINATED,
)
from engine.game import GameHost
from roles.definition import Trait
from schema.record import DialogueRecord, GameRecord
from logs.logger import setup_logger


# ============================================================
# 记录器
# ============================================================

class GameRecorder:
    """记录整局游戏的对话与决策，输出 JSON 日志供后续分析."""

    def __init__(self):
        self.entries: list[DialogueRecord] = []
        self._start_time = datetime.now()

    def add_host(self, message: str, day: int = 0, phase: str = "") -> None:
        self.entries.append(DialogueRecord(
            type="host", day=day, phase=phase,
            speaker="主持人", message=message,
            seq=len(self.entries),
        ))

    def add_decision(
        self,
        player_name: str, role_name: str, trait: Trait,
        day: int, phase: str, action: str,
        prompt: str = "", response: str = "",
        target: Optional[str] = None,
    ) -> None:
        self.entries.append(DialogueRecord(
            type="decision", day=day, phase=phase,
            speaker=player_name, role=role_name,
            trait=trait.cn, action=action,
            prompt=prompt[:200], response=response[:200],
            target=target, seq=len(self.entries),
        ))

    def add_event(self, event_type: str, message: str, **extra) -> None:
        self.entries.append(DialogueRecord(
            type="event", event_type=event_type,
            message=message, seq=len(self.entries),
            **extra,
        ))

    def save_json(self, filepath: str) -> str:
        record = GameRecord(
            game_id=self._start_time.strftime("%Y%m%d_%H%M%S"),
            started_at=self._start_time,
            entries=self.entries,
        )
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(record.model_dump_json(ensure_ascii=False, indent=2))
        return filepath

    def save_text(self, filepath: str) -> str:
        lines = [f"对局时间: {self._start_time.isoformat()}", "=" * 50]
        for e in self.entries:
            if e.type == "host":
                lines.append(f"\n[主持人] {e.message}")
            elif e.type == "decision":
                lines.append(f"  [{e.role}·{e.trait}] {e.speaker} → {e.response}")
            elif e.type == "event":
                lines.append(f"\n⚡ {e.message}")
        lines.append("\n" + "=" * 50)
        lines.append(f"共 {len(self.entries)} 条记录")
        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        return filepath


# ============================================================
# Agent 包装器
# ============================================================

class LoggedAgent:
    """Agent 包装器 — 自动记录每次 LLM 调用."""

    def __init__(self, agent, player_name: str, role_name: str, trait: Trait,
                 recorder: GameRecorder, day: int, phase: str, action: str):
        self._agent = agent
        self.player_name = player_name
        self.role_name = role_name
        self.trait = trait
        self.recorder = recorder
        self.day = day
        self.phase = phase
        self.action = action

    async def run(self, input_str: str) -> str:
        result = await self._agent.run(input_str)
        self.recorder.add_decision(
            player_name=self.player_name, role_name=self.role_name,
            trait=self.trait, day=self.day, phase=self.phase,
            action=self.action, prompt=input_str, response=result,
        )
        return result


# ============================================================
# 运行一局记录式对局
# ============================================================

def _log_dir() -> str:
    d = os.path.join(os.path.dirname(__file__), "games")
    os.makedirs(d, exist_ok=True)
    return d


def _update_phase(host: GameHost, day: int, phase: str) -> None:
    for agent in host.agents.values():
        if isinstance(agent, LoggedAgent):
            agent.day = day
            agent.phase = phase
            agent.action = phase


async def run_demo(player_count: int = 8) -> GameRecorder:
    """运行一局记录式对局，返回记录器。"""
    # 初始化运行日志（保存在 logs/runs/ 目录下）
    setup_logger(level="info")

    recorder = GameRecorder()
    host = GameHost(player_count=player_count)

    # 初始角色分配
    recorder.add_host(f"游戏开始！共 {len(host.state.players)} 名玩家。")
    for p in host.state.players:
        recorder.add_host(f"{p.name} 抽到了 {p.role_cn}（{p.trait.cn}）", phase="初始")

    # 包装 Agent
    role_map = {p.player_id: p.role_cn for p in host.state.players}
    for pid, agent in host.agents.items():
        host.agents[pid] = LoggedAgent(
            agent=agent, player_name=agent.name,
            role_name=role_map[pid],
            trait=host.state.get_player(pid).trait,
            recorder=recorder, day=0, phase="初始", action="unknown",
        )

    # 事件订阅
    def on_night_start(**kw):
        day = kw.get("day", 0)
        recorder.add_host(f"第 {day} 晚 — 天黑请闭眼。", day=day, phase="夜晚")
        _update_phase(host, day, "夜晚")

    def on_night_end(**kw):
        recorder.add_host("天亮了。", day=host.phase_manager.day, phase="夜晚")

    def on_discussion_start(**kw):
        day = kw.get("day", 0)
        recorder.add_host(f"第 {day} 天 — 讨论开始。", day=day, phase="讨论")
        _update_phase(host, day, "讨论")

    def on_vote_result(**kw):
        votes = kw.get("votes", {})
        day = host.phase_manager.day
        detail = "、".join(
            f"{host.state.get_player(v).name}→{host.state.get_player(t).name}"
            for v, t in votes.items()
            if host.state.get_player(v) and host.state.get_player(t)
        )
        recorder.add_host(f"投票详情：{detail}", day=day, phase="投票")

    def on_player_eliminated(**kw):
        p = host.state.get_player(kw.get("player_id"))
        if p:
            recorder.add_event("eliminated", f"{p.name}({p.role_cn}) 被放逐")

    def on_game_over(**kw):
        w = kw.get("winner")
        wcn = "狼人阵营" if w and w.value == "werewolf" else "好人阵营"
        recorder.add_event("game_over", f"游戏结束！{wcn}获胜！")

    game_bus.on(EVENT_NIGHT_START, on_night_start)
    game_bus.on(EVENT_NIGHT_END, on_night_end)
    game_bus.on(EVENT_DISCUSSION_START, on_discussion_start)
    game_bus.on(EVENT_VOTE_RESULT, on_vote_result)
    game_bus.on(EVENT_PLAYER_ELIMINATED, on_player_eliminated)
    game_bus.on(EVENT_GAME_OVER, on_game_over)

    # 运行
    result = await host.run_game()

    # 清理
    for ev in [EVENT_NIGHT_START, EVENT_NIGHT_END, EVENT_DISCUSSION_START,
               EVENT_VOTE_RESULT, EVENT_PLAYER_ELIMINATED, EVENT_GAME_OVER]:
        game_bus.off(ev, on_night_start if ev == EVENT_NIGHT_START else
                     on_night_end if ev == EVENT_NIGHT_END else
                     on_discussion_start if ev == EVENT_DISCUSSION_START else
                     on_vote_result if ev == EVENT_VOTE_RESULT else
                     on_player_eliminated if ev == EVENT_PLAYER_ELIMINATED else
                     on_game_over)

    # 讨论记录
    for line in host.discussion_history:
        recorder.add_event("discussion", f"💬 {line}")

    # 保存
    log_dir = _log_dir()
    base = f"game_{recorder._start_time.strftime('%Y%m%d_%H%M%S')}"
    jp = recorder.save_json(os.path.join(log_dir, f"{base}.json"))
    tp = recorder.save_text(os.path.join(log_dir, f"{base}.txt"))

    # 摘要
    wcn = "狼人阵营" if result.winner and result.winner.value == "werewolf" else "好人阵营"
    reason_map = {"vote": "被放逐", "hunter_shot": "被猎人带走",
                  "night_kill": "夜间被刀", "poison": "被毒杀"}

    print("\n" + "=" * 55)
    print("          🐺 AI 狼人杀 — 对局报告")
    print("=" * 55)
    print(f"\n参赛玩家 ({len(host.state.players)} 人)：")
    for p in host.state.players:
        print(f"  [{'✓' if p.is_alive else '✗'}] {p.name} — {p.role_cn}（{p.trait.cn}）")

    print(f"\n淘汰记录 ({len(result.eliminated_history)} 人)：")
    for e in result.eliminated_history:
        p = host.state.get_player(e["player_id"])
        r = reason_map.get(e.get("reason", ""), e.get("reason", ""))
        print(f"  {p.name}({p.role_cn}) — {r}" if p else f"  P{e['player_id']} — {r}")

    print(f"\n🏆 胜者：{wcn}")
    print(f"\n📄 JSON → {jp}\n   文本 → {tp}")
    print(f"📊 共记录 {len(recorder.entries)} 条对话记录")
    print("=" * 55 + "\n")

    return recorder
