# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

AI 狼人杀 (AI Werewolf) — Multi-agent team system for information-asymmetric gameplay. Each agent plays a role (werewolf, seer, witch, etc.) with independent goals, strategies, and action spaces under strict information isolation.

## Project Structure

```
.
├── CLAUDE.md
├── README.md
├── main.py                  # 入口：解析参数、初始化游戏、启动对局
├── requirements.txt         # 依赖
│
├── agents/                  # LLM 客户端层
│   ├── __init__.py
│   └── base.py              # BaseAgent（直接 HTTP 调用 LLM API，无需额外 SDK）
│
├── roles/                   # 角色 Agent 定义
│   ├── __init__.py
│   ├── werewolf.py          # 狼人（占位）
│   ├── seer.py              # 预言家（占位）
│   ├── witch.py             # 女巫（占位）
│   ├── villager.py          # 平民（占位）
│   ├── hunter.py            # 猎人（占位）
│   ├── guard.py             # 守卫（占位）
│   └── factory.py           # Agent 工厂（占位）
│
├── engine/                  # 游戏引擎核心
│   ├── __init__.py
│   ├── game.py              # GameHost 主持人 — 编排完整对局，协调 LLM 决策
│   ├── state.py             # 游戏状态（Player/GameState）
│   ├── phases.py            # 昼夜阶段管理（Phase/PhaseManager）
│   ├── vote.py              # 投票系统（讨论、投票、放逐结算）
│   ├── actions.py           # 夜间行动解析与冲突解决
│   ├── win_check.py         # 胜负判定（狼人/好人阵营）
│   └── events.py            # 事件系统（EventBus 松耦合通信）
│
├── config/                  # 配置
│   ├── __init__.py
│   ├── game.py              # 游戏规则配置
│   ├── roles.py             # 角色定义（RoleType/Team/Role 角色注册表）
│   ├── settings.py          # 全局设置
│   └── system_config.json   # LLM 连接配置（base_url/api_key/model）
│
├── schema/                  # 工具模块
│   ├── __init__.py
│   └── system_config.py     # 配置加载器
│
├── llm/                     # LLM 集成层
│   ├── __init__.py
│   ├── client.py            # LLM API 客户端
│   ├── prompts.py           # 提示词模板
│   └── parser.py            # 模型输出解析
│
├── logs/                    # 日志系统
│   ├── __init__.py
│   ├── logger.py            # 结构化日志
│   └── formatter.py         # 日志格式化
│
├── eval/                    # 评测与复盘
│   ├── __init__.py
│   ├── metrics.py           # 评测指标
│   ├── replay.py            # 复盘归因
│   └── leaderboard.py       # 排行榜
│
├── tests/                   # 测试
│   ├── __init__.py
│   ├── test_engine.py
│   ├── test_agents.py
│   ├── test_vote.py
│   └── test_win_check.py
│
└── ui/                      # 前端观战 UI（占位）
    └── __init__.py
```

## Architecture Overview

- **主持人模式**: `engine/game.py` 中的 `GameHost` 是整局游戏的编排者，驱动 night → discussion → vote → elimination 循环。Host 负责：分发角色、控制信息隔离、调用 LLM 收集决策、执行规则、判定胜负。
- **Agent 隔离**: 每个 `BaseAgent` 实例仅接收角色允许的信息。系统提示词（`_build_system_prompt`）在初始化时注入角色身份和阵营信息；每轮决策的 prompt 由 Host 按阶段动态构建。
- **夜间行动解析**: `engine/actions.py` 按优先级顺序（狼人→守卫=预言家→女巫）处理夜间行动，解决冲突（守卫+女巫救同一人、女巫毒药禁用猎人开枪等）。
- **胜负判定**: `engine/win_check.py` 每次淘汰后检测——狼人数 ≥ 好人总数则狼人胜，狼人全灭则好人胜。
- **事件系统**: `engine/events.py` 提供 `EventBus` 发布/订阅，引擎状态变更通过事件通知外部（日志、UI）。
- **Mock 回退**: `agents/base.py` 在 API 调用失败时自动降级为 mock 回复，支持不依赖 LLM 的开发测试。

## Design Principles

- 信息隔离通过 `GameHost` 的 prompt 构建逻辑强制实施，Agent 之间不直接通信
- `GameState` 是全局唯一状态源，Host 按需向各 Agent 披露
- LLM 调用统一在 `BaseAgent.run()` 中，更换模型/供应商只需修改 `system_config.json` 和 SDK 适配层

## Advanced Directions (三选一)

1. **General Agent** — "读懂自己→修改自己→运行自己"自演化系统
2. **评测+复盘** — 多维度量化评测 + 复盘归因 + 不同模型 Agent 排行榜
3. **自进化 Agent** — 对局→分析→优化→再对局循环，持续提升胜率

## Tech Stack

- Python 3.12
- LLM API (Anthropic/OpenAI SDK)
- pytest for testing
