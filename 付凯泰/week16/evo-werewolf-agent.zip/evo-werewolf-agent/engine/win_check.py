from __future__ import annotations

from roles.definition import Team
from engine.state import Player


def check_win(
    alive_players: list[Player],
) -> tuple[bool, Team | None]:
    """
    根据当前存活玩家判断游戏是否结束。

    返回 (game_over, winning_team)：
      - (True, Team.WEREWOLF)  → 狼人阵营获胜
      - (True, Team.VILLAGER)  → 好人阵营获胜
      - (False, None)          → 游戏继续
    """
    werewolf_count = 0
    good_count = 0

    for p in alive_players:
        if p.team == Team.WEREWOLF:
            werewolf_count += 1
        else:
            good_count += 1

    # 狼人获胜：狼人人数 ≥ 存活好人总数（且至少有一个狼人）
    if werewolf_count > 0 and werewolf_count >= good_count:
        return True, Team.WEREWOLF

    # 好人获胜：所有狼人出局
    if werewolf_count == 0:
        return True, Team.VILLAGER

    return False, None


def is_werewolf_victory(alive_players: list[Player]) -> bool:
    over, winner = check_win(alive_players)
    return over and winner == Team.WEREWOLF


def is_good_victory(alive_players: list[Player]) -> bool:
    over, winner = check_win(alive_players)
    return over and winner == Team.VILLAGER
