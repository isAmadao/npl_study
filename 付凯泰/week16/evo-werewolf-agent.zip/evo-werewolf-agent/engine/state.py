from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from roles.definition import RoleType, Team, Trait, get_role


# ── 玩家状态 ───────────────────────────────────────────────

@dataclass
class Player:
    """玩家运行时状态."""
    player_id: int
    name: str
    role_type: RoleType
    is_alive: bool = True
    trait: Trait = Trait.RANDOM         # 决策特质
    is_poisoned: bool = False           # 被女巫毒杀（猎人不能开枪）
    guarded_last_night: bool = False    # 昨夜是否被守护
    skill_used: dict[str, bool] = field(default_factory=dict)  # 技能可用性标记

    @property
    def team(self) -> Team:
        return get_role(self.role_type).team

    @property
    def role_cn(self) -> str:
        return get_role(self.role_type).name_cn

    def eliminate(self, by_poison: bool = False) -> None:
        self.is_alive = False
        if by_poison:
            self.is_poisoned = True


# ── 游戏全局状态 ────────────────────────────────────────────

@dataclass
class GameState:
    """游戏全局状态，贯穿整局."""
    phase: str = "init"                 # init / night / discussion / vote / next / ended
    day: int = 0
    players: list[Player] = field(default_factory=list)
    eliminated_history: list[dict] = field(default_factory=list)
    night_kill_target: Optional[int] = None
    seer_checks: list[dict] = field(default_factory=list)
    witch_save_used: bool = False
    witch_poison_used: bool = False
    guard_last_target: Optional[int] = None
    winner: Optional[Team] = None

    def alive_players(self) -> list[Player]:
        return [p for p in self.players if p.is_alive]

    def get_player(self, player_id: int) -> Optional[Player]:
        for p in self.players:
            if p.player_id == player_id:
                return p
        return None
