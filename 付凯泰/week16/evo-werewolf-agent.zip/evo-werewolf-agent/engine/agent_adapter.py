"""Agent 适配层 — 兼容不同版本的 BaseAgent 实现."""

from __future__ import annotations

import asyncio
import json
import os
import random
import re
import urllib.request
from typing import Optional

from roles.definition import Trait
from logs.logger import get_logger

_CONFIG_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_CONFIG_PATH = os.path.join(_CONFIG_DIR, "config", "system_config.json")
with open(_CONFIG_PATH) as _f:
    _CONFIG = json.load(_f)


class FallbackAgent:
    """引擎内置 Agent 实现 — 直接通过 HTTP 调用 OpenAI 兼容 API.
    支持决策特质，影响 mock 回复风格.
    """

    def __init__(
        self,
        name: str = "",
        instructions: str = "",
        model: Optional[str] = None,
        trait: Trait = Trait.RANDOM,
    ):
        self.name = name
        self.instructions = instructions
        self.trait = trait
        self._model = model or _CONFIG.get("default_model", "qwen-flash")
        self._api_key = os.environ.get("LLM_API_KEY") or _CONFIG.get("api_key", "")
        self._base_url = _CONFIG.get("base_url", "https://api.openai.com/v1").rstrip("/")
        self._messages: list[dict] = [{"role": "system", "content": instructions}]

    async def run(self, input_str: str) -> str:
        self._messages.append({"role": "user", "content": input_str})
        log = get_logger()
        try:
            reply = await self._call_api()
            self._messages.append({"role": "assistant", "content": reply})
            log.debug("[%s] LLM 回复: %s", self.name, reply[:60])
            return reply
        except Exception as e:
            log.warning("[%s] API 调用失败，使用 mock: %s", self.name, e)
            reply = self._mock_reply(input_str)
            log.debug("[%s] Mock 回复: %s", self.name, reply[:60])
            return reply

    async def _call_api(self) -> str:
        payload = json.dumps({
            "model": self._model,
            "messages": self._messages,
            "temperature": 0.7,
            "max_tokens": 256,
        }).encode()
        req = urllib.request.Request(
            url=f"{self._base_url}/chat/completions",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._api_key}",
            },
            method="POST",
        )
        def _do() -> str:
            with urllib.request.urlopen(req, timeout=30) as resp:
                body = json.loads(resp.read().decode())
            return body["choices"][0]["message"]["content"]
        return await asyncio.to_thread(_do)

    # ── 特质感知的 Mock 回复 ────────────────────────────────

    def _mock_reply(self, input_str: str) -> str:
        ids = re.findall(r"\b(\d+)\b", input_str)
        ids = [int(x) for x in ids if 1 <= int(x) <= 20]

        if "投票" in input_str:
            return self._mock_vote(ids, input_str)
        if "目标" in input_str and ids:
            return self._mock_choose_target(ids)
        if "解药" in input_str:
            return self._mock_witch_save()
        if "毒药" in input_str:
            return self._mock_choose_target(ids) if ids else "0"
        return self._mock_speech(input_str)

    def _mock_choose_target(self, ids: list[int]) -> str:
        """选目标 — 特质影响选择倾向."""
        if self.trait == Trait.CAUTIOUS:
            return str(ids[0])  # 选第一个（最不起眼）
        elif self.trait == Trait.BOLD:
            return str(ids[-1])  # 选最后一个（最显眼）
        else:
            return str(random.choice(ids))

    def _mock_vote(self, ids: list[int], input_str: str) -> str:
        """投票 — 特质影响投票策略."""
        if self.trait == Trait.CAUTIOUS:
            if len(ids) >= 2:
                return str(ids[1])  # 跟风投第二个
            return str(ids[0])
        elif self.trait == Trait.BOLD:
            return str(ids[-1])  # 投最可能出局的（末位）
        else:
            return str(random.choice(ids))

    def _mock_witch_save(self) -> str:
        """女巫救人 — 特质影响决策."""
        if self.trait == Trait.CAUTIOUS:
            return "否"  # 谨慎不轻易救
        elif self.trait == Trait.BOLD:
            return "是"  # 大胆救
        else:
            return random.choice(["是", "否"])

    def _mock_speech(self, input_str: str) -> str:
        """发言 — 特质影响风格."""
        if self.trait == Trait.CAUTIOUS:
            return "我还没什么头绪，再听听大家的看法吧。"
        elif self.trait == Trait.BOLD:
            return "我怀疑{0}号有问题，大家注意一下。".format(random.randint(1, 9))
        else:
            return "我暂时没有特别的信息，先听听大家的看法。"
