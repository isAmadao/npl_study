"""投票系统 — 白天讨论与投票."""

from __future__ import annotations

from collections import Counter
from typing import Optional

from engine.events import game_bus, EVENT_VOTE_RESULT
from engine.state import GameState, Player


def hold_vote(
    state: GameState,
    votes: dict[int, int],  # voter_id → target_id
    day: int = 0,
) -> tuple[Optional[Player], list[int]]:
    """
    执行投票并结算。

    参数：
      votes: {投票者ID: 目标ID}
      day: 当前天数

    返回：
      (被放逐的Player, 平票者ID列表)
      如果平票无人放逐则返回 (None, tie_players)
    """
    if not votes:
        return None, []

    target_counts = Counter(votes.values())
    max_votes = max(target_counts.values())
    top_targets = [pid for pid, count in target_counts.items() if count == max_votes]

    game_bus.emit(EVENT_VOTE_RESULT, votes=votes, top_targets=top_targets)

    if len(top_targets) > 1:
        return None, top_targets

    eliminated_id = top_targets[0]
    eliminated = state.get_player(eliminated_id)
    if eliminated:
        eliminated.is_alive = False
        state.eliminated_history.append({
            "day": day,
            "player_id": eliminated_id,
            "reason": "vote",
        })

    return eliminated, []


def format_vote_prompt(
    state: GameState,
    voter: Player,
    discussion_history: list[str],
    game_summary: str = "",
) -> str:
    """构造投票阶段发送给 Agent 的提示词."""
    alive = state.alive_players()
    alive_str = "\n".join(
        f"  {p.player_id}. {p.name}" for p in alive
    )
    discussion_str = "\n".join(discussion_history[-10:]) if discussion_history else "无"

    body = f"""现在是第{state.day}天投票阶段。

存活玩家：
{alive_str}

讨论记录：
{discussion_str}

请投票选出你要放逐的玩家。只回复玩家ID数字。"""
    return (game_summary + "\n\n" + body) if game_summary else body


def format_speech_prompt(
    state: GameState,
    speaker: Player,
    discussion_history: list[str],
    game_summary: str = "",
) -> str:
    """构造发言阶段发送给 Agent 的提示词."""
    alive = state.alive_players()
    alive_str = "\n".join(
        f"  {p.player_id}. {p.name}" for p in alive
    )
    prev = "\n".join(discussion_history[-5:]) if discussion_history else "无"

    body = f"""现在是第{state.day}天白天讨论阶段，你是{speaker.name}。

存活玩家：
{alive_str}

之前的发言：
{prev}

请发表你的看法，分析局势，指出可疑的人。发言简洁有力。"""
    return (game_summary + "\n\n" + body) if game_summary else body
