"""游戏预设 — 对局参数和默认角色配置."""

import random

from roles.definition import RoleType


DISCUSSION_SECONDS = 120
VOTE_SECONDS = 30
NIGHT_SECONDS = 30
MAX_CONSECUTIVE_SAME_VOTE = 2


# ── 经典角色配比（按人数） ────────────────────────────────
# 每项 = (总人数, [角色列表])
CLASSIC_ROSTERS: dict[int, list[RoleType]] = {
    6: [
        RoleType.WEREWOLF, RoleType.WEREWOLF,
        RoleType.SEER, RoleType.WITCH,
        RoleType.VILLAGER, RoleType.VILLAGER,
    ],
    7: [
        RoleType.WEREWOLF, RoleType.WEREWOLF,
        RoleType.SEER, RoleType.WITCH, RoleType.HUNTER,
        RoleType.VILLAGER, RoleType.VILLAGER,
    ],
    8: [
        RoleType.WEREWOLF, RoleType.WEREWOLF,
        RoleType.SEER, RoleType.WITCH, RoleType.HUNTER, RoleType.GUARD,
        RoleType.VILLAGER, RoleType.VILLAGER,
    ],
    9: [
        RoleType.WEREWOLF, RoleType.WEREWOLF, RoleType.WEREWOLF,
        RoleType.SEER, RoleType.WITCH, RoleType.HUNTER, RoleType.GUARD,
        RoleType.VILLAGER, RoleType.VILLAGER,
    ],
    10: [
        RoleType.WEREWOLF, RoleType.WEREWOLF, RoleType.WEREWOLF,
        RoleType.SEER, RoleType.WITCH, RoleType.HUNTER, RoleType.GUARD,
        RoleType.VILLAGER, RoleType.VILLAGER, RoleType.VILLAGER,
    ],
    12: [
        RoleType.WEREWOLF, RoleType.WEREWOLF, RoleType.WEREWOLF, RoleType.WEREWOLF,
        RoleType.SEER, RoleType.WITCH, RoleType.HUNTER, RoleType.GUARD,
        RoleType.VILLAGER, RoleType.VILLAGER, RoleType.VILLAGER, RoleType.VILLAGER,
    ],
}

# 默认取 9 人局
DEFAULT_ROSTER = CLASSIC_ROSTERS[9]


def get_roster(player_count: int = 9) -> list[RoleType]:
    """获取指定人数的经典角色配比，以随机顺序发牌."""
    if player_count not in CLASSIC_ROSTERS:
        valid = sorted(CLASSIC_ROSTERS.keys())
        raise ValueError(f"不支持 {player_count} 人局，支持人数: {valid}")
    roster = CLASSIC_ROSTERS[player_count].copy()
    random.shuffle(roster)  # 洗牌 = 随机发牌
    return roster


def validate_roster(roster: list[RoleType] | None = None) -> None:
    r: list[RoleType] = roster or DEFAULT_ROSTER
    if len(r) < 4:
        raise ValueError(f"玩家数量至少 4 人，当前 {len(r)} 人")
    wolf_count = sum(1 for rt in r if rt == RoleType.WEREWOLF)
    if wolf_count < 1:
        raise ValueError("至少需要 1 名狼人")
    if len(r) - wolf_count < 1:
        raise ValueError("至少需要 1 名好人")
