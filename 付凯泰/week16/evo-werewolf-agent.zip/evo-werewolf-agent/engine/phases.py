"""阶段管理 — 昼夜阶段流转."""

from __future__ import annotations

from enum import Enum, auto


class Phase(Enum):
    """游戏阶段枚举."""
    INIT = auto()          # 初始化
    NIGHT = auto()         # 夜晚（角色行动）
    DISCUSSION = auto()    # 白天讨论
    VOTE = auto()          # 白天投票
    ELIMINATION = auto()   # 放逐结算
    GAME_OVER = auto()     # 游戏结束


# 阶段流转顺序
PHASE_CYCLE: list[Phase] = [
    Phase.NIGHT,
    Phase.DISCUSSION,
    Phase.VOTE,
    Phase.ELIMINATION,
]


class PhaseManager:
    """管理当前阶段和阶段流转."""

    def __init__(self):
        self._phase = Phase.INIT
        self._day = 0

    @property
    def phase(self) -> Phase:
        return self._phase

    @property
    def day(self) -> int:
        return self._day

    def transition_to(self, phase: Phase) -> None:
        """切换到指定阶段."""
        self._phase = phase

    def next_phase(self) -> Phase:
        """按周期顺序进入下一阶段，跨越天数时 +1."""
        if self._phase == Phase.INIT:
            self._day = 1
            self._phase = Phase.NIGHT
        elif self._phase == Phase.NIGHT:
            self._phase = Phase.DISCUSSION
        elif self._phase == Phase.DISCUSSION:
            self._phase = Phase.VOTE
        elif self._phase == Phase.VOTE:
            self._phase = Phase.ELIMINATION
        elif self._phase == Phase.ELIMINATION:
            self._day += 1
            self._phase = Phase.NIGHT
        elif self._phase == Phase.GAME_OVER:
            pass
        return self._phase

    def end_game(self) -> None:
        self._phase = Phase.GAME_OVER

    def reset(self) -> None:
        self._phase = Phase.INIT
        self._day = 0
