"""事件系统 — 松耦合的发布/订阅通信."""

from __future__ import annotations

from typing import Callable, Any

EventHandler = Callable[..., Any]


class EventBus:
    """简单的事件总线，支持按事件名订阅和发布."""

    def __init__(self):
        self._handlers: dict[str, list[EventHandler]] = {}

    def on(self, event: str, handler: EventHandler) -> None:
        """订阅事件."""
        self._handlers.setdefault(event, []).append(handler)

    def off(self, event: str, handler: EventHandler) -> None:
        """取消订阅."""
        handlers = self._handlers.get(event, [])
        if handler in handlers:
            handlers.remove(handler)

    def emit(self, event: str, **data: Any) -> None:
        """发布事件."""
        for handler in self._handlers.get(event, []):
            handler(**data)

    def clear(self) -> None:
        """清空所有订阅."""
        self._handlers.clear()


# ── 全局事件实例 ───────────────────────────────────────────

game_bus = EventBus()


# ── 事件名常量 ─────────────────────────────────────────────

EVENT_NIGHT_START = "night:start"           # 入夜
EVENT_NIGHT_END = "night:end"               # 天亮
EVENT_PLAYER_KILLED = "player:killed"       # 玩家被刀
EVENT_PLAYER_POISONED = "player:poisoned"   # 玩家被毒
EVENT_PLAYER_SAVED = "player:saved"         # 玩家被救
EVENT_PLAYER_GUARDED = "player:guarded"     # 玩家被守
EVENT_PLAYER_ELIMINATED = "player:eliminated"  # 玩家被放逐
EVENT_HUNTER_SHOT = "hunter:shot"           # 猎人开枪
EVENT_DISCUSSION_START = "discussion:start" # 开始讨论
EVENT_VOTE_START = "vote:start"             # 开始投票
EVENT_VOTE_RESULT = "vote:result"           # 投票结果
EVENT_GAME_OVER = "game:over"               # 游戏结束
