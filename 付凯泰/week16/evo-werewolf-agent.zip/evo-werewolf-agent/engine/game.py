"""游戏主持人 — 编排完整对局流程，协调 LLM Agent 决策."""

from __future__ import annotations

import random
from typing import Optional

from engine.agent_adapter import FallbackAgent as BaseAgent
from engine.presets import DEFAULT_ROSTER, get_roster, validate_roster
from roles.definition import RoleType, Team, Trait, get_role
from engine.actions import resolve_night_actions
from engine.events import (
    game_bus,
    EVENT_NIGHT_START,
    EVENT_NIGHT_END,
    EVENT_GAME_OVER,
    EVENT_PLAYER_ELIMINATED,
    EVENT_DISCUSSION_START,
)
from engine.phases import Phase, PhaseManager
from engine.state import GameState, Player
from engine.vote import hold_vote, format_vote_prompt, format_speech_prompt
from engine.win_check import check_win
from logs.logger import get_logger


class GameHost:
    """游戏主持人 — 驱动整局游戏."""

    def __init__(
        self,
        roster: list[RoleType] | None = None,
        player_names: list[str] | None = None,
        player_count: int | None = None,
        traits: list[Trait] | None = None,
    ):
        if roster is not None:
            validate_roster(roster)
            self.roster = roster
        elif player_count is not None:
            self.roster = get_roster(player_count)
        else:
            self.roster = DEFAULT_ROSTER

        self.state = GameState()
        self.phase_manager = PhaseManager()
        self.agents: dict[int, BaseAgent] = {}
        self.discussion_history: list[str] = []

        # 本轮夜间状态
        self._kill_target: Optional[int] = None
        self._guard_target: Optional[int] = None
        self._seer_target: Optional[int] = None
        self._witch_save: bool = False
        self._witch_poison_target: Optional[int] = None

        self.logger = get_logger()
        self._init_players(player_names, traits)
        self._init_agents()
        self._bind_events()

    # ── 初始化 ──────────────────────────────────────────────

    def _init_players(self, player_names: list[str] | None,
                      traits: list[Trait] | None = None) -> None:
        if player_names and len(player_names) != len(self.roster):
            raise ValueError(f"需要 {len(self.roster)} 个名字，提供了 {len(player_names)} 个")
        if traits and len(traits) != len(self.roster):
            raise ValueError(f"需要 {len(self.roster)} 个特质，提供了 {len(traits)} 个")

        for i, rt in enumerate(self.roster):
            name = player_names[i] if player_names else f"玩家{i + 1}"
            trait = traits[i] if traits else random.choice(list(Trait))
            self.state.players.append(
                Player(player_id=i + 1, name=name, role_type=rt, trait=trait)
            )
        random.shuffle(self.state.players)

    def _init_agents(self) -> None:
        for p in self.state.players:
            instructions = self._build_system_prompt(p)
            self.agents[p.player_id] = BaseAgent(
                name=p.name,
                instructions=instructions,
                trait=p.trait,
            )
        self.logger.info("角色分配: %s",
                         ", ".join(f"{p.name}={p.role_cn}({p.trait.cn})" for p in self.state.players))

    def _bind_events(self) -> None:
        game_bus.on(EVENT_PLAYER_ELIMINATED, self._on_player_eliminated)

    # ── 系统提示词 ──────────────────────────────────────────

    def _build_system_prompt(self, player: Player) -> str:
        role = get_role(player.role_type)
        team_cn = "狼人阵营" if player.team == Team.WEREWOLF else "好人阵营"
        teammates = self._get_teammates(player)

        trait_desc = {
            Trait.CAUTIOUS: "你的风格是谨慎保守的：做决策时倾向于安全选项，发言保持低调，不轻易冒险。",
            Trait.RANDOM: "你的风格是不可预测的：每次决策都让人捉摸不透。",
            Trait.BOLD: "你的风格是大胆激进的：主动出击，强势站边，敢于冒险。",
        }[player.trait]

        lines = [
            f"你是{player.name}，你的身份是：{role.name_cn}。",
            f"所属阵营：{team_cn}",
            f"获胜条件：{role.win_condition}",
            f"角色描述：{role.description}",
            f"\n{trait_desc}",
        ]

        if teammates:
            names = "、".join(f"{p.name}({p.player_id}号)" for p in teammates)
            lines.append(f"你的同伴：{names}")

        lines.append("\n游戏规则：")
        lines.append("- 游戏分为夜晚和白天两个阶段交替进行。")
        lines.append("- 夜晚阶段：有特殊能力的角色可以行动。")
        lines.append("- 白天阶段：所有存活玩家依次发言，然后投票放逐一名玩家。")
        lines.append("- 请根据你的身份和已知信息做出合理决策。")
        lines.append("- 输出格式：只回复你决策的内容，不要包含额外解释。")

        return "\n".join(lines)

    def _get_teammates(self, player: Player) -> list[Player]:
        """获取同一阵营的队友（狼人可见同伴，好人不可见）. """
        if player.team != Team.WEREWOLF:
            return []
        return [
            p for p in self.state.players
            if p.player_id != player.player_id and p.team == Team.WEREWOLF
        ]

    # ── 游戏摘要 ────────────────────────────────────────────

    def _build_game_summary(self, player: Player) -> str:
        """构建游戏进度摘要，注入到每个 Agent 的 prompt 开头."""
        alive = self.state.alive_players()
        total = len(self.state.players)
        day = self.phase_manager.day

        reason_map = {
            "vote": "被放逐", "night_kill": "被刀杀",
            "poison": "被毒杀", "hunter_shot": "被猎人带走",
        }
        time_map = {
            "vote": "天", "night_kill": "晚",
            "poison": "晚", "hunter_shot": "天",
        }

        lines = [
            "=" * 42,
            f"  游戏状态 — 第{day}天 | 存活{len(alive)}/{total}人",
            "=" * 42,
        ]

        # 淘汰记录
        if self.state.eliminated_history:
            lines.append("")
            lines.append("📋 淘汰记录:")
            for entry in self.state.eliminated_history:
                p = self.state.get_player(entry["player_id"])
                if p is None:
                    continue
                d = entry.get("day", "?")
                r = reason_map.get(entry.get("reason", ""), entry.get("reason", ""))
                t = time_map.get(entry.get("reason", ""), "天")
                lines.append(f"  第{d}{t} {p.name}({p.role_cn}) {r}")

        # 夜晚结果摘要
        night_msgs = [s for s in self.discussion_history if s.startswith("【昨晚】")]
        if night_msgs:
            lines.append("")
            for msg in night_msgs[-3:]:
                lines.append(f"  {msg}")

        # 投票结果摘要
        vote_msgs = [s for s in self.discussion_history if s.startswith("【投票结果】")]
        if vote_msgs:
            lines.append("")
            for msg in vote_msgs[-3:]:
                lines.append(f"  {msg}")

        # 预言家个人查验历史
        if player.role_type == RoleType.SEER and self.state.seer_checks:
            lines.append("")
            lines.append("🔍 你的查验记录:")
            for c in self.state.seer_checks:
                lines.append(f"  第{c['day']}晚 → {c['target_name']} = {c['result_role']}")

        lines.append("=" * 42)
        return "\n".join(lines)

    # ── 主循环 ──────────────────────────────────────────────

    async def run_game(self) -> GameState:
        """执行完整对局，返回最终状态."""
        self.logger.info("游戏开始 — %d 名玩家", len(self.state.players))

        while self.phase_manager.phase != Phase.GAME_OVER:
            phase = self.phase_manager.next_phase()
            phase_cn = {"NIGHT": "夜晚", "DISCUSSION": "讨论", "VOTE": "投票", "ELIMINATION": "放逐", "GAME_OVER": "结束"}
            self.logger.info("进入阶段: %s (第%d天)", phase_cn.get(phase.name, phase.name), self.phase_manager.day)
            self.state.day = self.phase_manager.day  # 同步天数到 GameState

            if phase == Phase.NIGHT:
                await self._run_night()
            elif phase == Phase.DISCUSSION:
                await self._run_discussion()
            elif phase == Phase.VOTE:
                await self._run_vote()
            elif phase == Phase.ELIMINATION:
                await self._run_elimination()

            # 每次阶段结束后检查胜负
            if self.state.winner is not None:
                winner_cn = "狼人阵营" if self.state.winner == Team.WEREWOLF else "好人阵营"
                self.logger.info("游戏结束 — %s获胜！", winner_cn)
                self.phase_manager.end_game()
                game_bus.emit(EVENT_GAME_OVER, winner=self.state.winner)

        return self.state

    # ── 夜晚阶段 ────────────────────────────────────────────

    async def _run_night(self) -> None:
        game_bus.emit(EVENT_NIGHT_START, day=self.phase_manager.day)
        self.logger.info("天黑请闭眼 —— 夜间行动开始")
        self._reset_night_state()

        alive_wolves = [p for p in self.state.alive_players()
                        if p.role_type == RoleType.WEREWOLF]
        alive_seer = [p for p in self.state.alive_players()
                      if p.role_type == RoleType.SEER]
        alive_witch = [p for p in self.state.alive_players()
                       if p.role_type == RoleType.WITCH]
        alive_guard = [p for p in self.state.alive_players()
                       if p.role_type == RoleType.GUARD]

        self.logger.debug("存活: 狼人%d 预言家%d 女巫%d 守卫%d",
                          len(alive_wolves), len(alive_seer), len(alive_witch), len(alive_guard))

        # 1. 狼人行动
        if alive_wolves:
            self._kill_target = await self._wolf_action(alive_wolves)
            self.logger.info("狼人刀人目标: %s",
                             self.state.get_player(self._kill_target).name if self._kill_target else "无")

        # 2. 守卫行动
        if alive_guard:
            self._guard_target = await self._guard_action(alive_guard[0])
            self.logger.info("守卫守护目标: %s",
                             self.state.get_player(self._guard_target).name if self._guard_target else "无")

        # 3. 预言家行动
        if alive_seer:
            self._seer_target = await self._seer_action(alive_seer[0])
            self.logger.info("预言家查验目标: %s",
                             self.state.get_player(self._seer_target).name if self._seer_target else "无")

        # 4. 女巫行动
        if alive_witch:
            self._witch_save, self._witch_poison_target = await self._witch_action(
                alive_witch[0], self._kill_target
            )
            self.logger.info("女巫: 救=%s 毒=%s", self._witch_save,
                             self.state.get_player(self._witch_poison_target).name
                             if self._witch_poison_target else "无")

        # 5. 结算
        events = resolve_night_actions(
            self.state,
            kill_target=self._kill_target,
            guard_target=self._guard_target,
            seer_target=self._seer_target,
            witch_save=self._witch_save,
            witch_poison_target=self._witch_poison_target,
            day=self.phase_manager.day,
        )
        self._announce_night_results(events)
        game_bus.emit(EVENT_NIGHT_END, events=events)

    def _reset_night_state(self) -> None:
        for p in self.state.players:
            p.guarded_last_night = False
        self._kill_target = None
        self._guard_target = None
        self._seer_target = None
        self._witch_save = False
        self._witch_poison_target = None

    async def _wolf_action(self, wolves: list[Player]) -> Optional[int]:
        """狼人选择刀人目标。每人独立选择，取多数票."""
        targets = []
        for wolf in wolves:
            prompt = self._build_wolf_prompt(wolf)
            try:
                resp = await self.agents[wolf.player_id].run(prompt)
                choice = self._parse_player_id(resp)
                if choice and self.state.get_player(choice) and \
                   self.state.get_player(choice).is_alive and \
                   self.state.get_player(choice).team != Team.WEREWOLF:
                    targets.append(choice)
                    self.logger.debug("狼人 %s 选择目标 %s", wolf.name,
                                      self.state.get_player(choice).name)
            except Exception as e:
                self.logger.warning("狼人 %s 决策失败: %s", wolf.name, e)

        if not targets:
            self.logger.warning("所有狼人均未选择目标")
            return None
        target_id = max(set(targets), key=targets.count)
        self.logger.debug("狼人多数票目标: %s", self.state.get_player(target_id).name)
        return target_id

    def _build_wolf_prompt(self, wolf: Player) -> str:
        summary = self._build_game_summary(wolf)
        alive = self.state.alive_players()
        others = [p for p in alive if p.team != Team.WEREWOLF]
        wolves = [p for p in alive if p.team == Team.WEREWOLF]
        solo = len(wolves) <= 1
        lines = [
            summary,
            "\n天黑请闭眼。你是狼人，"
            + ("请独自选择今晚要杀的目标。" if solo else "请和同伴商议选择今晚要杀的目标。"),
            "\n可选目标（非狼人玩家）：",
        ]
        for p in others:
            lines.append(f"  {p.player_id}. {p.name}")
        lines.append("\n请回复目标玩家的ID数字。")
        return "\n".join(lines)

    async def _seer_action(self, seer: Player) -> Optional[int]:
        summary = self._build_game_summary(seer)
        alive = [p for p in self.state.alive_players()
                 if p.player_id != seer.player_id]
        lines = [
            summary,
            "\n天黑请闭眼。你是预言家，请选择要查验身份的玩家。",
            "\n可选目标：",
        ]
        for p in alive:
            lines.append(f"  {p.player_id}. {p.name}")
        lines.append("\n请回复目标玩家的ID数字。")

        try:
            resp = await self.agents[seer.player_id].run("\n".join(lines))
            target_id = self._parse_player_id(resp)
            if target_id and self.state.get_player(target_id):
                target = self.state.get_player(target_id)
                role = get_role(target.role_type)
                self.logger.info("预言家查验 %s → %s", target.name, role.name_cn)
                self.state.seer_checks.append({
                    "day": self.phase_manager.day,
                    "target_name": target.name,
                    "result_role": role.name_cn,
                })
                await self.agents[seer.player_id].run(
                    f"查验结果：{target.name} 的身份是 {role.name_cn}。"
                )
                return target_id
        except Exception as e:
            self.logger.warning("预言家决策失败: %s", e)
        return None

    async def _witch_action(
        self, witch: Player, killed_id: Optional[int]
    ) -> tuple[bool, Optional[int]]:
        summary = self._build_game_summary(witch)
        use_save = False
        poison_target = None

        # 告知女巫今晚被杀的人
        if killed_id is not None and not self.state.witch_save_used:
            killed = self.state.get_player(killed_id)
            name = killed.name if killed else "未知"
            prompt = (
                summary + "\n\n"
                + f"天黑请闭眼。今晚被杀的玩家是：{name}({killed_id}号)。\n"
                + ("你有一瓶解药（已使用）。" if self.state.witch_save_used
                   else "你有一瓶解药。是否使用解药救他？回复 是 或 否。")
            )
            try:
                resp = await self.agents[witch.player_id].run(prompt)
                use_save = "是" in resp
                self.logger.info("女巫是否使用解药救 %s: %s", name, "是" if use_save else "否")
            except Exception as e:
                self.logger.warning("女巫解药决策失败: %s", e)

        # 询问是否使用毒药
        if not self.state.witch_poison_used:
            alive = [p for p in self.state.alive_players()
                     if p.player_id != witch.player_id]
            lines = [summary, "\n你是否使用毒药？"]
            for p in alive:
                lines.append(f"  {p.player_id}. {p.name}")
            lines.append("回复格式：毒药目标ID（不用毒则回复 0）")
            try:
                resp = await self.agents[witch.player_id].run("\n".join(lines))
                tid = self._parse_player_id(resp)
                if tid and self.state.get_player(tid) and \
                   self.state.get_player(tid).is_alive:
                    poison_target = tid
                    self.logger.info("女巫使用毒药: %s", self.state.get_player(tid).name)
            except Exception as e:
                self.logger.warning("女巫毒药决策失败: %s", e)

        return use_save, poison_target

    async def _guard_action(self, guard: Player) -> Optional[int]:
        summary = self._build_game_summary(guard)
        alive = [p for p in self.state.alive_players()
                 if p.player_id != guard.player_id]
        lines = [
            summary,
            "\n天黑请闭眼。你是守卫，请选择要守护的玩家。",
        ]
        if self.state.guard_last_target is not None:
            lines.append(f"（上一晚你守护了{self.state.guard_last_target}号，不能连续守护同一人）")
        lines.append("\n可选目标：")
        for p in alive:
            if p.player_id != self.state.guard_last_target:
                lines.append(f"  {p.player_id}. {p.name}")
        lines.append("\n请回复目标玩家的ID数字。")

        try:
            resp = await self.agents[guard.player_id].run("\n".join(lines))
            tid = self._parse_player_id(resp)
            if tid and self.state.get_player(tid) and \
               self.state.get_player(tid).is_alive and \
               tid != self.state.guard_last_target:
                self.logger.info("守卫守护 %s", self.state.get_player(tid).name)
                return tid
        except Exception as e:
            self.logger.warning("守卫决策失败: %s", e)
        return None

    def _announce_night_results(self, events: list[dict]) -> None:
        dead_ids = []
        for ev in events:
            if ev["type"] in ("player:killed", "player:poisoned"):
                dead_ids.append(ev["player_id"])
        if dead_ids:
            dead_info = "、".join(
                f"{self.state.get_player(pid).name}({self.state.get_player(pid).role_cn})"
                for pid in dead_ids if self.state.get_player(pid)
            )
            self.logger.info("昨晚死亡: %s", dead_info)
            self.discussion_history.append(f"【昨晚】{dead_info}死亡。")
        else:
            self.logger.info("昨晚是平安夜")
            self.discussion_history.append("【昨晚】昨晚是平安夜。")

    # ── 白天讨论 ────────────────────────────────────────────

    async def _run_discussion(self) -> None:
        game_bus.emit(EVENT_DISCUSSION_START, day=self.phase_manager.day)
        alive = self.state.alive_players()
        self.logger.info("白天讨论开始，%d 名玩家发言", len(alive))

        for speaker in alive:
            summary = self._build_game_summary(speaker)
            prompt = format_speech_prompt(self.state, speaker, self.discussion_history, summary)
            try:
                speech = await self.agents[speaker.player_id].run(prompt)
                if speech:
                    record = f"{speaker.name}说：{speech}"
                    self.discussion_history.append(record)
                    self.logger.info("%s 发言: %s", speaker.name, speech[:80])
            except Exception as e:
                self.logger.warning("%s 发言失败: %s", speaker.name, e)
                self.discussion_history.append(f"{speaker.name}说：...")

    # ── 投票 ────────────────────────────────────────────────

    async def _run_vote(self) -> None:
        alive = self.state.alive_players()
        votes: dict[int, int] = {}
        self.logger.info("投票开始")

        for voter in alive:
            summary = self._build_game_summary(voter)
            prompt = format_vote_prompt(self.state, voter, self.discussion_history, summary)
            try:
                resp = await self.agents[voter.player_id].run(prompt)
                target_id = self._parse_player_id(resp)
                target = self.state.get_player(target_id) if target_id else None
                if target and target.is_alive:
                    votes[voter.player_id] = target_id
                    self.logger.debug("%s 投票给 %s", voter.name, target.name)
            except Exception as e:
                self.logger.warning("%s 投票失败: %s", voter.name, e)

        eliminated, tie_ids = hold_vote(self.state, votes, day=self.phase_manager.day)
        if eliminated:
            self.logger.info("投票结果: %s 被放逐", eliminated.name)
            self.discussion_history.append(
                f"【投票结果】{eliminated.name}({eliminated.role_cn})被放逐。"
            )
        elif tie_ids:
            self.logger.info("投票平局: %s", [self.state.get_player(i).name for i in tie_ids])

    # ── 放逐结算 ────────────────────────────────────────────

    async def _run_elimination(self) -> None:
        last = self.state.eliminated_history[-1] if self.state.eliminated_history else None
        if not last or last.get("reason") != "vote":
            return

        pid = last["player_id"]
        player = self.state.get_player(pid)
        if not player:
            return

        self.logger.info("放逐结算: %s(%s)", player.name, player.role_cn)

        # 猎人开枪
        if player.role_type == RoleType.HUNTER and not player.is_poisoned:
            self.logger.info("%s 是猎人，触发开枪", player.name)
            await self._hunter_shot(player)

        # 胜负判定
        alive = self.state.alive_players()
        over, winner = check_win(alive)
        if over:
            self.state.winner = winner

    async def _hunter_shot(self, hunter: Player) -> None:
        alive = self.state.alive_players()
        targets = [p for p in alive if p.player_id != hunter.player_id]
        if not targets:
            return

        summary = self._build_game_summary(hunter)
        lines = [summary, "\n你被放逐了！你可以开枪带走一名玩家。选择你的目标："]
        for p in targets:
            lines.append(f"  {p.player_id}. {p.name}")
        lines.append("请回复目标玩家的ID数字。")

        try:
            resp = await self.agents[hunter.player_id].run("\n".join(lines))
            tid = self._parse_player_id(resp)
            target = self.state.get_player(tid) if tid else None
            if target and target.is_alive:
                target.eliminate()
                self.state.eliminated_history.append({
                    "day": self.phase_manager.day,
                    "player_id": tid,
                    "reason": "hunter_shot",
                })
                self.logger.info("猎人开枪带走 %s", target.name)
                self.discussion_history.append(
                    f"{hunter.name}开枪带走了{target.name}({target.role_cn})！"
                )
        except Exception as e:
            self.logger.warning("猎人开枪失败: %s", e)

    # ── 事件回调 ────────────────────────────────────────────

    def _on_player_eliminated(self, player_id: int, **_kwargs) -> None:
        player = self.state.get_player(player_id)
        if player and player.role_type == RoleType.HUNTER and not player.is_poisoned:
            pass  # 已在 _run_elimination 中处理

    # ── 工具方法 ────────────────────────────────────────────

    @staticmethod
    def _parse_player_id(text: str) -> Optional[int]:
        """从 LLM 回复中提取玩家 ID 数字."""
        if not text:
            return None
        # 提取第一个连续数字
        import re
        match = re.search(r"\d+", text.strip())
        return int(match.group()) if match else None

    def get_role_info(self) -> dict[int, str]:
        """返回 {player_id: role_name} 映射，用于日志/UI. """
        return {p.player_id: p.role_cn for p in self.state.players}

    def get_status(self) -> dict:
        """返回游戏当前状态摘要，用于日志/UI. """
        return {
            "phase": self.phase_manager.phase.name,
            "day": self.phase_manager.day,
            "alive": [{"id": p.player_id, "name": p.name} for p in self.state.alive_players()],
            "winner": self.state.winner.value if self.state.winner else None,
            "history": self.state.eliminated_history,
        }
