"""行动解析 — 夜间行动处理与冲突解决."""

from __future__ import annotations

from typing import Optional

from roles.definition import Team
from engine.events import (
    game_bus,
    EVENT_PLAYER_KILLED,
    EVENT_PLAYER_SAVED,
    EVENT_PLAYER_GUARDED,
    EVENT_PLAYER_POISONED,
)
from engine.state import GameState
from engine.win_check import check_win


class Action:
    """一次夜间行动的记录."""
    def __init__(
        self,
        actor_id: int,
        action_type: str,
        target_id: Optional[int] = None,
    ):
        self.actor_id = actor_id
        self.action_type = action_type
        self.target_id = target_id


def resolve_night_actions(
    state: GameState,
    kill_target: Optional[int],
    guard_target: Optional[int],
    seer_target: Optional[int],
    witch_save: bool,
    witch_poison_target: Optional[int],
    day: int = 0,
) -> list[dict]:
    """
    解析夜间所有行动，决定谁死亡、谁被救、谁被查验。

    返回事件列表，每项包含 type/player_id 等字段供日志和通知使用。
    """
    events: list[dict] = []
    actual_dead: Optional[int] = None

    # 1. 守卫保护
    if guard_target is not None:
        target = state.get_player(guard_target)
        if target and target.is_alive:
            target.guarded_last_night = True
            state.guard_last_target = guard_target
            events.append({"type": EVENT_PLAYER_GUARDED, "player_id": guard_target})

    # 2. 狼人刀人
    killed = None
    if kill_target is not None:
        victim = state.get_player(kill_target)
        if victim and victim.is_alive:
            killed = kill_target

    # 3. 女巫解药
    if witch_save and killed is not None:
        victim = state.get_player(killed)
        if victim and victim.guarded_last_night:
            events.append({"type": EVENT_PLAYER_SAVED, "player_id": killed, "by": "guard"})
            actual_dead = None
        elif victim:
            victim.guarded_last_night = False
            events.append({"type": EVENT_PLAYER_SAVED, "player_id": killed, "by": "witch"})
            actual_dead = None
            state.witch_save_used = True
    elif killed is not None:
        victim = state.get_player(killed)
        if victim and victim.guarded_last_night:
            actual_dead = None
        else:
            actual_dead = killed
            victim = state.get_player(actual_dead)
            if victim:
                victim.eliminate()
                events.append({"type": EVENT_PLAYER_KILLED, "player_id": actual_dead})
                state.eliminated_history.append({
                    "day": day, "player_id": actual_dead, "reason": "night_kill",
                })

    # 4. 女巫毒药
    if witch_poison_target is not None:
        target = state.get_player(witch_poison_target)
        if target and target.is_alive:
            target.eliminate(by_poison=True)
            events.append({"type": EVENT_PLAYER_POISONED, "player_id": witch_poison_target})
            state.witch_poison_used = True
            state.eliminated_history.append({
                "day": day, "player_id": witch_poison_target, "reason": "poison",
            })

    # 5. 胜利判定
    alive = state.alive_players()
    over, winner = check_win(alive)
    if over:
        state.winner = winner

    return events


def validate_night_action(
    state: GameState,
    player_id: int,
    target_id: Optional[int],
    action_type: str,
) -> str:
    """
    校验夜间行动是否合法，返回空字符串表示合法，否则返回错误信息.
    """
    player = state.get_player(player_id)
    if not player or not player.is_alive:
        return "玩家已死亡"

    if action_type == "kill":
        target = state.get_player(target_id) if target_id else None
        if not target or not target.is_alive:
            return "目标无效或已死亡"
        if target.team == Team.WEREWOLF:
            return "不能刀同伴"

    elif action_type == "guard":
        target = state.get_player(target_id) if target_id else None
        if not target or not target.is_alive:
            return "守护目标无效或已死亡"
        if state.guard_last_target == target_id:
            return "不能连续两晚守护同一人"

    elif action_type == "poison":
        if state.witch_poison_used:
            return "毒药已使用"

    return ""
