"""
AI 狼人杀 — 对局演示脚本

运行一局完整游戏，记录每个角色的决策和发言过程，
输出结构化日志供后续分析和学习。
"""

import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from logs.recorder import run_demo

if __name__ == "__main__":
    asyncio.run(run_demo(player_count=8))
