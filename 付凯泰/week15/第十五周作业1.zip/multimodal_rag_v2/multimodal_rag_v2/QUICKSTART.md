# 多模态RAG聊天机器人 - 快速开始

## 项目概述

这是一个基于多模态检索增强生成（RAG）技术的智能问答系统，能够处理包含文本和图像的PDF文档，并基于文档内容进行智能问答。

## 系统架构

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Streamlit  │────▶│  FastAPI    │────▶│   Worker    │
│  Web界面    │     │  Backend    │     │  离线处理   │
└─────────────┘     └─────────────┘     └─────────────┘
                           │                   │
                           ▼                   ▼
                    ┌─────────────┐     ┌─────────────┐
                    │   Milvus    │     │   MinerU    │
                    │  向量数据库  │     │  文档解析   │
                    └─────────────┘     └─────────────┘
```

## 快速启动

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置服务

编辑 `config.yaml` 文件，配置以下服务：

- **Milvus**: Zilliz Cloud向量数据库（已配置）
- **Kafka**: 本地Kafka服务（默认localhost:9092）
- **MinerU**: 文档解析服务（默认http://127.0.0.1:30000）
- **Qwen API**: 阿里云通义千问API（已配置）

### 3. 启动服务

#### 3.1 启动FastAPI后端服务

```bash
cd 05-multimodal-rag-chatbot
python main.py
```

或使用uvicorn：

```bash
uvicorn main:app --reload --port 8000
```

#### 3.2 启动离线处理Worker

```bash
cd 05-multimodal-rag-chatbot
python worker/offline_worker.py
```

#### 3.3 启动Web界面

```bash
cd 05-multimodal-rag-chatbot
streamlit run web/web_demo.py --server.port 8501
```

### 4. 访问系统

- **Web界面**: http://localhost:8501
- **API文档**: http://localhost:8000/docs

## 使用流程

### 1. 上传文档

1. 打开Web界面
2. 选择"文档上传"功能
3. 选择PDF文件并上传
4. 系统自动解析文档（可在"文档管理"查看进度）

### 2. 智能问答

1. 选择"智能问答"功能
2. 输入问题
3. 系统检索相关文档并生成答案
4. 查看答案和参考来源

## API接口

### 文档上传
```bash
curl -X POST "http://localhost:8000/upload/document" \
  -F "file=@example.pdf"
```

### 文档列表
```bash
curl "http://localhost:8000/documents?page=1&page_size=10"
```

### 智能问答
```bash
curl -X POST "http://localhost:8000/chat" \
  -H "Content-Type: application/json" \
  -d '{"question": "你的问题", "top_k": 5}'
```

## 运行测试

```bash
cd 05-multimodal-rag-chatbot
python -m pytest tests/ -v
```

## 项目结构

```
05-multimodal-rag-chatbot/
├── main.py                 # FastAPI主程序
├── config.yaml             # 配置文件
├── requirements.txt        # 依赖列表
├── app/
│   ├── api/                # API接口
│   ├── core/               # 核心模块（配置、数据库、模型）
│   └── services/           # 服务层（解析、存储、检索、问答）
├── worker/
│   └── offline_worker.py   # 离线处理worker
├── web/
│   └── web_demo.py         # Streamlit Web界面
└── tests/                  # 测试用例
```

## 技术栈

- **后端框架**: FastAPI
- **Web界面**: Streamlit
- **向量数据库**: Milvus (Zilliz Cloud)
- **消息队列**: Kafka
- **文档解析**: MinerU
- **文本编码**: BGE (sentence-transformers)
- **多模态编码**: CLIP (jina-clip-v2)
- **大语言模型**: Qwen-plus / Qwen-VL

