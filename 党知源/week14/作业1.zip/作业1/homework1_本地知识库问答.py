"""
作业1：基于 LangChain 的「本地知识库文档检索 + LLM 回答」最小流程。

与课堂代码一致：使用 langchain_openai 的 ChatOpenAI（默认百炼 DashScope 兼容端点）。
流程对齐参考项目（检索 → 将资料写入提示词 → 大模型生成）。

运行前（请在 Week14/作业/作业1 目录下）：
  pip install -r requirements-homework1.txt

环境变量（二选一配置即可）：
  DASHSCOPE_API_KEY  或  OPENAI_API_KEY  —— 与课堂相同的 API Key
可选：
  DASHSCOPE_BASE_URL   默认 https://dashscope.aliyuncs.com/compatible-mode/v1
  LLM_MODEL            默认 qwen-flash
  EMBEDDING_MODEL      默认 text-embedding-v3（需与当前账号支持的向量模型一致）

用法：
  python homework1_本地知识库问答.py
  python homework1_本地知识库问答.py "工作满8年有多少天年假？"
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings


def split_text_with_overlap(text: str, chunk_size: int, chunk_overlap: int) -> list[str]:
    """与参考项目一致的定长滑动窗口切分，避免 langchain_text_splitters 在部分环境拖入 nltk/scipy。"""
    if chunk_overlap >= chunk_size:
        chunk_overlap = max(0, chunk_size // 8)
    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunks.append(text[start:end])
        if end >= len(text):
            break
        start = start + chunk_size - chunk_overlap
    return chunks


def split_documents(
    docs: list[Document],
    chunk_size: int = 400,
    chunk_overlap: int = 40,
) -> list[Document]:
    splits: list[Document] = []
    for doc in docs:
        for piece in split_text_with_overlap(doc.page_content, chunk_size, chunk_overlap):
            if piece.strip():
                splits.append(Document(page_content=piece, metadata=doc.metadata))
    return splits


def _kb_dir() -> Path:
    return Path(__file__).resolve().parent / "knowledge_homework1"


def _env_api_key() -> str:
    return os.getenv("DASHSCOPE_API_KEY") or os.getenv("OPENAI_API_KEY") or ""


def _env_base_url() -> str:
    return os.getenv(
        "DASHSCOPE_BASE_URL",
        "https://dashscope.aliyuncs.com/compatible-mode/v1",
    )


def load_local_documents(knowledge_dir: Path) -> list:
    """递归读取目录下所有 .txt，避免 DirectoryLoader 在部分环境下拖入 nltk/scipy 依赖链。"""
    if not knowledge_dir.is_dir():
        raise FileNotFoundError(f"知识库目录不存在: {knowledge_dir}")

    docs: list[Document] = []
    for path in sorted(knowledge_dir.rglob("*.txt")):
        text = path.read_text(encoding="utf-8")
        docs.append(
            Document(
                page_content=text,
                metadata={"source": str(path.relative_to(knowledge_dir))},
            )
        )
    if not docs:
        raise ValueError(
            f"目录中未找到 .txt 文件，请将资料放入: {knowledge_dir}"
        )
    return docs


def build_retriever(docs: list, embeddings: OpenAIEmbeddings, k: int = 4):
    splits = split_documents(docs, chunk_size=400, chunk_overlap=40)
    vectorstore = FAISS.from_documents(splits, embeddings)
    return vectorstore.as_retriever(search_kwargs={"k": k})


def format_docs(docs) -> str:
    return "\n\n---\n\n".join(d.page_content for d in docs)


def build_rag_chain(retriever, llm: ChatOpenAI):
    # 与参考项目思路一致：先检索，再把「资料 + 问题」交给模型
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "你是严谨的知识库问答助手。只能根据用户提供的「资料」回答问题；"
                "若资料中没有相关信息，请明确回答：根据现有资料无法回答。不要编造资料中不存在的内容。",
            ),
            (
                "human",
                "资料：\n{context}\n\n问题：{question}",
            ),
        ]
    )

    return (
        {
            "context": retriever | format_docs,
            "question": RunnablePassthrough(),
        }
        | prompt
        | llm
        | StrOutputParser()
    )


def answer_question(question: str, llm: ChatOpenAI, embeddings: OpenAIEmbeddings) -> str:
    docs = load_local_documents(_kb_dir())
    retriever = build_retriever(docs, embeddings)
    chain = build_rag_chain(retriever, llm)
    return chain.invoke(question)


def main() -> None:
    api_key = _env_api_key()
    if not api_key:
        print(
            "请先设置环境变量 DASHSCOPE_API_KEY 或 OPENAI_API_KEY（与课堂使用的 Key 相同）。",
            file=sys.stderr,
        )
        sys.exit(1)

    base_url = _env_base_url()
    llm_model = os.getenv("LLM_MODEL", "qwen-flash")
    emb_model = os.getenv("EMBEDDING_MODEL", "text-embedding-v3")

    llm = ChatOpenAI(
        model=llm_model,
        base_url=base_url,
        api_key=api_key,
        temperature=0.2,
    )
    embeddings = OpenAIEmbeddings(
        model=emb_model,
        base_url=base_url,
        api_key=api_key,
    )

    q = (
        sys.argv[1]
        if len(sys.argv) > 1
        else "工作满8年的员工年休假有多少天？请只依据资料说明。"
    )
    print("问题:", q)
    print("-" * 60)
    out = answer_question(q, llm, embeddings)
    print(out)


if __name__ == "__main__":
    main()
