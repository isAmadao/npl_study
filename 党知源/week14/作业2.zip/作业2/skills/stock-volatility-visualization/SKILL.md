---
name: stock-volatility-visualization
description: 用于股票 OHLC 数据：在同一图中绘制「日波动」与「周波动」曲线，并基于波动在历史中的相对强弱输出启发式买卖时间参考。当用户需要波动可视化、择时讨论时启用。
---

# 股票波动可视化 Skill

## 何时使用

- 用户提供了（或需要读取）包含 `date, open, high, low, close` 的 CSV 行情数据
- 需要在**一张图**里同时观察**日尺度波动**与**周尺度波动**
- 需要基于波动「相对大小」给出**教学用**的买入/卖出/观望时间窗口文字建议

## 指标定义（作业约定）

1. **日波动**：收盘价的对数收益 `log(close_t/close_{t-1})`，在 **5 个交易日** 窗口上计算滚动标准差（越大表示短期震荡越强）。
2. **周波动**：按**自然周**（周日至周六，`W-SUN`）分组，对周内各交易日的对数收益求**标准差**，再将该值赋给该周内每个交易日，用于与日线对齐绘图（右 Y 轴）。
3. **同图展示**：使用 **matplotlib 双 Y 轴**（`twinx`）：左轴日波动、右轴周波动，共享 X 轴日期。

## 运行方式（必须）

在 **`作业/作业2`** 目录下已提供示例数据 `data/sample_ohlc.csv`。

```bash
python skills/stock-volatility-visualization/volatility_plot.py --csv data/sample_ohlc.csv --out skills/stock-volatility-visualization/volatility_chart.png
```

- 必须先 `matplotlib.use('Agg')` 再 `import pyplot`（脚本已内置，勿删）。
- 输出 PNG 后，在支持图片预览的环境中打开 `volatility_chart.png` 查看。

## 买卖时间建议逻辑（启发式）

由 `volatility_plot.py` 中 `suggest_timing` 实现，规则摘要：

| 条件（相对全样本分位/中位数） | 文字倾向（非投资建议） |
|------------------------------|-------------------------|
| 日波动 ≥ 75% 分位 且 周波动 ≥ 周波动中位数 | 不宜追高；已持仓偏观望或控制加仓 |
| 仅日波动 ≥ 75% 分位 | 等待波动回落后再评估入场/加仓 |
| 日、周波动均 ≤ 各自偏低水平，且近 5 日跌幅明显 | 波动收敛+回调：可关注分批低吸窗口（非买入指令） |
| 日、周波动均偏低但价格未明显回调 | 低波动阶段：注意低波动后可能突变 |
| 其余 | 中性，继续跟踪波动突破或收敛 |

脚本末尾会打印完整中文说明，并附带**非投资建议**声明。

## 依赖

- `pandas`, `numpy`, `matplotlib`（见 `作业/作业2/requirements-homework2.txt`）
- 若运行时报 **NumPy 2.x 与 matplotlib 不兼容**，请先执行：`pip install "numpy>=1.26,<2"` 再安装本目录依赖。
- 若 `pip install` 出现 **Read timed out**，可重试或加大超时：`pip install --default-timeout=1000 -r requirements-homework2.txt`，或配置国内 PyPI 镜像后再安装。

## 扩展

- 可将 `--csv` 换成真实行情导出文件（列名保持一致）。
- 若需接入 Agent：将本目录作为 skill 目录挂载，或由工具函数 `subprocess` 调用上述命令并读取 PNG 与 stdout 建议文本。
