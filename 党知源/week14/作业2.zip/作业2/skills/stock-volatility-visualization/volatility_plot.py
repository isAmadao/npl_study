"""
股票日/周波动同图可视化 + 基于波动相对强弱的启发式买卖时间建议（课程演示，非投资建议）。
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def _configure_fonts() -> None:
    plt.rcParams.update(
        {
            "figure.dpi": 100,
            "savefig.dpi": 150,
            "axes.grid": True,
            "grid.alpha": 0.3,
        }
    )
    # Windows 常见中文字体
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial"]
    plt.rcParams["axes.unicode_minus"] = False


def load_ohlc(csv_path: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path, parse_dates=["date"]).sort_values("date")
    df.set_index("date", inplace=True)
    return df


def daily_volatility(close: pd.Series, window: int = 5) -> pd.Series:
    """日波动：收盘对数收益的 rolling 标准差（window 个交易日）。"""
    log_ret = np.log(close / close.shift(1))
    return log_ret.rolling(window=window, min_periods=window).std()


def weekly_volatility(close: pd.Series) -> pd.Series:
    """自然周：周内日对数收益的标准差，索引为当周周一；再按日对齐到主时间轴。"""
    log_ret = np.log(close / close.shift(1))
    tmp = log_ret.to_frame("lr")
    tmp["week"] = tmp.index.to_period("W-SUN")
    weekly = tmp.groupby("week")["lr"].std()
    # 将每周波动映射到该周内的每个交易日
    aligned = pd.Series(index=close.index, dtype=float)
    for ts in close.index:
        w = ts.to_period("W-SUN")
        aligned.loc[ts] = weekly.get(w, np.nan)
    return aligned


def suggest_timing(
    daily_vol: pd.Series,
    weekly_vol: pd.Series,
    close: pd.Series,
) -> str:
    """
    根据「当前波动在历史中的相对位置」给出启发式时间建议（非投资建议）。
    """
    dv = daily_vol.dropna()
    wv = weekly_vol.dropna()
    if len(dv) < 10 or len(wv) < 3:
        return "数据过短，无法给出波动相对强弱的参考结论。"

    last_d = float(dv.iloc[-1])
    last_w = float(wv.iloc[-1])
    q75_d, q25_d = float(dv.quantile(0.75)), float(dv.quantile(0.25))
    med_w = float(wv.median())

    ret_5d = float(close.iloc[-1] / close.iloc[-6] - 1) if len(close) > 6 else 0.0

    lines: list[str] = []

    # 波动放大：偏风险、避免追高
    if last_d >= q75_d and last_w >= med_w:
        lines.append(
            "当前**日波动**处于历史较高分位，且**周波动**不低于中位数："
            "短期不确定性偏大，模型倾向**不宜追高**；若已持仓，可优先考虑**观望或控制加仓节奏**。"
        )
    elif last_d >= q75_d:
        lines.append(
            "当前**日波动**明显偏高：更适合等待波动**回落后再评估**入场或加仓窗口。"
        )

    # 波动收敛 + 近期下跌：可关注左侧布局（仍非投资建议）
    if last_d <= q25_d and last_w <= med_w and ret_5d < -0.02:
        lines.append(
            "日、周波动均相对**收敛**，且近几个交易日价格有所回调："
            "从波动角度更接近**分批关注低吸窗口**（需结合基本面与趋势，**非买入指令**）。"
        )
    elif last_d <= q25_d and last_w <= med_w:
        lines.append(
            "日、周波动均处于相对**低位**：若价格处于横盘或温和上行，可视为**波动风险较低阶段**；"
            "若价格急涨则需警惕**低波动后的突变**。"
        )

    if not lines:
        lines.append(
            "日、周波动处于中性区间：模型**不给出明确偏向**的择时结论，建议继续跟踪波动是否向上突破或向下收敛。"
        )

    lines.append(
        "\n【声明】以上为教学用**启发式规则**，不构成任何证券投资建议；实盘请遵守法规并自行判断。"
    )
    return "\n".join(lines)


def plot_volatility(
    df: pd.DataFrame,
    out_path: Path,
    daily_window: int = 5,
) -> str:
    close = df["close"]
    daily = daily_volatility(close, window=daily_window)
    weekly = weekly_volatility(close)

    _configure_fonts()
    fig, ax1 = plt.subplots(figsize=(11, 5.5))

    ax1.set_xlabel("日期")
    ax1.set_ylabel("日波动（对数收益滚动标准差）", color="#0173B2")
    (l1,) = ax1.plot(
        daily.index,
        daily.values,
        color="#0173B2",
        linewidth=1.8,
        label=f"日波动（{daily_window}日滚动）",
    )
    ax1.tick_params(axis="y", labelcolor="#0173B2")

    ax2 = ax1.twinx()
    ax2.set_ylabel("周波动（周内日收益标准差）", color="#DE8F05")
    (l2,) = ax2.plot(
        weekly.index,
        weekly.values,
        color="#DE8F05",
        linewidth=1.5,
        linestyle="--",
        alpha=0.9,
        label="周波动（按自然周聚合）",
    )
    ax2.tick_params(axis="y", labelcolor="#DE8F05")

    ax1.set_title("股票日波动与周波动（同一坐标系：左轴日 / 右轴周）")

    lines = [l1, l2]
    labels = [ln.get_label() for ln in lines]
    ax1.legend(lines, labels, loc="upper left", framealpha=0.92)

    fig.autofmt_xdate()
    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, bbox_inches="tight", facecolor="white")
    plt.close()

    return suggest_timing(daily, weekly, close)


def main() -> None:
    parser = argparse.ArgumentParser(description="Stock daily/weekly volatility plot + heuristic note.")
    parser.add_argument(
        "--csv",
        type=Path,
        default=Path(__file__).resolve().parents[2] / "data" / "sample_ohlc.csv",
        help="OHLC CSV with columns: date,open,high,low,close",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(__file__).resolve().parent / "volatility_chart.png",
        help="Output PNG path",
    )
    args = parser.parse_args()

    df = load_ohlc(args.csv)
    advice = plot_volatility(df, args.out)
    print(advice)
    print(f"\n图表已保存: {args.out.resolve()}")


if __name__ == "__main__":
    main()
