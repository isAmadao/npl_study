from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPT = ROOT / "skills" / "stock-volatility-visualization" / "volatility_plot.py"
CSV = ROOT / "data" / "sample_ohlc.csv"
OUT = ROOT / "skills" / "stock-volatility-visualization" / "volatility_chart.png"


def main() -> None:
    cmd = [
        sys.executable,
        str(SCRIPT),
        "--csv",
        str(CSV),
        "--out",
        str(OUT),
    ]
    subprocess.run(cmd, check=True)


if __name__ == "__main__":
    main()
