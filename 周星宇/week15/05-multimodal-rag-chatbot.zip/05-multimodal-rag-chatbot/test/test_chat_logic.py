import unittest
import os
import sys

# 将上级目录加入系统路径，以便导入 web_page_chat 模块
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))



from web_page_chat import fix_image_path


class TestChatLogic(unittest.TestCase):

    def test_fix_image_path(self):
        """测试图片路径修复逻辑是否符合预期"""
        # 模拟从数据库取出的原始文本和文件路径
        raw_text = "这是一个图表 ![柱状图](images/chart_01.png) 的详细分析。"
        file_path = "/data/documents/2023_sales_report.pdf"

        # 调用修复函数
        fixed_text = fix_image_path(raw_text, file_path)

        # 期望的路径
        expected_path = "demo.png"

        self.assertIn(expected_path, fixed_text, "图片路径修复失败！")
        print(f"✅ 路径修复测试通过：{expected_path}")

    def test_vector_dimension_mock(self):
        """模拟测试向量编码的维度（防止模型更换后维度不匹配导致数据库报错）"""
        # 在实际开发中，这里可以加载真实的 bge_model 进行断言
        # 假设 BGE 的维度是 512 (bge-small-zh)
        mock_bge_dimension = 512
        mock_clip_dimension = 512  # 假设 CLIP 也是 512

        # 这里仅作逻辑演示：确保你的 Milvus 数据库字段维度与模型输出一致
        self.assertEqual(mock_bge_dimension, 512, "BGE模型维度与预期不符，请检查 Milvus Schema！")
        print("✅ 向量维度预期检查通过")


if __name__ == '__main__':
    unittest.main()