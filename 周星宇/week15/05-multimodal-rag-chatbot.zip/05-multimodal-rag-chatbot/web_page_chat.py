import streamlit as st
import openai
import os
import re
import traceback
from sentence_transformers import SentenceTransformer
from pymilvus import MilvusClient

def fix_image_path(text, file_path):
    file_dir = os.path.basename(file_path).split(".")[0]
    return text.replace("images/", f"./processed/{file_dir}/vlm/images/")
# ================== 配置区 ==================
# 设置 HuggingFace 镜像（加速模型下载）
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

# 初始化 Qwen 客户端 (阿里云百炼/灵积)
qwen_client = openai.OpenAI(
    api_key="sk-711c186f74494136ba26035be25a7cb8",  # 请确保这是有效的 API Key
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
)

# RAG 提示词模板 (优化了逻辑，要求模型必须基于资料回答)
rag_prompt = """你是一个专业的AI助手。请严格基于提供的参考资料回答用户的问题。

**用户问题：**
{0}

**参考资料：**
{1}

**回答要求：**
1. 回答必须客观、有逻辑，且完全基于参考资料。
2. 如果资料中包含图片链接，请保留原始链接，并将其放置在与之相关的文本内容旁边。
3. 如果参考资料中没有相关信息，请直接回答“未找到相关信息”。
"""

# ================== 初始化组件 ==================
# 1. 加载 Embedding 模型 (BGE 用于文本检索，CLIP 用于图文跨模态检索)
# 注意：请确保 /root/autodl-tmp/models/ 目录下同时存在 bge 和 clip 模型文件夹
try:
    bge_model = SentenceTransformer('/root/autodl-tmp/models/BAAI/bge-small-zh-v1.5')
    # 这里假设你的 CLIP 模型文件夹名为 openai/clip-vit-base-patch32 或类似
    clip_model = SentenceTransformer('/root/autodl-tmp/models/openai/clip-vit-base-patch32')
    st.success("模型加载成功！")
except Exception as e:
    st.error(f"模型加载失败: {e}")
    st.stop()

# 2. 连接 Milvus 向量数据库
client = MilvusClient(
    uri="https://in03-5cb3b56f3af9ebc.serverless.ali-cn-hangzhou.cloud.zilliz.com.cn",
    token="9027d285f74e5ce113bf24162fc5cabe04b67db3ee25055f4748ea23785f00d0fa9b8217c108a04dc77c4a703b5860a7d39d7a7b"
)


# ================== 辅助函数 ==================
def clear_chat_history():
    st.session_state.messages = [
        {"role": "system", "content": "你好，我是多模态AI助手，可以阅读文档并回答关于文本和图片的问题。"}
    ]


# 用于在 Streamlit 中安全渲染 Markdown 并显示图片
def render_markdown_with_images(markdown_text):
    pattern = re.compile(r'!\[.*?\]\((.*?)\)')
    last_pos = 0
    for match in pattern.finditer(markdown_text):
        st.markdown(markdown_text[last_pos:match.start()], unsafe_allow_html=True)
        img_url = match.group(1)
        # 尝试显示图片，如果 URL 无效则忽略
        try:
            st.image(img_url, width=300)
        except:
            st.write(f"[图片无法显示: {img_url}]")
        last_pos = match.end()
    st.markdown(markdown_text[last_pos:], unsafe_allow_html=True)


# ================== 主程序逻辑 ==================
# 1. 页面初始化
st.set_page_config(page_title="多模态RAG问答", layout="wide")
st.title("📄 多模态文档问答系统")

# 2. 聊天历史初始化
if "messages" not in st.session_state.keys():
    st.session_state.messages = [
        {"role": "system", "content": "你好，我是多模态AI助手，请上传文档或直接提问。"}
    ]

# 3. 显示聊天记录
for message in st.session_state.messages:
    if message["role"] != "system":  # 不显示 system 消息
        with st.chat_message(message["role"]):
            render_markdown_with_images(message["content"])

# 4. 侧边栏控制
with st.sidebar:
    st.header("Chat 控制")
    if st.button('🧹 清空聊天记录', use_container_width=True):
        clear_chat_history()
        st.rerun()

# 5. 用户输入与处理 (核心逻辑)
if prompt := st.chat_input("请输入你的问题..."):
    # 添加用户消息到历史
    st.session_state.messages.append({"role": "user", "content": prompt})

    with st.chat_message("user"):
        st.write(prompt)

    with st.chat_message("assistant"):
        try:
            # --- 步骤 1: 编码查询 ---
            # 使用 BGE 编码文本用于文本检索
            prompt_bge_embedding = bge_model.encode(prompt, normalize_embeddings=True)
            # 使用 CLIP 编码文本用于图片检索 (跨模态)
            prompt_clip_embedding = clip_model.encode(prompt, normalize_embeddings=True)

            # --- 步骤 2: 混合检索 (关键改进) ---
            results = []

            # A. 检索相关图片 (基于 CLIP 向量: 文本->图片)
            # 假设你的 Milvus 集合中有一个专门存储图片特征的字段 "clip_image_vector"
            image_search_res = client.search(
                collection_name="rag_data_new",
                data=[list(prompt_clip_embedding)],
                anns_field="clip_image_vector",  # 搜索图片向量
                limit=2,  # 最多检索 2 张相关图片
                output_fields=["text", "file_path", "file_name"]
            )
            results.extend(image_search_res[0])

            # B. 检索相关文本 (基于 BGE 向量)
            text_search_res = client.search(
                collection_name="rag_data_new",
                data=[list(prompt_bge_embedding)],
                anns_field="text_vector",
                limit=3,  # 最多检索 3 段文本
                output_fields=["text", "file_path", "file_name"]
            )
            results.extend(text_search_res[0])

            # --- 步骤 3: 结果去重与拼接 ---
            # 简单基于文本前50字符去重
            unique_contents = {}
            for res in results:
                entity = res["entity"]
                # 修复图片路径 (将 Markdown 中的相对路径转换为绝对路径)
                text = entity["text"]
                # 这里的路径修复逻辑需要根据你 mineru 解析后的实际存储结构调整
                file_dir = os.path.basename(entity["file_path"]).split(".")[0]
                text = text.replace("images/", f"./processed/{file_dir}/vlm/images/")
                # 去重 Key
                key = text.strip()[:50]
                unique_contents[key] = text

            # 拼接最终上下文
            related_content = "\n---\n".join(unique_contents.values())

            # --- 步骤 4: 调用大模型生成答案 ---
            # 使用 qwen-vl-plus 以支持多模态理解
            completion = qwen_client.chat.completions.create(
                model="qwen-vl-plus",
                messages=[
                    {
                        "role": "user",
                        "content": rag_prompt.format(prompt, related_content)
                    }
                ],
                temperature=0.1
            )

            # 获取模型回答
            response = completion.choices[0].message.content
            # 显示并保存回答
            render_markdown_with_images(response)
            st.session_state.messages.append({"role": "assistant", "content": response})

        except Exception as e:
            error_msg = f"处理出错: {str(e)}"
            st.error(error_msg)
            st.session_state.messages.append({"role": "assistant", "content": error_msg})
            traceback.print_exc()


