"""离线文档处理 Worker

Kafka 消费者，消费 parse_document_topic 消息，执行：
  下载PDF → 解析(MinerU/OCR) → 分块 → 向量化(BGE+CLIP) → 写入Milvus
"""
import json
import os
import signal
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

from config.settings import settings
from core.database import ensure_db, get_db
from core.file_service import FileService
from core.kafka_service import KafkaService
from core.milvus_service import MilvusService
from core.embedding_service import EmbeddingService
from models.schemas import DocStatus
from orm_model import Chunk as ChunkModel, Document, Image as ImageModel
from worker.pdf_parser import PdfParser
from worker.chunk_splitter import ChunkSplitter
from worker.vectorize_pipeline import VectorizePipeline
from utils.logger import logger, set_trace_id
from utils.retry import retry


class Worker:
    """文档解析 Worker"""

    def __init__(self):
        self.running = True
        self.kafka = KafkaService()
        self.file_service = FileService()
        self.milvus = MilvusService()
        self.embedding = EmbeddingService()
        self.pdf_parser = PdfParser()
        self.chunk_splitter = ChunkSplitter()
        self.vectorize_pipeline = VectorizePipeline(self.embedding, self.milvus)

        self.processed_dir = Path(settings.PDF_PROCESSED_DIR)
        self.processed_dir.mkdir(parents=True, exist_ok=True)

        # 注册信号
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    def _signal_handler(self, signum, frame):
        logger.info("Received signal %s, shutting down...", signum)
        self.running = False

    def _update_status(self, document_id: str, status: str, error_msg: str = ""):
        """更新文档状态"""
        db = get_db()
        try:
            doc = db.query(Document).filter(Document.document_id == document_id).first()
            if doc:
                doc.status = status
                if error_msg:
                    doc.error_msg = error_msg
                db.commit()
                logger.info("Status updated: doc=%s status=%s", document_id, status)
        except Exception as e:
            logger.error("Failed to update status: %s", e)
        finally:
            db.close()

    def _save_chunk_meta(self, chunk_dict: dict, document_id: str, knowledge_base_id: str, embedding_id: str = ""):
        """保存 chunk 元信息到 MySQL"""
        db = get_db()
        try:
            chunk = ChunkModel(
                document_id=document_id,
                knowledge_base_id=knowledge_base_id,
                page_num=chunk_dict.get("page_num", 0),
                content=chunk_dict["content"],
                title=chunk_dict.get("title", ""),
                embedding_id=embedding_id,
            )
            db.add(chunk)
            db.commit()
        except Exception as e:
            logger.error("Failed to save chunk meta: %s", e)
            db.rollback()
        finally:
            db.close()

    def _save_image_meta(self, image_info: dict, document_id: str, knowledge_base_id: str):
        """保存图片元信息到 MySQL"""
        db = get_db()
        try:
            img = ImageModel(
                document_id=document_id,
                knowledge_base_id=knowledge_base_id,
                page_num=image_info.get("page_num", 0),
                image_path=image_info["image_path"],
                embedding_id=image_info.get("embedding_id", ""),
            )
            db.add(img)
            db.commit()
        except Exception as e:
            logger.error("Failed to save image meta: %s", e)
            db.rollback()
        finally:
            db.close()

    def process_task(self, task: dict):
        """处理单个解析任务"""
        document_id = task["document_id"]
        file_path = task["file_path"]
        knowledge_base_id = task["knowledge_base_id"]

        set_trace_id(document_id[:16])
        logger.info("Processing task: doc=%s file=%s", document_id, file_path)

        try:
            # 1. 更新状态为 parsing
            self._update_status(document_id, DocStatus.PARSING)

            # 2. 下载 PDF
            output_dir = str(self.processed_dir / document_id)
            self.file_service.ensure_dir(output_dir)
            local_pdf = os.path.join(output_dir, "source.pdf")
            try:
                self.file_service.download_to_local(file_path, local_pdf)
            except Exception as e:
                self._update_status(document_id, DocStatus.DOWNLOAD_FAILED, str(e))
                raise

            # 3. 解析 PDF
            try:
                parse_result = self.pdf_parser.parse(local_pdf, output_dir)
            except Exception as e:
                self._update_status(document_id, DocStatus.PARSE_FAILED, str(e))
                raise

            # MinerU 返回格式：{markdown: "path/to/xxx.md", images: ["path/to/img1.png", ...]}
            markdown_path = parse_result.get("markdown", "")
            image_paths = parse_result.get("images", [])

            if markdown_path:
                # 更新文档的 markdown_path
                db = get_db()
                try:
                    doc = db.query(Document).filter(Document.document_id == document_id).first()
                    if doc:
                        doc.markdown_path = markdown_path
                        db.commit()
                finally:
                    db.close()

            # 4. 读取 Markdown 并分块
            chunks = []
            if markdown_path and os.path.exists(markdown_path):
                with open(markdown_path, "r", encoding="utf-8") as f:
                    md_content = f.read()
                chunks = self.chunk_splitter.split(md_content)

            # 5. 向量化文本 chunks
            try:
                chunk_ids = self.vectorize_pipeline.process_chunks(
                    chunks, document_id, knowledge_base_id,
                )
                # 保存 chunk 元信息
                for i, chunk in enumerate(chunks):
                    self._save_chunk_meta(
                        chunk, document_id, knowledge_base_id,
                        embedding_id=chunk_ids[i] if i < len(chunk_ids) else "",
                    )
            except Exception as e:
                self._update_status(document_id, DocStatus.EMBEDDING_FAILED, str(e))
                raise

            # 6. 向量化图片
            try:
                image_results = self.vectorize_pipeline.process_images(
                    image_paths, document_id, knowledge_base_id,
                )
                for img in image_results:
                    self._save_image_meta(img, document_id, knowledge_base_id)
            except Exception as e:
                logger.warning("Image vectorization failed (non-fatal): %s", e)

            # 7. 更新完成状态
            self._update_status(document_id, DocStatus.COMPLETED)
            logger.info("Task completed: doc=%s", document_id)

        except Exception as e:
            logger.error("Task failed: doc=%s error=%s", document_id, traceback.format_exc())
            # 尝试发送死信
            try:
                self.kafka.send_dead_letter(task, error=str(e))
            except Exception:
                pass

    def run(self):
        """启动 Worker 主循环"""
        ensure_db()
        logger.info("Worker starting (concurrency=%d)...", settings.WORKER_CONCURRENCY)

        consumer = self.kafka.create_consumer()

        while self.running:
            try:
                msg_pack = consumer.poll(timeout_ms=1000)
                for tp, messages in msg_pack.items():
                    for msg in messages:
                        if not self.running:
                            break
                        task = msg.value
                        logger.info("Received task: %s", task)
                        self.process_task(task)
            except Exception as e:
                logger.error("Consumer error: %s", traceback.format_exc())
                time.sleep(1)

        consumer.close()
        self.kafka.close()
        self.milvus.close()
        logger.info("Worker stopped.")


def main():
    worker = Worker()
    worker.run()


if __name__ == "__main__":
    main()
