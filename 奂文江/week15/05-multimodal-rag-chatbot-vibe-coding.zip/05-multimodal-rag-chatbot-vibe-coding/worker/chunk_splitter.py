"""Markdown 文本分块"""
import re
from typing import Iterator

from config.settings import settings
from utils.logger import logger


class ChunkSplitter:
    """Markdown 文本分块器，支持按 token 大小和重叠分割"""

    def __init__(self, chunk_size: int = None, chunk_overlap: int = None):
        self.chunk_size = chunk_size or settings.CHUNK_SIZE
        self.chunk_overlap = chunk_overlap or settings.CHUNK_OVERLAP

    def _estimate_tokens(self, text: str) -> int:
        """粗略估算 token 数（中英文混合）"""
        # 中文约 1.5 字/token，英文约 3.5 字母/token
        chinese_chars = len(re.findall(r'[一-鿿]', text))
        english_chars = len(re.findall(r'[a-zA-Z]', text))
        return int(chinese_chars / 1.5 + english_chars / 3.5)

    def _split_by_headers(self, text: str) -> list[str]:
        """按标题（##, ###）预分割"""
        sections = re.split(r'(\n#{1,3}\s+.*?\n)', text)
        result = []
        buffer = ""
        for part in sections:
            if re.match(r'^#{1,3}\s+', part.strip()):
                if buffer:
                    result.append(buffer.strip())
                buffer = part
            else:
                buffer += part
        if buffer:
            result.append(buffer.strip())
        return [r for r in result if r]

    def split(self, text: str, page_num: int = 0, title: str = "") -> list[dict]:
        """分块文本

        Returns:
            [{chunk_id, page_num, content, title}]
        """
        if not text or not text.strip():
            return []

        sections = self._split_by_headers(text)
        chunks = []
        current_chunk = ""
        current_title = title or ""

        for section in sections:
            # 检测当前 section 的标题
            header_match = re.match(r'(#{1,3})\s+(.+?)\n', section)
            if header_match:
                current_title = header_match.group(2).strip()

            section_tokens = self._estimate_tokens(section)

            if self._estimate_tokens(current_chunk) + section_tokens <= self.chunk_size:
                current_chunk += section + "\n"
            else:
                if current_chunk.strip():
                    chunks.append({
                        "content": current_chunk.strip(),
                        "page_num": page_num,
                        "title": current_title,
                    })
                # 重叠：保留上个 chunk 末尾部分内容
                if self.chunk_overlap > 0 and current_chunk:
                    words = current_chunk.split()
                    overlap_len = min(len(words), int(self.chunk_overlap / 2))
                    current_chunk = " ".join(words[-overlap_len:]) + "\n" + section + "\n"
                else:
                    current_chunk = section + "\n"

        if current_chunk.strip():
            chunks.append({
                "content": current_chunk.strip(),
                "page_num": page_num,
                "title": current_title,
            })

        logger.info("Split into %d chunks (size=%d, overlap=%d)", len(chunks), self.chunk_size, self.chunk_overlap)
        return chunks

    def split_document(self, markdown_content: str, page_map: dict[int, str] = None) -> list[dict]:
        """按页分块

        Args:
            markdown_content: 完整 markdown 内容
            page_map: {页码: 该页文本内容} 映射

        Returns:
            chunk 列表
        """
        if page_map:
            all_chunks = []
            for page_num, text in sorted(page_map.items()):
                page_chunks = self.split(text, page_num=page_num)
                all_chunks.extend(page_chunks)
            return all_chunks

        # 无 page_map 时整体分块
        return self.split(markdown_content)
