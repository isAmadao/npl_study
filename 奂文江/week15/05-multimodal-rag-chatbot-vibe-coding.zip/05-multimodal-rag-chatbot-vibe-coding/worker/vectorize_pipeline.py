"""向量化流水线：分块 → BGE/CLIP 向量 → 写入 Milvus + MySQL"""
import os
from pathlib import Path

from config.settings import settings
from core.embedding_service import EmbeddingService
from core.milvus_service import MilvusService
from utils.logger import logger
from utils.retry import retry


class VectorizePipeline:
    """向量化流水线"""

    def __init__(self, embedding: EmbeddingService, milvus: MilvusService):
        self.embedding = embedding
        self.milvus = milvus

    def process_chunks(
        self,
        chunks: list[dict],
        document_id: str,
        knowledge_base_id: str,
    ) -> list[str]:
        """文本 chunk 向量化并写入 Milvus

        Args:
            chunks: chunk 列表 [{content, page_num, title}]
            document_id: 文档 ID
            knowledge_base_id: 知识库 ID

        Returns:
            chunk_id 列表（与 chunks 对应）
        """
        if not chunks:
            return []

        texts = [c["content"] for c in chunks]
        logger.info("Embedding %d text chunks with BGE...", len(texts))

        vectors = self.embedding.embed_text(texts)

        entities = []
        for i, (chunk, vec) in enumerate(zip(chunks, vectors)):
            entities.append({
                "vector": vec,
                "document_id": document_id,
                "knowledge_base_id": knowledge_base_id,
                "chunk_id": f"{document_id}_chunk_{i}",
                "page_num": chunk["page_num"],
            })

        ids = self.milvus.insert_text_vectors(entities)
        chunk_ids = [f"{document_id}_chunk_{i}" for i in range(len(chunks))]
        logger.info("Inserted %d text vectors to Milvus", len(chunk_ids))
        return chunk_ids

    def process_images(
        self,
        image_paths: list[str],
        document_id: str,
        knowledge_base_id: str,
    ) -> list[dict]:
        """图片向量化并写入 Milvus

        Args:
            image_paths: 图片路径列表
            document_id: 文档 ID
            knowledge_base_id: 知识库 ID

        Returns:
            [{image_id, image_path}] 列表
        """
        if not image_paths:
            return []

        logger.info("Embedding %d images with CLIP...", len(image_paths))

        vectors = self.embedding.embed_image(image_paths)

        entities = []
        results = []
        for i, (img_path, vec) in enumerate(zip(image_paths, vectors)):
            image_id = f"{document_id}_img_{i}"
            entities.append({
                "vector": vec,
                "document_id": document_id,
                "knowledge_base_id": knowledge_base_id,
                "image_id": image_id,
                "page_num": 0,  # 暂缺页码信息
                "image_path": img_path,
            })
            results.append({"image_id": image_id, "image_path": img_path})

        self.milvus.insert_image_vectors(entities)
        logger.info("Inserted %d image vectors to Milvus", len(results))
        return results
