"""PDF 解析服务（MinerU + DeepSeek-OCR 双引擎）"""
import json
import os
import subprocess
from pathlib import Path

import requests

from config.settings import settings
from utils.logger import logger
from utils.retry import retry


class PdfParser:
    """PDF 解析器，支持 MinerU 和 DeepSeek-OCR 双引擎自动切换"""

    def __init__(self):
        self.mineru_url = settings.MINERU_API_URL
        self.mineru_timeout = settings.MINERU_TIMEOUT

    @retry(max_retries=2, delay=2.0, backoff=2.0)
    def parse_with_mineru(self, pdf_path: str, output_dir: str) -> dict:
        """使用 MinerU 解析 PDF

        Returns:
            {markdown_dir: str, images_dir: str}
        """
        url = f"{self.mineru_url}/parse"
        with open(pdf_path, "rb") as f:
            files = {"file": f}
            resp = requests.post(url, files=files, timeout=self.mineru_timeout)
        resp.raise_for_status()
        result = resp.json()

        # MinerU 返回结构： {markdown: "path/to/xxx.md", images: ["path/to/img1.png", ...]}
        logger.info("MinerU parse success: %s", pdf_path)
        return result

    def parse_with_deepseek_ocr(self, pdf_path: str, output_dir: str) -> dict:
        """使用 DeepSeek-OCR 解析 PDF（备选引擎）"""
        # 实际调用时需替换为真实 API
        raise NotImplementedError("DeepSeek-OCR integration pending")

    def parse(self, pdf_path: str, output_dir: str) -> dict:
        """解析 PDF，MinerU 失败自动切换 DeepSeek-OCR"""
        try:
            return self.parse_with_mineru(pdf_path, output_dir)
        except Exception as e:
            logger.warning("MinerU failed, switching to DeepSeek-OCR: %s", e)
            try:
                return self.parse_with_deepseek_ocr(pdf_path, output_dir)
            except Exception as e2:
                logger.error("Both parsers failed: %s", e2)
                raise
