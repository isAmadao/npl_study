一、稳定需求定义（按模块拆解，明确输入 / 输出 / 约束）
1. 数据上传模块（Web 服务，POST /upload/document）
功能需求
表格
序号	需求描述	输入参数	输出 / 状态	约束与错误处理
1	仅支持 PDF 文件上传	file（二进制流）、knowledge_base_id、uploader	成功：{"code":200, "data":{"document_id":"xxx"}}	格式校验：非 PDF 返回400；大小超限（可配置，默认 100MB）返回400
2	文件存储（本地 / OSS）	上传的 PDF 流	存储路径：{base_path}/{document_id}/{original.pdf}	路径可配置；文件覆盖保护（基于document_id唯一命名）
3	记录文档元信息	document_id、knowledge_base_id、file_name、uploader、file_path	写入 MySQL：文档表新增记录，状态pending	字段非空校验；主键唯一约束
4	发送解析任务到 Kafka	document_id、file_path、knowledge_base_id	Kafka Topic parse_document_topic 发送 JSON 消息	消息格式：{"document_id":"xxx", "file_path":"xxx", "knowledge_base_id":"xxx", "upload_time":"xxx"}；失败重试 3 次，失败后标记文档状态为send_failed
5	幂等性校验	文件哈希（MD5）	重复文件返回已存在的document_id	基于文件哈希避免重复上传
非功能约束
接口响应时间：正常场景 < 5s（含存储 + Kafka 发送）
并发支持：单实例支持 100 + 并发上传
日志：记录trace_id、文件信息、存储 / 发送结果
2. 任务队列模块（Kafka）
功能需求
表格
序号	需求描述	输入	输出	约束
1	Topic 配置	parse_document_topic	分区数可配置（默认 3），副本数 3	保证消息不丢失（acks=all）
2	消息生产	上传模块发送的任务消息	至少一次投递	失败重试机制，死信队列（parse_document_topic_dlq）存储重试失败消息
3	消息消费	Worker 拉取 Topic 消息	按document_id消费，避免重复处理	消费前更新文档状态为parsing；消费失败重试 2 次，超过次数进入死信队列
非功能约束
消息堆积监控：超过 100 条告警
消费延迟：<10s
3. 文档解析 Worker（离线服务）
功能需求
表格
阶段	需求描述	输入	输出	约束与错误处理
1	任务消费与文件下载	Kafka 消息（document_id、file_path）	本地下载 PDF 文件到临时目录	下载失败重试 2 次，失败标记文档状态为download_failed
2	PDF 解析（MinerU/DeepSeek-OCR）	PDF 文件路径	Markdown 文件、图片文件集合	引擎可配置，MinerU 失败自动切换 DeepSeek-OCR；解析失败标记状态为parse_failed，记录错误信息
3	输出存储	Markdown、图片文件	存储到对象存储：
{base_path}/{document_id}/output/xxx.md、{base_path}/{document_id}/images/xxx.png	路径可配置；存储失败重试 2 次
4	Markdown 分块	Markdown 内容	文本 Chunk 列表（含chunk_id、page_num、content、title）	分块大小可配置（默认 1000token，重叠 200token）；过滤空内容
5	向量化处理	文本 Chunk、图片文件	文本向量（BGE）、图片向量（CLIP）	模型可配置；向量维度匹配 Milvus 集合（如 BGE 为 1024，CLIP 为 512）；生成失败标记状态为embedding_failed
6	向量与元信息写入	向量、Chunk / 图片元信息	Milvus 写入向量；MySQL 写入 Chunk 表、图片表	批量写入；失败重试 1 次；写入完成后更新文档状态为completed
非功能约束
单 PDF 解析耗时：100 页以内 < 5min
并发解析数：可配置（默认 5 个并发）
日志：记录每个阶段的耗时、错误信息，关联document_id
4. 存储与索引模块
（1）对象存储（本地 / OSS）
表格
需求	输入	输出	约束
文件上传 / 下载	文件流、目标路径	上传成功 / 下载文件流	路径格式统一：{base_path}/{document_id}/{type}/xxx；支持签名 URL 访问（OSS）
（2）向量数据库（Milvus）
表格
集合	字段	约束
文本向量集合	id（主键）、vector（BGE 向量）、document_id、knowledge_base_id、chunk_id、page_num	按knowledge_base_id分区；索引类型IVF_FLAT
图片向量集合	id（主键）、vector（CLIP 向量）、document_id、knowledge_base_id、image_id、page_num、image_path	按knowledge_base_id分区；索引类型IVF_FLAT
（3）元信息数据库（MySQL/SQLite）
表格
表名	关键字段	约束
文档表	document_id（PK）、knowledge_base_id、file_name、uploader、upload_time、status、original_path、markdown_path、error_msg	status枚举：pending/parsing/completed/failed
Chunk 表	chunk_id（PK）、document_id、knowledge_base_id、page_num、content、title、embedding_id（Milvus ID）	外键关联document_id
图片表	image_id（PK）、document_id、knowledge_base_id、page_num、image_path、embedding_id（Milvus ID）	外键关联document_id
权限表	user_id、knowledge_base_id、role（read/write/admin）	唯一约束：(user_id, knowledge_base_id)
5. 多模态问答模块（Web 服务，POST /chat）
功能需求
表格
阶段	需求描述	输入参数	输出	约束与错误处理
1	参数校验与权限控制	user_id、knowledge_base_id、question、top_k（默认 5）	校验失败返回403（无权限）/400（参数错误）	验证用户是否有权限访问knowledge_base_id
2	多模态检索（RAG）	question、knowledge_base_id、user_id	文本 Chunk 列表、图片列表（含来源信息）	文本检索：BGE 生成问题向量→Milvus 按相似度 Top-K 返回→按权限过滤
图片检索：CLIP 生成问题向量→Milvus 按相似度 Top-K 返回→按权限过滤
3	上下文构建	文本 Chunk、图片列表	图文上下文（含来源标记：文档名+页码/图片编号+文档名+页码）	上下文长度不超过 Qwen-VL 模型限制
4	多模态生成（Qwen-VL）	问题、图文上下文	答案文本、来源信息列表	模型调用超时重试 2 次，超时设置 30s；失败返回500或 “暂无相关信息”
5	响应返回	答案、来源信息	{"code":200, "data":{"answer":"xxx", "sources":[{"file_name":"xxx", "page_num":3, "type":"text"}, ...]}}	来源信息需可追溯到文档和页码
非功能约束
接口响应时间：<10s（含检索 + 模型调用）
限流：单用户每秒最多 2 次请求
日志：记录trace_id、检索耗时、模型调用耗时、来源信息
6. 模型与工具链
表格
组件	需求描述	约束
MinerU/DeepSeek-OCR	PDF 解析引擎，可配置切换	错误时自动切换备用引擎；支持批量处理
BGE	文本 Embedding 模型，支持本地 / API 调用	向量维度与 Milvus 匹配；可配置模型版本
CLIP	多模态 Embedding 模型，支持文本 / 图片向量化	向量维度与 Milvus 匹配；可配置模型版本
Qwen-VL	多模态生成模型，支持图文输入	可配置最大上下文长度、温度参数；支持流式输出（可选）
二、测试逻辑（分层覆盖，适配代码生成）
1. 单元测试（Mock 依赖，验证单模块逻辑）
（1）数据上传模块
用例 1：正常上传 PDF（格式正确、大小合规）→ 验证文件存储、元信息写入、Kafka 消息发送
用例 2：上传非 PDF 文件→ 返回400错误
用例 3：上传超大文件（>100MB）→ 返回400错误
用例 4：存储失败（Mock OSS / 本地存储异常）→ 验证文件未保存、元信息状态为upload_failed
用例 5：Kafka 发送失败（Mock Kafka 异常）→ 验证重试机制、状态更新为send_failed
（2）文档解析 Worker
用例 1：正常解析 PDF→ 验证 Markdown / 图片生成、存储、分块、向量化、元信息更新
用例 2：PDF 下载失败（Mock 文件不存在）→ 验证重试、状态更新为download_failed
用例 3：MinerU 解析失败→ 验证自动切换 DeepSeek-OCR
用例 4：分块逻辑验证（不同分块大小 / 重叠率）→ 验证 Chunk 数量、内容正确性
用例 5：向量写入失败（Mock Milvus 异常）→ 验证重试、状态更新为embedding_failed
（3）多模态检索（RAG）
用例 1：文本检索→ Mock BGE/Milvus，验证 Top-K 结果、知识库过滤、权限过滤
用例 2：图片检索→ Mock CLIP/Milvus，验证 Top-K 结果、知识库过滤、权限过滤
用例 3：无权限访问知识库→ 验证返回空结果或403
用例 4：空检索结果→ 验证返回空列表，生成阶段提示 “暂无相关信息”
（4）多模态生成（Qwen-VL）
用例 1：正常生成答案→ Mock Qwen-VL，验证答案包含来源信息
用例 2：模型调用超时→ 验证重试机制、超时处理
用例 3：上下文过长→ 验证截断逻辑或错误提示
用例 4：图片格式不支持→ 验证无效图片过滤或模型兼容处理
2. 集成测试（模块间交互，依赖真实测试环境）
（1）上传→解析→存储链路
场景：上传含文本 + 图片的 PDF→ 验证：
Kafka 消息发送成功
Worker 消费并解析完成，Markdown / 图片存储成功
Chunk / 图片元信息写入 MySQL
文本 / 图片向量写入 Milvus
文档状态更新为completed
（2）问答全链路
场景 1：文本相关提问→ 验证文本检索返回相关 Chunk，答案包含来源信息
场景 2：图片相关提问→ 验证图片检索返回对应图片，答案包含图片来源
场景 3：跨知识库权限验证→ 用户无权限时无法检索其他知识库内容
场景 4：空知识库提问→ 返回 “暂无相关信息”
（3）异常场景
Kafka 宕机：上传任务发送失败，状态更新为send_failed；恢复后支持手动触发重试
Milvus 宕机：Worker 向量化失败，状态更新为embedding_failed；恢复后支持重新向量化
模型服务宕机：BGE/CLIP/Qwen-VL 异常时，验证降级策略（如仅文本检索、返回服务维护提示）
3. 端到端（E2E）测试（模拟用户真实场景）
（1）完整流程测试
用户 A 上传 PDF 到知识库 K1→ 解析完成
用户 A 提问文本问题→ 验证答案内容正确、来源标记（文档名 + 页码）准确
用户 A 提问图片问题→ 验证答案描述正确、图片来源标记准确
用户 B 无 K1 权限→ 调用 /chat 接口返回403错误
（2）性能压测
并发上传：10 用户同时上传 10MB PDF→ 验证接口无报错、响应时间 < 5s
并发问答：100 用户同时调用 /chat→ 验证平均响应时间 < 10s、错误率 < 1%
大文档解析：上传 100 页 PDF→ 验证解析耗时 < 5min、向量化后可正常检索
（3）评价指标验证（对应架构图）
页面匹配度：验证答案引用的页码与文档实际内容一致（权重 0.25）
文件名匹配度：验证答案引用的文件名与上传文件一致（权重 0.25）
答案相似度：用 Jaccard 系数计算答案与文档内容的交集 / 并集≥0.5
4. 其他测试点
兼容性：不同 PDF 版本（1.4/1.5/1.7）、图片格式（PNG/JPG）解析测试
安全：SQL 注入、XSS 攻击、权限越权测试
回归：修改解析引擎 / 向量模型后，验证历史用例通过
