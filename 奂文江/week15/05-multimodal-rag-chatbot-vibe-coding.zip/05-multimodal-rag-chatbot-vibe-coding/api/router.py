"""FastAPI 路由汇总"""
from fastapi import APIRouter
from api.upload_api import router as upload_router
from api.chat_api import router as chat_router

api_router = APIRouter(prefix="/api")
api_router.include_router(upload_router)
api_router.include_router(chat_router)
