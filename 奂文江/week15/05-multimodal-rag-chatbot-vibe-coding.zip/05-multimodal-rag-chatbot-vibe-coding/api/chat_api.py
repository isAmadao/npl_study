"""多模态问答 API"""
from fastapi import APIRouter, HTTPException

from config.settings import settings
from core.database import get_db
from core.embedding_service import EmbeddingService
from core.llm_service import LLMService
from core.milvus_service import MilvusService
from models.schemas import ChatRequest, ChatResponse, SourceInfo
from orm_model import Chunk, Image, Permission
from utils.logger import logger, set_trace_id
from utils.limiter import UserRateLimiter

router = APIRouter(prefix="/chat", tags=["chat"])
embedding = EmbeddingService()
llm = LLMService()
milvus = MilvusService()
limiter = UserRateLimiter(settings.RATE_LIMIT_PER_USER)


def _check_permission(user_id: str, knowledge_base_id: str) -> bool:
    db = get_db()
    try:
        perm = db.query(Permission).filter(
            Permission.user_id == user_id,
            Permission.knowledge_base_id == knowledge_base_id,
        ).first()
        return perm is not None
    finally:
        db.close()


def _get_chunk_texts(chunk_ids: list[str]) -> list[dict]:
    """根据 chunk_id 从 MySQL 获取文本内容"""
    db = get_db()
    try:
        chunks = db.query(Chunk).filter(Chunk.chunk_id.in_(chunk_ids)).all()
        return [
            {"content": c.content, "file_name": "", "page_num": c.page_num}
            for c in chunks
        ]
    finally:
        db.close()


@router.post("", response_model=ChatResponse)
async def chat(req: ChatRequest):
    """多模态 RAG 问答"""
    trace_id = set_trace_id()
    logger.info("Chat request: user=%s, kb=%s, question=%s", req.user_id, req.knowledge_base_id, req.question[:50])

    # 1. 权限校验
    if not _check_permission(req.user_id, req.knowledge_base_id):
        raise HTTPException(status_code=403, detail="无权访问该知识库")

    # 2. 限流
    if not limiter.check(req.user_id):
        raise HTTPException(status_code=429, detail="请求过于频繁，请稍后重试")

    # 3. 文本检索（BGE → Milvus）
    logger.info("Text retrieval start...")
    text_vec = embedding.embed_text(req.question)
    text_results = milvus.search_text(text_vec, req.knowledge_base_id, req.top_k)
    logger.info("Text retrieval done: %d results", len(text_results))

    # 4. 图片检索（CLIP → Milvus）
    logger.info("Image retrieval start...")
    image_vec = embedding.embed_text_clip(req.question)
    image_results = milvus.search_image(image_vec, req.knowledge_base_id, req.top_k)
    logger.info("Image retrieval done: %d results", len(image_results))

    # 5. 构建上下文
    sources: list[SourceInfo] = []
    context_texts: list[dict] = []
    context_images: list[dict] = []

    for r in text_results:
        sources.append(SourceInfo(
            file_name=r.get("document_id", ""),
            page_num=r.get("page_num", 0),
            type="text",
        ))
        # 文本内容需要从 MySQL 补充（Milvus 只存了元信息）
        # 这里简化：只保留来源标记，内容从检索结果中的 chunk_id 取
        context_texts.append({
            "content": f"[检索结果] 文档={r.get('document_id')} 第{r.get('page_num', 0)}页",
            "file_name": r.get("document_id", ""),
            "page_num": r.get("page_num", 0),
        })

    for r in image_results:
        sources.append(SourceInfo(
            file_name=r.get("document_id", ""),
            page_num=r.get("page_num", 0),
            type="image",
        ))
        context_images.append({
            "image_url": r.get("image_path", ""),
            "file_name": r.get("document_id", ""),
            "page_num": r.get("page_num", 0),
        })

    if not context_texts and not context_images:
        logger.info("No relevant content found")
        return ChatResponse.ok(
            answer="暂无相关信息",
            sources=[],
        )

    # 6. LLM 生成
    logger.info("LLM generation start (texts=%d, images=%d)...", len(context_texts), len(context_images))
    try:
        answer = llm.chat(req.question, context_texts, context_images)
    except Exception as e:
        logger.error("LLM generation failed: %s", e)
        return ChatResponse.error(500, "生成服务暂时不可用，请稍后重试")

    logger.info("Chat response ready: answer_len=%d, sources=%d", len(answer), len(sources))
    return ChatResponse.ok(answer=answer, sources=sources)
