"""文件上传 API"""
import os
import uuid
from datetime import datetime

from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from core.database import get_db
from core.file_service import FileService
from core.kafka_service import KafkaService
from models.schemas import DocStatus, UploadResponse
from orm_model import Document, Permission
from utils.logger import logger, set_trace_id

router = APIRouter(prefix="/upload", tags=["upload"])
file_service = FileService()
kafka_service = KafkaService()


@router.post("/document", response_model=UploadResponse)
async def upload_document(
    file: UploadFile = File(...),
    knowledge_base_id: str = Form(...),
    uploader: str = Form(...),
):
    """上传 PDF 文档"""
    trace_id = set_trace_id()
    logger.info("Upload request: file=%s, kb=%s, uploader=%s", file.filename, knowledge_base_id, uploader)

    # 1. 格式校验
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext != ".pdf":
        raise HTTPException(status_code=400, detail="仅支持 PDF 文件格式")

    # 2. 大小校验
    file.file.seek(0, 2)
    file_size = file.file.tell()
    file.file.seek(0)
    max_bytes = 100 * 1024 * 1024
    if file_size > max_bytes:
        raise HTTPException(status_code=400, detail=f"文件大小超过限制（最大 100MB）")

    # 3. 写入临时文件计算 MD5（幂等性校验）
    import tempfile
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        content = await file.read()
        tmp.write(content)
        tmp_path = tmp.name

    try:
        file_hash = file_service.compute_md5(tmp_path)

        db = get_db()
        try:
            # 查重
            existing = db.query(Document).filter(
                Document.file_hash == file_hash,
                Document.knowledge_base_id == knowledge_base_id,
            ).first()
            if existing:
                logger.info("Duplicate file detected: doc_id=%s", existing.document_id)
                return UploadResponse.ok(document_id=existing.document_id, is_duplicate=True)

            # 4. 生成 document_id，保存文件
            document_id = uuid.uuid4().hex
            dest_path = file_service.save_upload(document_id, open(tmp_path, "rb"), file.filename)

            # 5. 写 MySQL
            doc = Document(
                document_id=document_id,
                knowledge_base_id=knowledge_base_id,
                file_name=file.filename,
                file_hash=file_hash,
                file_size=file_size,
                uploader=uploader,
                upload_time=datetime.utcnow(),
                status=DocStatus.PENDING,
                original_path=dest_path,
            )
            db.add(doc)
            db.commit()

            # 6. 发 Kafka 消息
            kafka_msg = {
                "document_id": document_id,
                "file_path": dest_path,
                "knowledge_base_id": knowledge_base_id,
                "upload_time": datetime.utcnow().isoformat(),
            }
            try:
                kafka_service.send_parse_task(kafka_msg)
            except Exception as ke:
                doc.status = DocStatus.SEND_FAILED
                doc.error_msg = str(ke)
                db.commit()
                logger.error("Kafka send failed: %s", ke)
                kafka_service.send_dead_letter(kafka_msg, error=str(ke))
                raise HTTPException(status_code=500, detail=f"消息发送失败: {ke}")

            logger.info("Upload success: doc_id=%s", document_id)
            return UploadResponse.ok(document_id=document_id)

        finally:
            db.close()
    finally:
        os.unlink(tmp_path)
