"""Worker 模块测试 — chunk_splitter, pdf_parser, vectorize_pipeline"""

import json
import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from worker.chunk_splitter import ChunkSplitter
from worker.pdf_parser import PdfParser
from worker.vectorize_pipeline import VectorizePipeline
from core.embedding_service import EmbeddingService
from core.milvus_service import MilvusService


# ============================================================
# ChunkSplitter
# ============================================================

class TestChunkSplitter:
    """Markdown 分块器测试"""

    def test_init_defaults(self):
        splitter = ChunkSplitter()
        assert splitter.chunk_size == 1000
        assert splitter.chunk_overlap == 200

    def test_init_custom(self):
        splitter = ChunkSplitter(chunk_size=200, chunk_overlap=50)
        assert splitter.chunk_size == 200
        assert splitter.chunk_overlap == 50

    def test_estimate_tokens_chinese(self):
        splitter = ChunkSplitter()
        text = "你好世界"  # 4 个中文字
        tokens = splitter._estimate_tokens(text)
        assert tokens == 2  # 4 / 1.5 ≈ 2

    def test_estimate_tokens_english(self):
        splitter = ChunkSplitter()
        text = "hello world"
        tokens = splitter._estimate_tokens(text)
        assert tokens == 2  # 10 / 3.5 ≈ 2

    def test_estimate_tokens_mixed(self):
        splitter = ChunkSplitter()
        text = "hello 你好 world 世界"
        tokens = splitter._estimate_tokens(text)
        expected = int(4 / 1.5 + 10 / 3.5)
        assert tokens == expected

    def test_estimate_tokens_empty(self):
        splitter = ChunkSplitter()
        assert splitter._estimate_tokens("") == 0

    def test_split_by_headers(self):
        splitter = ChunkSplitter()
        text = """
## 第一章
这是第一章的内容
### 1.1 小节
小节内容
## 第二章
第二章内容
"""
        sections = splitter._split_by_headers(text)
        assert len(sections) >= 3  # 至少 3 个 section
        assert any("第一章" in s for s in sections)
        assert any("第二章" in s for s in sections)

    def test_split_by_headers_no_headers(self):
        splitter = ChunkSplitter()
        text = "没有标题的纯文本段落。"
        sections = splitter._split_by_headers(text)
        assert len(sections) == 1
        assert sections[0] == text

    def test_split_empty_text(self):
        splitter = ChunkSplitter()
        assert splitter.split("") == []
        assert splitter.split("  ") == []
        assert splitter.split(None) == []

    def test_split_small_text(self):
        splitter = ChunkSplitter(chunk_size=1000, chunk_overlap=200)
        text = "这是一段较短的文本，不超过一个 chunk 的大小。"
        chunks = splitter.split(text, page_num=1, title="测试")
        assert len(chunks) == 1
        assert chunks[0]["page_num"] == 1
        assert chunks[0]["title"] == "测试"
        assert text.strip() in chunks[0]["content"]

    def test_split_large_text(self):
        """大文本应被切割成多个 chunk"""
        splitter = ChunkSplitter(chunk_size=50, chunk_overlap=10)
        # 构造一个足够长的文本
        text = "第一章 人工智能概述 " * 30
        chunks = splitter.split(text)
        assert len(chunks) >= 2

    def test_split_overlap_content(self):
        """验证重叠部分存在"""
        splitter = ChunkSplitter(chunk_size=50, chunk_overlap=20)
        text = "第一节 基础概念 第二节 高级方法 第三节 实践应用 第四节 总结 第五节 参考"
        chunks = splitter.split(text)
        if len(chunks) >= 2:
            # 第二个 chunk 应包含第一个 chunk 的部分尾部内容
            assert len(chunks[0]["content"]) > 0
            assert len(chunks[1]["content"]) > 0

    def test_split_with_header_titles(self):
        """分块应跟踪标题变化"""
        splitter = ChunkSplitter(chunk_size=500, chunk_overlap=50)
        text = """## 第一章
这是第一章的内容。有很多内容需要填充到这个文本中。
### 1.1 子节
子节的具体内容。
## 第二章
第二章的内容介绍。"""
        chunks = splitter.split(text)
        if len(chunks) >= 2:
            # 第二个 chunk 的 title 应为 "第二章"
            titles = [c["title"] for c in chunks]
            assert "第一章" in titles or "第二章" in titles

    def test_split_page_numbers(self):
        splitter = ChunkSplitter(chunk_size=1000, chunk_overlap=200)
        chunks = splitter.split("第1页内容", page_num=5)
        assert chunks[0]["page_num"] == 5

    def test_split_multiple_chunks_page_num(self):
        splitter = ChunkSplitter(chunk_size=30, chunk_overlap=5)
        text = "内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容"
        chunks = splitter.split(text, page_num=3)
        for c in chunks:
            assert c["page_num"] == 3

    def test_split_document_with_page_map(self):
        splitter = ChunkSplitter(chunk_size=1000, chunk_overlap=200)
        page_map = {
            1: "第一页内容",
            2: "第二页内容",
            3: "第三页内容",
        }
        chunks = splitter.split_document("", page_map=page_map)
        assert len(chunks) == 3
        assert chunks[0]["page_num"] == 1
        assert chunks[1]["page_num"] == 2
        assert chunks[2]["page_num"] == 3

    def test_split_document_without_page_map(self):
        splitter = ChunkSplitter(chunk_size=1000, chunk_overlap=200)
        chunks = splitter.split_document("整体文档内容")
        assert len(chunks) >= 1


# ============================================================
# PdfParser
# ============================================================

class TestPdfParser:
    """PDF 解析器测试"""

    def test_init(self):
        parser = PdfParser()
        assert parser.mineru_url == "http://127.0.0.1:30000"
        assert parser.mineru_timeout == 300

    @patch("requests.post")
    def test_parse_with_mineru_success(self, mock_post):
        mock_post.return_value.status_code = 200
        mock_post.return_value.json.return_value = {
            "markdown": "/tmp/test/output.md",
            "images": ["/tmp/test/img1.png"],
        }

        parser = PdfParser()
        result = parser.parse_with_mineru("/tmp/test.pdf", "/tmp/output")
        assert "markdown" in result
        assert "images" in result
        assert result["markdown"] == "/tmp/test/output.md"

    @patch("requests.post")
    def test_parse_with_mineru_timeout(self, mock_post):
        import requests
        mock_post.side_effect = requests.exceptions.Timeout("Request timeout")

        parser = PdfParser()
        with pytest.raises(requests.exceptions.Timeout):
            parser.parse_with_mineru("/tmp/test.pdf", "/tmp/output")

    def test_parse_with_deepseek_ocr_not_implemented(self):
        parser = PdfParser()
        with pytest.raises(NotImplementedError):
            parser.parse_with_deepseek_ocr("/tmp/test.pdf", "/tmp/output")

    @patch.object(PdfParser, "parse_with_mineru")
    def test_parse_fallback_not_needed(self, mock_mineru):
        mock_mineru.return_value = {"markdown": "/tmp/output.md", "images": []}
        parser = PdfParser()
        result = parser.parse("/tmp/test.pdf", "/tmp/output")
        assert result["markdown"] == "/tmp/output.md"
        mock_mineru.assert_called_once()

    @patch.object(PdfParser, "parse_with_mineru")
    @patch.object(PdfParser, "parse_with_deepseek_ocr")
    def test_parse_fallback_on_failure(self, mock_deepseek, mock_mineru):
        mock_mineru.side_effect = Exception("MinerU failed")
        mock_deepseek.side_effect = NotImplementedError("OCR not ready")

        parser = PdfParser()
        with pytest.raises(NotImplementedError):
            parser.parse("/tmp/test.pdf", "/tmp/output")

        mock_mineru.assert_called_once()
        mock_deepseek.assert_called_once()

    @patch.object(PdfParser, "parse_with_mineru")
    @patch.object(PdfParser, "parse_with_deepseek_ocr")
    def test_parse_fallback_success(self, mock_deepseek, mock_mineru):
        mock_mineru.side_effect = Exception("MinerU failed")
        mock_deepseek.return_value = {"markdown": "/tmp/ocr.md", "images": []}

        parser = PdfParser()
        result = parser.parse("/tmp/test.pdf", "/tmp/output")
        assert result["markdown"] == "/tmp/ocr.md"
        # DeepSeek-OCR 当前是占位，但逻辑上验证 fallback 流程


# ============================================================
# VectorizePipeline
# ============================================================

class TestVectorizePipeline:
    """向量化流水线测试"""

    def test_init(self):
        emb = MagicMock(spec=EmbeddingService)
        mil = MagicMock(spec=MilvusService)
        pipeline = VectorizePipeline(emb, mil)
        assert pipeline.embedding is emb
        assert pipeline.milvus is mil

    def test_process_chunks_empty(self):
        emb = MagicMock()
        mil = MagicMock()
        pipeline = VectorizePipeline(emb, mil)
        result = pipeline.process_chunks([], "doc1", "kb1")
        assert result == []
        emb.embed_text.assert_not_called()
        mil.insert_text_vectors.assert_not_called()

    def test_process_chunks_success(self):
        emb = MagicMock(spec=EmbeddingService)
        emb.embed_text.return_value = [[0.1] * 1024 for _ in range(2)]
        mil = MagicMock(spec=MilvusService)
        mil.insert_text_vectors.return_value = [1, 2]

        pipeline = VectorizePipeline(emb, mil)
        chunks = [
            {"content": "文本1", "page_num": 1, "title": "章1"},
            {"content": "文本2", "page_num": 2, "title": "章2"},
        ]
        chunk_ids = pipeline.process_chunks(chunks, "doc1", "kb1")
        assert len(chunk_ids) == 2
        assert chunk_ids[0] == "doc1_chunk_0"
        assert chunk_ids[1] == "doc1_chunk_1"

        # 验证向量插入数据
        mil.insert_text_vectors.assert_called_once()
        entities = mil.insert_text_vectors.call_args[0][0]
        assert len(entities) == 2
        assert entities[0]["document_id"] == "doc1"
        assert entities[0]["knowledge_base_id"] == "kb1"

    def test_process_images_empty(self):
        emb = MagicMock()
        mil = MagicMock()
        pipeline = VectorizePipeline(emb, mil)
        result = pipeline.process_images([], "doc1", "kb1")
        assert result == []
        emb.embed_image.assert_not_called()
        mil.insert_image_vectors.assert_not_called()

    def test_process_images_success(self):
        emb = MagicMock(spec=EmbeddingService)
        emb.embed_image.return_value = [[0.2] * 512 for _ in range(2)]
        mil = MagicMock(spec=MilvusService)

        pipeline = VectorizePipeline(emb, mil)
        image_paths = ["/img1.png", "/img2.png"]
        results = pipeline.process_images(image_paths, "doc1", "kb1")

        assert len(results) == 2
        assert results[0]["image_id"] == "doc1_img_0"
        assert results[1]["image_id"] == "doc1_img_1"
        assert results[0]["image_path"] == "/img1.png"

        mil.insert_image_vectors.assert_called_once()
        entities = mil.insert_image_vectors.call_args[0][0]
        assert len(entities) == 2
        assert entities[0]["image_path"] == "/img1.png"
        assert entities[1]["image_path"] == "/img2.png"

    def test_process_chunks_vector_dimension(self):
        """验证向量维度传递正确"""
        emb = MagicMock(spec=EmbeddingService)
        emb.embed_text.return_value = [[0.5] * 1024]
        mil = MagicMock(spec=MilvusService)

        pipeline = VectorizePipeline(emb, mil)
        pipeline.process_chunks(
            [{"content": "测试", "page_num": 1, "title": "t"}],
            "doc1", "kb1",
        )
        entities = mil.insert_text_vectors.call_args[0][0]
        assert len(entities[0]["vector"]) == 1024
