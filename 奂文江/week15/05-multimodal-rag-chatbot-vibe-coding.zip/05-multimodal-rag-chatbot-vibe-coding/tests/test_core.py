"""核心服务模块测试 — database, file_service, kafka, milvus, embedding, llm"""

import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from core.database import ensure_db, init_db
from core.file_service import FileService
from core.kafka_service import KafkaService
from core.milvus_service import MilvusService
from core.embedding_service import EmbeddingService
from core.llm_service import LLMService


# ============================================================
# database
# ============================================================

class TestDatabase:
    """数据库会话管理测试"""

    def test_init_db(self):
        """init_db 应可安全重复调用"""
        init_db()  # 幂等操作

    def test_ensure_db(self):
        """ensure_db 应完成数据库初始化"""
        ensure_db()

    def test_get_session(self, db_session):
        # 验证在 conftest 中已正确注入
        from core.database import get_session
        sessions = list(get_session())
        assert len(sessions) == 1


# ============================================================
# file_service
# ============================================================

class TestFileService:
    """文件存储服务测试"""

    def test_init_creates_base_dir(self, patch_dirs):
        svc = FileService()
        assert os.path.exists(patch_dirs["upload"])

    def test_save_upload(self, file_service):
        doc_id = "test_save_001"
        data = b"fake pdf content"
        from io import BytesIO
        stream = BytesIO(data)

        path = file_service.save_upload(doc_id, stream, "document.pdf")
        assert doc_id in path
        assert path.endswith(".pdf")
        assert os.path.exists(path)

        with open(path, "rb") as f:
            assert f.read() == data

    def test_save_upload_preserves_extension(self, file_service):
        doc_id = "test_ext"
        stream = BytesIO(b"data")
        path = file_service.save_upload(doc_id, stream, "report.PDF")
        assert path.endswith(".pdf")

    def test_compute_md5(self, file_service):
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
            f.write(b"hello world")
            tmp = f.name
        try:
            md5 = file_service.compute_md5(tmp)
            assert md5 == "5eb63bbbe01eeed093cb22bb8f5acdc3"
        finally:
            os.unlink(tmp)

    def test_compute_md5_bytes(self, file_service):
        md5 = file_service.compute_md5_bytes(b"hello world")
        assert md5 == "5eb63bbbe01eeed093cb22bb8f5acdc3"

    def test_compute_md5_empty(self, file_service):
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
            tmp = f.name
        try:
            md5 = file_service.compute_md5(tmp)
            assert md5 == "d41d8cd98f00b204e9800998ecf8427e"
        finally:
            os.unlink(tmp)

    def test_download_to_local(self, file_service):
        # 先保存一个文件，然后下载
        doc_id = "test_dl"
        data = b"download test"
        saved = file_service.save_upload(doc_id, BytesIO(data), "source.pdf")

        dest = os.path.join(tempfile.gettempdir(), "downloaded.pdf")
        result = file_service.download_to_local(saved, dest)
        assert result == dest
        assert os.path.exists(dest)
        with open(dest, "rb") as f:
            assert f.read() == data
        os.unlink(dest)

    def test_download_to_local_not_found(self, file_service):
        with pytest.raises(FileNotFoundError):
            file_service.download_to_local("/nonexistent/file.pdf", "/tmp/out.pdf")

    def test_ensure_dir(self, file_service):
        with tempfile.TemporaryDirectory() as tmp:
            new_dir = os.path.join(tmp, "a", "b", "c")
            result = file_service.ensure_dir(new_dir)
            assert result == new_dir
            assert os.path.exists(new_dir)

    def test_ensure_dir_idempotent(self, file_service):
        with tempfile.TemporaryDirectory() as tmp:
            file_service.ensure_dir(tmp)
            file_service.ensure_dir(tmp)  # 不报错

    def test_use_oss_raises_not_implemented(self, monkeypatch, patch_dirs):
        monkeypatch.setattr("config.settings.settings.USE_OSS", True)
        svc = FileService()
        with pytest.raises(NotImplementedError, match="OSS download"):
            svc.download_to_local("/remote/path", "/local/path")

    def test_get_doc_dir_creates(self, file_service):
        from core.file_service import FileService
        # 直接访问 _get_doc_dir
        doc_dir = file_service._get_doc_dir("test_dir_doc")
        assert os.path.exists(doc_dir)


# ============================================================
# kafka_service
# ============================================================

class TestKafkaService:
    """Kafka 服务测试（全部 mock）"""

    def test_init(self):
        svc = KafkaService()
        assert svc.bootstrap_servers == "localhost:9092"
        assert svc.topic_parse == "parse_document_topic"

    def test_producer_lazy_init(self, mock_kafka_producer):
        svc = KafkaService()
        svc._producer = None  # 强制重新初始化
        producer = svc.producer
        assert producer is not None

    def test_send_parse_task_success(self, mock_kafka_producer):
        svc = KafkaService()
        svc._producer = mock_kafka_producer

        msg = {"document_id": "doc1", "file_path": "/tmp/1.pdf", "knowledge_base_id": "kb1"}
        result = svc.send_parse_task(msg)
        assert result is True
        mock_kafka_producer.send.assert_called_once()
        args, kwargs = mock_kafka_producer.send.call_args
        assert kwargs["value"]["document_id"] == "doc1"

    def test_send_dead_letter(self, mock_kafka_producer):
        svc = KafkaService()
        svc._producer = mock_kafka_producer

        svc.send_dead_letter({"document_id": "doc1"}, error="test error")
        mock_kafka_producer.send.assert_called_once()
        args, kwargs = mock_kafka_producer.send.call_args
        assert "error" in kwargs["value"]
        assert kwargs["value"]["error"] == "test error"

    def test_close(self, mock_kafka_producer):
        svc = KafkaService()
        svc._producer = mock_kafka_producer
        svc.close()
        mock_kafka_producer.close.assert_called_once()
        assert svc._producer is None

    def test_create_consumer(self, mock_kafka_producer):
        svc = KafkaService()
        consumer = svc.create_consumer(group_id="test-group")
        assert consumer is not None


# ============================================================
# milvus_service
# ============================================================

class TestMilvusService:
    """Milvus 服务测试（全部 mock）"""

    def test_init(self):
        svc = MilvusService()
        assert svc.text_collection_name == "text_chunk"
        assert svc.image_collection_name == "image_chunk"
        assert not svc._connected

    def test_connect(self, mock_milvus):
        svc = MilvusService()
        svc.connect()
        mock_milvus["conn"].connect.assert_called_once()
        assert svc._connected

    def test_connect_idempotent(self, mock_milvus):
        svc = MilvusService()
        svc.connect()
        svc.connect()  # 第二次不应再调用 connect
        mock_milvus["conn"].connect.assert_called_once()

    def test_get_or_create_collection_text(self, mock_milvus):
        mock_milvus["utility"].has_collection.return_value = False
        svc = MilvusService()
        collection = svc.get_or_create_collection("text_chunk")
        assert collection is not None

    def test_get_or_create_collection_image(self, mock_milvus):
        mock_milvus["utility"].has_collection.return_value = False
        svc = MilvusService()
        collection = svc.get_or_create_collection("image_chunk")
        assert collection is not None

    def test_get_or_create_collection_existing(self, mock_milvus):
        mock_milvus["utility"].has_collection.return_value = True
        svc = MilvusService()
        collection = svc.get_or_create_collection("text_chunk")
        assert collection is not None

    def test_get_or_create_collection_unknown(self, mock_milvus):
        mock_milvus["utility"].has_collection.return_value = False
        svc = MilvusService()
        with pytest.raises(ValueError, match="Unknown collection"):
            svc.get_or_create_collection("unknown")

    def test_insert_text_vectors(self, mock_milvus):
        svc = MilvusService()
        entities = [
            {"vector": [0.1]*1024, "document_id": "doc1", "knowledge_base_id": "kb1",
             "chunk_id": "c1", "page_num": 1},
        ]
        ids = svc.insert_text_vectors(entities)
        assert len(ids) == 3

    def test_insert_image_vectors(self, mock_milvus):
        svc = MilvusService()
        entities = [
            {"vector": [0.2]*512, "document_id": "doc1", "knowledge_base_id": "kb1",
             "image_id": "i1", "page_num": 1, "image_path": "/img.png"},
        ]
        ids = svc.insert_image_vectors(entities)
        assert len(ids) == 3

    def test_search_text(self, mock_milvus):
        svc = MilvusService()
        results = svc.search_text([0.1]*1024, "kb1", top_k=3)
        assert len(results) == 1
        assert results[0]["document_id"] == "doc1"
        assert results[0]["distance"] == 0.95

    def test_search_image(self, mock_milvus):
        svc = MilvusService()
        results = svc.search_image([0.2]*512, "kb1", top_k=3)
        assert len(results) == 1

    def test_format_results(self, mock_milvus):
        svc = MilvusService()
        mock_result = MagicMock()
        mock_result.id = 1
        mock_result.distance = 0.85
        mock_result.entity.to_dict.return_value = {"document_id": "d1"}
        # _format_results 接收的是 collection.search 的返回值
        # 直接构造模拟的 collection.search 结果
        class MockResults:
            def __getitem__(self, i):
                return [mock_result]
        svc.search_text([0.1]*1024, "kb1")
        # _format_results 在 search_text 内部被调用

    def test_drop_collection(self, mock_milvus):
        mock_milvus["utility"].has_collection.return_value = True
        svc = MilvusService()
        svc.drop_collection("text_chunk")
        mock_milvus["utility"].drop_collection.assert_called_with("text_chunk")

    def test_drop_collection_not_exists(self, mock_milvus):
        mock_milvus["utility"].has_collection.return_value = False
        svc = MilvusService()
        svc.drop_collection("text_chunk")
        mock_milvus["utility"].drop_collection.assert_not_called()

    def test_close(self, mock_milvus):
        svc = MilvusService()
        svc._connected = True
        svc.close()
        mock_milvus["conn"].disconnect.assert_called_once()
        assert not svc._connected


# ============================================================
# embedding_service
# ============================================================

class TestEmbeddingService:
    """向量化服务测试"""

    def test_init(self):
        svc = EmbeddingService()
        assert not svc.bge_loaded
        assert not svc.clip_loaded

    def test_load_bge_local(self, mock_bge_embedding):
        svc = EmbeddingService()
        svc._load_bge_local()
        assert svc.bge_loaded

    def test_load_clip_local(self, mock_clip_embedding):
        svc = EmbeddingService()
        svc._load_clip_local()
        assert svc.clip_loaded

    def test_load_bge_idempotent(self, mock_bge_embedding):
        svc = EmbeddingService()
        svc._load_bge_local()
        svc._load_bge_local()  # 第二次不应报错
        assert svc.bge_loaded

    def test_embed_text_single(self, mock_bge_embedding):
        svc = EmbeddingService()
        svc.bge_model = mock_bge_embedding
        svc.bge_loaded = True

        result = svc.embed_text("测试文本")
        assert isinstance(result, list)
        assert len(result) == 1024

    def test_embed_text_batch(self, mock_bge_embedding):
        svc = EmbeddingService()
        svc.bge_model = mock_bge_embedding
        svc.bge_loaded = True

        result = svc.embed_text(["文本1", "文本2"])
        assert isinstance(result, list)
        assert len(result) == 2

    def test_embed_text_empty(self, mock_bge_embedding):
        """空字符串应当正常工作"""
        svc = EmbeddingService()
        svc.bge_model = mock_bge_embedding
        svc.bge_loaded = True

        result = svc.embed_text("")
        assert len(result) == 1024

    def test_embed_text_clip(self, mock_clip_embedding):
        svc = EmbeddingService()
        svc.clip_model = mock_clip_embedding
        svc.clip_loaded = True

        result = svc.embed_text_clip("CLIP 文本")
        assert isinstance(result, list)
        assert len(result) == 512

    def test_embed_image(self, mock_clip_embedding):
        svc = EmbeddingService()
        svc.clip_model = mock_clip_embedding
        svc.clip_loaded = True

        # 创建一个临时图片
        import tempfile
        from PIL import Image
        tmp_img = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        img = Image.new("RGB", (100, 100), color="red")
        img.save(tmp_img.name)
        tmp_img.close()

        try:
            result = svc.embed_image(tmp_img.name)
            assert isinstance(result, list)
            assert len(result) == 512
        finally:
            os.unlink(tmp_img.name)

    def test_remote_embed(self):
        """测试远程 API 调用分支"""
        svc = EmbeddingService()
        with patch("requests.post") as mock_post:
            mock_post.return_value.json.return_value = {"embeddings": [[0.1, 0.2]]}
            mock_post.return_value.raise_for_status.return_value = None

            result = svc.embed_text("remote text")
            assert isinstance(result, list)

    def test_embed_text_prefers_remote_api(self, monkeypatch):
        monkeypatch.setattr("config.settings.settings.BGE_API_URL", "http://bge-api:8000/embed")
        svc = EmbeddingService()
        with patch("requests.post") as mock_post:
            mock_post.return_value.json.return_value = {"embeddings": [[0.1] * 1024]}
            mock_post.return_value.raise_for_status.return_value = None

            result = svc.embed_text("remote")
            assert len(result) == 1024

    def test_load_bge_failure(self):
        svc = EmbeddingService()
        with patch("sentence_transformers.SentenceTransformer", side_effect=ImportError("no model")):
            with pytest.raises(Exception):
                svc._load_bge_local()

    def test_embed_text_via_remote_skip_load(self, monkeypatch, mock_bge_embedding):
        """当设置了 API_URL 时不应尝试加载本地模型"""
        monkeypatch.setattr("config.settings.settings.BGE_API_URL", "http://remote:8000")
        svc = EmbeddingService()
        assert not svc.bge_loaded  # 没有被加载

        with patch("requests.post") as mock_post:
            mock_post.return_value.json.return_value = {"embeddings": [[0.1]]}
            mock_post.return_value.raise_for_status.return_value = None
            svc.embed_text("x")
        assert not svc.bge_loaded  # 仍然不应加载

    def test_remote_embed_error(self):
        svc = EmbeddingService()
        with patch("requests.post") as mock_post:
            mock_post.return_value.raise_for_status.side_effect = Exception("API error")
            with pytest.raises(Exception):
                svc.embed_text("x")


# ============================================================
# llm_service
# ============================================================

class TestLLMService:
    """LLM 服务测试"""

    def test_init(self):
        svc = LLMService()
        assert svc.model == "qwen-vl-max"

    def test_chat_success(self, mock_llm):
        svc = LLMService()
        answer = svc.chat(
            question="什么是RAG？",
            context_texts=[{"content": "RAG是检索增强生成", "file_name": "doc1", "page_num": 1}],
        )
        assert answer == "这是 LLM 生成的测试答案。"

    def test_chat_with_images(self, mock_llm):
        svc = LLMService()
        answer = svc.chat(
            question="图片里是什么？",
            context_texts=[],
            context_images=[{
                "image_url": "http://example.com/img.png",
                "file_name": "doc1", "page_num": 1,
            }],
        )
        assert answer is not None

    def test_chat_without_context(self, mock_llm):
        """没有上下文时也应当正常调用"""
        svc = LLMService()
        answer = svc.chat(question="你好", context_texts=[])
        assert answer is not None

    def test_chat_failure(self):
        svc = LLMService()
        svc.api_key = "invalid"
        with patch("openai.OpenAI") as mock_oa:
            mock_oa.side_effect = Exception("connection error")
            with pytest.raises(Exception):
                svc.chat(question="q", context_texts=[])

    def test_build_system_prompt(self):
        """验证系统提示词构建正确"""
        svc = LLMService()
        texts = [{"content": "测试内容", "file_name": "doc.pdf", "page_num": 2}]
        images = [{"image_url": "http://img", "file_name": "doc.pdf", "page_num": 3}]

        prompt = svc._build_system_prompt(texts, images)
        assert "测试内容" in prompt
        assert "doc.pdf" in prompt
        assert "图片" in prompt

    def test_build_system_prompt_no_images(self):
        svc = LLMService()
        prompt = svc._build_system_prompt([{"content": "a", "file_name": "d", "page_num": 1}], [])
        assert "参考图片" not in prompt

    def test_build_user_content(self):
        svc = LLMService()
        content = svc._build_user_content("你好", [])
        assert content[0]["type"] == "text"
        assert content[0]["text"] == "你好"
        assert len(content) == 1

    def test_build_user_content_with_images(self):
        svc = LLMService()
        images = [{"image_url": "http://img1.png", "file_name": "d", "page_num": 1}]
        content = svc._build_user_content("看图说话", images)
        assert len(content) == 2
        assert content[1]["type"] == "image_url"
