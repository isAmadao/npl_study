"""ORM 模型 + Pydantic Schema 测试"""

import pytest
from datetime import datetime

from orm_model import Document, Chunk, Image, Permission, gen_uuid
from models.schemas import (
    ChatRequest, ChatResponse, UploadRequest, UploadResponse,
    SourceInfo, ChatData, DocStatus, ParseTask,
)


class TestOrmModels:
    """SQLAlchemy ORM 模型测试"""

    def test_gen_uuid(self):
        uid = gen_uuid()
        assert isinstance(uid, str)
        assert len(uid) == 32  # hex of 16 bytes

    def test_document_create(self, db_session):
        doc = Document(
            document_id="doc_001",
            knowledge_base_id="kb_001",
            file_name="report.pdf",
            file_hash="md5hash",
            file_size=2048,
            uploader="alice",
            status=DocStatus.PENDING,
        )
        db_session.add(doc)
        db_session.commit()

        saved = db_session.query(Document).filter_by(document_id="doc_001").first()
        assert saved is not None
        assert saved.file_name == "report.pdf"
        assert saved.status == "pending"
        assert saved.upload_time is not None
        assert saved.error_msg == ""

    def test_document_default_status(self, db_session):
        doc = Document(
            document_id="doc_002",
            knowledge_base_id="kb_001",
            file_name="test.pdf",
            uploader="bob",
        )
        db_session.add(doc)
        db_session.commit()
        assert doc.status == "pending"

    def test_document_repr(self):
        doc = Document(document_id="d1", file_name="f.pdf", status="completed")
        assert "Document" in repr(doc)
        assert "d1" in repr(doc)

    def test_chunk_create(self, db_session, sample_document):
        chunk = Chunk(
            chunk_id="chunk_001",
            document_id=sample_document.document_id,
            knowledge_base_id="kb_001",
            page_num=1,
            content="测试文本内容",
            title="第一章",
        )
        db_session.add(chunk)
        db_session.commit()

        saved = db_session.query(Chunk).filter_by(chunk_id="chunk_001").first()
        assert saved is not None
        assert saved.content == "测试文本内容"
        assert saved.page_num == 1

    def test_chunk_relationship(self, db_session, sample_document):
        chunk = Chunk(
            chunk_id="chunk_rel",
            document_id=sample_document.document_id,
            knowledge_base_id="kb_001",
            page_num=2,
            content="内容",
        )
        db_session.add(chunk)
        db_session.commit()

        assert len(sample_document.chunks) == 1
        assert sample_document.chunks[0].chunk_id == "chunk_rel"

    def test_chunk_repr(self):
        c = Chunk(chunk_id="c1", document_id="d1", page_num=1)
        assert "c1" in repr(c)

    def test_image_create(self, db_session, sample_document):
        img = Image(
            image_id="img_001",
            document_id=sample_document.document_id,
            knowledge_base_id="kb_001",
            page_num=5,
            image_path="/path/to/img.png",
        )
        db_session.add(img)
        db_session.commit()

        saved = db_session.query(Image).filter_by(image_id="img_001").first()
        assert saved is not None
        assert saved.image_path == "/path/to/img.png"

    def test_image_relationship(self, db_session, sample_document):
        img = Image(
            image_id="img_rel",
            document_id=sample_document.document_id,
            knowledge_base_id="kb_001",
            page_num=1,
            image_path="/img.png",
        )
        db_session.add(img)
        db_session.commit()
        assert len(sample_document.images) == 1

    def test_image_repr(self):
        img = Image(image_id="i1", document_id="d1", image_path="/x.png")
        assert "i1" in repr(img)

    def test_permission_create(self, db_session):
        perm = Permission(
            user_id="user_001",
            knowledge_base_id="kb_001",
            role="admin",
        )
        db_session.add(perm)
        db_session.commit()

        saved = db_session.query(Permission).filter_by(
            user_id="user_001", knowledge_base_id="kb_001",
        ).first()
        assert saved is not None
        assert saved.role == "admin"

    def test_permission_unique_constraint(self, db_session):
        p1 = Permission(user_id="u1", knowledge_base_id="kb1", role="read")
        db_session.add(p1)
        db_session.commit()

        p2 = Permission(user_id="u1", knowledge_base_id="kb1", role="write")
        db_session.add(p2)
        with pytest.raises(Exception):
            db_session.commit()
        db_session.rollback()

    def test_permission_repr(self):
        p = Permission(user_id="u1", knowledge_base_id="kb1", role="read")
        assert "u1" in repr(p)
        assert "kb1" in repr(p)

    def test_document_cascade_delete(self, db_session, sample_document):
        """删除文档应级联删除关联的 chunks 和 images"""
        Chunk(chunk_id="c_c", document_id=sample_document.document_id,
              knowledge_base_id="kb_001", page_num=1, content="x").save()
        Image(image_id="i_c", document_id=sample_document.document_id,
              knowledge_base_id="kb_001", page_num=1, image_path="/x.png").save()
        db_session.commit()

        db_session.delete(sample_document)
        db_session.commit()

        assert db_session.query(Chunk).filter_by(document_id=sample_document.document_id).count() == 0
        assert db_session.query(Image).filter_by(document_id=sample_document.document_id).count() == 0

    # 对 model_chunk的save方法不存在 但没关系


class TestDocStatus:
    """文档状态枚举测试"""

    def test_all_choices(self):
        assert DocStatus.PENDING == "pending"
        assert DocStatus.PARSING == "parsing"
        assert DocStatus.COMPLETED == "completed"
        assert DocStatus.DOWNLOAD_FAILED == "download_failed"
        assert DocStatus.PARSE_FAILED == "parse_failed"
        assert DocStatus.EMBEDDING_FAILED == "embedding_failed"
        assert DocStatus.SEND_FAILED == "send_failed"
        assert DocStatus.UPLOAD_FAILED == "upload_failed"

    def test_choices_list(self):
        assert len(DocStatus.CHOICES) == 8


class TestPydanticSchemas:
    """Pydantic 请求/响应模型测试"""

    def test_upload_request(self):
        req = UploadRequest(knowledge_base_id="kb_001", uploader="alice")
        assert req.knowledge_base_id == "kb_001"
        assert req.uploader == "alice"

    def test_upload_response_ok(self):
        resp = UploadResponse.ok(document_id="doc_001")
        assert resp.code == 200
        assert resp.message == "success"
        assert resp.data == {"document_id": "doc_001", "is_duplicate": False}

    def test_upload_response_duplicate(self):
        resp = UploadResponse.ok(document_id="doc_001", is_duplicate=True)
        assert resp.data["is_duplicate"] is True

    def test_upload_response_error(self):
        resp = UploadResponse.error(code=400, message="bad request")
        assert resp.code == 400
        assert resp.message == "bad request"
        assert resp.data is None

    def test_chat_request_valid(self):
        req = ChatRequest(
            user_id="user1",
            knowledge_base_id="kb1",
            question="什么是人工智能？",
        )
        assert req.question == "什么是人工智能？"
        assert req.top_k == 5

    def test_chat_request_invalid_empty_question(self):
        with pytest.raises(Exception):
            ChatRequest(user_id="u1", knowledge_base_id="kb1", question="")

    def test_chat_request_invalid_too_long(self):
        with pytest.raises(Exception):
            ChatRequest(user_id="u1", knowledge_base_id="kb1",
                        question="x" * 5000)

    def test_chat_request_top_k_range(self):
        with pytest.raises(Exception):
            ChatRequest(user_id="u1", knowledge_base_id="kb1",
                        question="hi", top_k=0)
        with pytest.raises(Exception):
            ChatRequest(user_id="u1", knowledge_base_id="kb1",
                        question="hi", top_k=100)

    def test_source_info(self):
        src = SourceInfo(file_name="test.pdf", page_num=3, type="text")
        assert src.file_name == "test.pdf"
        assert src.type == "text"

    def test_source_info_image(self):
        src = SourceInfo(file_name="img.png", page_num=1, type="image")
        assert src.type == "image"

    def test_chat_data(self):
        sources = [
            SourceInfo(file_name="a.pdf", page_num=1, type="text"),
        ]
        data = ChatData(answer="测试答案", sources=sources)
        assert data.answer == "测试答案"
        assert len(data.sources) == 1

    def test_chat_response_ok(self):
        sources = [SourceInfo(file_name="a.pdf", page_num=1, type="text")]
        resp = ChatResponse.ok(answer="答案", sources=sources)
        assert resp.code == 200
        assert resp.data.answer == "答案"
        assert len(resp.data.sources) == 1

    def test_chat_response_error(self):
        resp = ChatResponse.error(code=500, message="LLM error")
        assert resp.code == 500
        assert resp.message == "LLM error"
        assert resp.data is None

    def test_chat_response_empty_sources(self):
        resp = ChatResponse.ok(answer="答案", sources=[])
        assert len(resp.data.sources) == 0

    def test_parse_task(self):
        task = ParseTask(
            document_id="doc_001",
            file_path="/tmp/test.pdf",
            knowledge_base_id="kb_001",
        )
        assert task.document_id == "doc_001"
        assert task.retry_count == 0

    def test_parse_task_with_retry(self):
        task = ParseTask(
            document_id="doc_001",
            file_path="/tmp/test.pdf",
            knowledge_base_id="kb_001",
            retry_count=2,
        )
        assert task.retry_count == 2
