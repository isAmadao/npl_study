"""API 路由测试 — upload + chat，使用 FastAPI TestClient"""

import io
import json
import os
from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from core.database import get_db


class TestUploadAPI:
    """文件上传 API 测试"""

    def test_upload_success(self, client, db_session, mock_kafka_producer):
        """正常上传 PDF"""
        kwargs = {
            "data": {
                "knowledge_base_id": "kb_001",
                "uploader": "alice",
            },
            "files": {
                "file": ("test.pdf", b"%PDF-1.4 fake content", "application/pdf"),
            },
        }
        resp = client.post("/api/upload/document", **kwargs)
        assert resp.status_code == 200
        body = resp.json()
        assert body["code"] == 200
        assert "document_id" in body["data"]
        assert body["data"]["is_duplicate"] is False

    def test_upload_invalid_extension(self, client):
        """非 PDF 格式应返回 400"""
        kwargs = {
            "data": {"knowledge_base_id": "kb1", "uploader": "alice"},
            "files": {"file": ("test.txt", b"hello", "text/plain")},
        }
        resp = client.post("/api/upload/document", **kwargs)
        assert resp.status_code == 400
        assert "仅支持 PDF" in resp.json()["detail"]

    def test_upload_file_too_large(self, client):
        """超过 100MB 应拒绝"""
        big_content = b"x" * (101 * 1024 * 1024)
        kwargs = {
            "data": {"knowledge_base_id": "kb1", "uploader": "alice"},
            "files": {"file": ("big.pdf", big_content, "application/pdf")},
        }
        resp = client.post("/api/upload/document", **kwargs)
        assert resp.status_code == 400
        assert "超过限制" in resp.json()["detail"]

    def test_upload_duplicate(self, client, db_session, mock_kafka_producer):
        """相同 MD5 应检测为重复文档"""
        data = b"duplicate content"
        kwargs = {
            "data": {"knowledge_base_id": "kb_dedup", "uploader": "alice"},
            "files": {"file": ("dup.pdf", data, "application/pdf")},
        }
        resp1 = client.post("/api/upload/document", **kwargs)
        assert resp1.status_code == 200
        doc_id = resp1.json()["data"]["document_id"]

        kwargs2 = {
            "data": {"knowledge_base_id": "kb_dedup", "uploader": "alice"},
            "files": {"file": ("dup2.pdf", data, "application/pdf")},
        }
        resp2 = client.post("/api/upload/document", **kwargs2)
        assert resp2.status_code == 200
        body2 = resp2.json()
        assert body2["data"]["document_id"] == doc_id
        assert body2["data"]["is_duplicate"] is True

    def test_upload_kafka_failure(self, client, db_session, mock_kafka_producer):
        """Kafka 发送失败应返回 500"""
        mock_kafka_producer.send.side_effect = Exception("Kafka broker unavailable")

        kwargs = {
            "data": {"knowledge_base_id": "kb_kafka_fail", "uploader": "alice"},
            "files": {"file": ("fail.pdf", b"content", "application/pdf")},
        }
        resp = client.post("/api/upload/document", **kwargs)
        assert resp.status_code == 500
        assert "消息发送失败" in resp.json()["detail"]

    def test_upload_missing_file(self, client):
        """没有上传文件时"""
        resp = client.post("/api/upload/document", data={
            "knowledge_base_id": "kb1", "uploader": "u1",
        })
        assert resp.status_code == 422

    def test_upload_empty_filename(self, client):
        """文件名为空"""
        kwargs = {
            "data": {"knowledge_base_id": "kb1", "uploader": "u1"},
            "files": {"file": ("", b"data", "application/pdf")},
        }
        resp = client.post("/api/upload/document", **kwargs)
        assert resp.status_code == 400

    def test_upload_preserves_original_name(self, client, db_session, mock_kafka_producer):
        """上传后数据库中的 file_name 应为原始名称"""
        kwargs = {
            "data": {"knowledge_base_id": "kb_name", "uploader": "alice"},
            "files": {"file": ("年报2026.pdf", b"data", "application/pdf")},
        }
        resp = client.post("/api/upload/document", **kwargs)
        assert resp.status_code == 200

        from orm_model import Document
        doc = db_session.query(Document).filter_by(knowledge_base_id="kb_name").first()
        assert doc.file_name == "年报2026.pdf"

    def test_health_check(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"


class TestChatAPI:
    """多模态问答 API 测试"""

    @patch("core.embedding_service.EmbeddingService.embed_text")
    @patch("core.embedding_service.EmbeddingService.embed_text_clip")
    @patch("core.milvus_service.MilvusService.search_text")
    @patch("core.milvus_service.MilvusService.search_image")
    @patch("core.llm_service.LLMService.chat")
    def test_chat_success(
        self, mock_llm, mock_search_image, mock_search_text,
        mock_embed_clip, mock_embed_text, client, db_session,
    ):
        """正常问答流程"""
        # 准备权限
        from orm_model import Permission
        perm = Permission(user_id="user1", knowledge_base_id="kb_chat", role="read")
        db_session.add(perm)
        db_session.commit()

        # Mock 向量化
        mock_embed_text.return_value = [0.1] * 1024
        mock_embed_clip.return_value = [0.2] * 512

        # Mock 检索结果
        mock_search_text.return_value = [
            {"id": 1, "distance": 0.9, "document_id": "doc1",
             "chunk_id": "c1", "page_num": 1, "knowledge_base_id": "kb_chat"},
        ]
        mock_search_image.return_value = [
            {"id": 2, "distance": 0.8, "document_id": "doc1",
             "image_id": "i1", "page_num": 2, "image_path": "/img.png",
             "knowledge_base_id": "kb_chat"},
        ]

        # Mock LLM
        mock_llm.return_value = "RAG 是检索增强生成技术。"

        resp = client.post("/api/chat", json={
            "user_id": "user1",
            "knowledge_base_id": "kb_chat",
            "question": "什么是RAG？",
        })
        assert resp.status_code == 200
        body = resp.json()
        assert body["code"] == 200
        assert "RAG" in body["data"]["answer"]
        assert len(body["data"]["sources"]) == 2

    def test_chat_no_permission(self, client, db_session):
        """无权访问知识库"""
        resp = client.post("/api/chat", json={
            "user_id": "unauthorized_user",
            "knowledge_base_id": "kb_nonexistent",
            "question": "测试",
        })
        assert resp.status_code == 403

    @patch("api.chat_api.limiter")
    def test_chat_rate_limited(self, mock_limiter, client, db_session):
        """超过频率限制"""
        from orm_model import Permission
        perm = Permission(user_id="user_limited", knowledge_base_id="kb_limit", role="read")
        db_session.add(perm)
        db_session.commit()

        mock_limiter.check.return_value = False

        resp = client.post("/api/chat", json={
            "user_id": "user_limited",
            "knowledge_base_id": "kb_limit",
            "question": "测试",
        })
        assert resp.status_code == 429

    @patch("core.embedding_service.EmbeddingService.embed_text")
    @patch("core.embedding_service.EmbeddingService.embed_text_clip")
    @patch("core.milvus_service.MilvusService.search_text")
    @patch("core.milvus_service.MilvusService.search_image")
    def test_chat_no_relevant_content(
        self, mock_search_image, mock_search_text,
        mock_embed_clip, mock_embed_text, client, db_session,
    ):
        """无检索结果时的响应"""
        from orm_model import Permission
        perm = Permission(user_id="user2", knowledge_base_id="kb_empty", role="read")
        db_session.add(perm)
        db_session.commit()

        mock_embed_text.return_value = [0.1] * 1024
        mock_embed_clip.return_value = [0.2] * 512
        mock_search_text.return_value = []
        mock_search_image.return_value = []

        resp = client.post("/api/chat", json={
            "user_id": "user2",
            "knowledge_base_id": "kb_empty",
            "question": "不存在的内容",
        })
        assert resp.status_code == 200
        assert resp.json()["data"]["answer"] == "暂无相关信息"

    @patch("core.embedding_service.EmbeddingService.embed_text")
    @patch("core.embedding_service.EmbeddingService.embed_text_clip")
    @patch("core.milvus_service.MilvusService.search_text")
    @patch("core.milvus_service.MilvusService.search_image")
    @patch("core.llm_service.LLMService.chat")
    def test_chat_llm_failure(
        self, mock_llm, mock_search_image, mock_search_text,
        mock_embed_clip, mock_embed_text, client, db_session,
    ):
        """LLM 调用失败时的降级响应"""
        from orm_model import Permission
        perm = Permission(user_id="user3", knowledge_base_id="kb_llm_fail", role="read")
        db_session.add(perm)
        db_session.commit()

        mock_embed_text.return_value = [0.1] * 1024
        mock_embed_clip.return_value = [0.2] * 512
        mock_search_text.return_value = [
            {"id": 1, "distance": 0.9, "document_id": "d1",
             "chunk_id": "c1", "page_num": 1, "knowledge_base_id": "kb_llm_fail"},
        ]
        mock_search_image.return_value = []
        mock_llm.side_effect = Exception("LLM timeout")

        resp = client.post("/api/chat", json={
            "user_id": "user3",
            "knowledge_base_id": "kb_llm_fail",
            "question": "测试",
        })
        assert resp.status_code == 200
        body = resp.json()
        assert body["code"] == 500
        assert "不可用" in body["message"]

    def test_chat_invalid_input(self, client):
        """无效输入"""
        resp = client.post("/api/chat", json={
            "user_id": "u1",
            "knowledge_base_id": "kb1",
            "question": "",
        })
        assert resp.status_code == 422

        resp2 = client.post("/api/chat", json={
            "user_id": "u1",
            "knowledge_base_id": "kb1",
            "question": "x" * 5000,
        })
        assert resp2.status_code == 422

    @patch("core.embedding_service.EmbeddingService.embed_text")
    @patch("core.embedding_service.EmbeddingService.embed_text_clip")
    @patch("core.milvus_service.MilvusService.search_text")
    @patch("core.milvus_service.MilvusService.search_image")
    def test_chat_image_only(
        self, mock_search_image, mock_search_text,
        mock_embed_clip, mock_embed_text, client, db_session,
    ):
        """只有图片检索结果的场景"""
        from orm_model import Permission
        perm = Permission(user_id="user_img", knowledge_base_id="kb_img", role="read")
        db_session.add(perm)
        db_session.commit()

        mock_embed_text.return_value = [0.1] * 1024
        mock_embed_clip.return_value = [0.2] * 512
        mock_search_text.return_value = []
        mock_search_image.return_value = [
            {"id": 1, "distance": 0.85, "document_id": "d1",
             "image_id": "i1", "page_num": 3, "image_path": "/img.png",
             "knowledge_base_id": "kb_img"},
        ]

        with patch("core.llm_service.LLMService.chat") as mock_llm:
            mock_llm.return_value = "图片描述了系统架构"

            resp = client.post("/api/chat", json={
                "user_id": "user_img",
                "knowledge_base_id": "kb_img",
                "question": "架构图是什么",
            })
            assert resp.status_code == 200
            body = resp.json()
            assert len(body["data"]["sources"]) == 1
            assert body["data"]["sources"][0]["type"] == "image"
