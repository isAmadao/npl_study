"""离线 Worker 集成流程测试 — 模拟 Kafka → 解析 → 向量化全链路"""

import json
import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from models.schemas import DocStatus


class TestWorker:
    """离线解析 Worker 测试"""

    @pytest.fixture
    def worker(self, patch_dirs, monkeypatch):
        """构造 Worker 实例，全部外部依赖 mock"""
        from offline_process_worker import Worker
        w = Worker()

        # Mock 所有外部依赖
        w.kafka = MagicMock()
        w.file_service = MagicMock()
        w.milvus = MagicMock()
        w.embedding = MagicMock()
        w.pdf_parser = MagicMock()
        w.chunk_splitter = MagicMock()
        w.vectorize_pipeline = MagicMock()

        return w

    def test_init(self, patch_dirs):
        from offline_process_worker import Worker
        w = Worker()
        assert w.running is True
        assert os.path.exists(patch_dirs["processed"])

    def test_update_status_success(self, db_session, worker):
        """验证状态更新"""
        from orm_model import Document
        doc = Document(
            document_id="status_test",
            knowledge_base_id="kb1",
            file_name="t.pdf",
            uploader="u1",
        )
        db_session.add(doc)
        db_session.commit()

        # 将 Worker 内部数据库替换为测试 session
        worker._update_status = MagicMock()

    def test_update_status_document_not_found(self, db_session, worker):
        """更新不存在的文档不应报错"""
        worker._update_status = MagicMock()

    def test_process_task_success(self, worker):
        """完整任务处理流程（Mock 外部依赖）"""
        task = {
            "document_id": "doc_success",
            "file_path": "/tmp/doc_success/test.pdf",
            "knowledge_base_id": "kb_success",
        }

        # Mock 解析结果
        worker.pdf_parser.parse.return_value = {
            "markdown": "/tmp/processed/doc_success/output.md",
            "images": ["/tmp/img1.png"],
        }

        # Mock 分块
        worker.chunk_splitter.split.return_value = [
            {"content": "第一章 内容", "page_num": 1, "title": "第一章"},
        ]

        # Mock 向量化文本
        worker.vectorize_pipeline.process_chunks.return_value = ["doc_success_chunk_0"]

        # Mock 向量化图片
        worker.vectorize_pipeline.process_images.return_value = [
            {"image_id": "doc_success_img_0", "image_path": "/tmp/img1.png"},
        ]

        # 执行任务
        worker.process_task(task)

        # 验证流程
        assert worker._update_status.called
        worker.pdf_parser.parse.assert_called_once_with(
            os.path.join(worker.processed_dir, "doc_success", "source.pdf"),
            str(worker.processed_dir / "doc_success"),
        )
        worker.vectorize_pipeline.process_chunks.assert_called_once()
        worker.vectorize_pipeline.process_images.assert_called_once()

    def test_process_task_download_failure(self, worker, monkeypatch):
        """PDF 下载失败应更新为 download_failed"""
        task = {
            "document_id": "doc_dl_fail",
            "file_path": "/tmp/nonexistent.pdf",
            "knowledge_base_id": "kb1",
        }

        # file_service.download_to_local 抛出异常
        worker.file_service.download_to_local.side_effect = FileNotFoundError("File not found")

        worker.process_task(task)

        # 验证更新状态
        status_calls = []
        for call in worker._update_status.call_args_list:
            status_calls.append(call[0][1])
        assert DocStatus.DOWNLOAD_FAILED in status_calls

    def test_process_task_parse_failure(self, worker):
        """PDF 解析失败应更新为 parse_failed"""
        task = {
            "document_id": "doc_parse_fail",
            "file_path": "/tmp/test.pdf",
            "knowledge_base_id": "kb1",
        }

        worker.pdf_parser.parse.side_effect = Exception("Parse error")

        worker.process_task(task)

        status_calls = []
        for call in worker._update_status.call_args_list:
            status_calls.append(call[0][1])
        assert DocStatus.PARSE_FAILED in status_calls

    def test_process_task_embedding_failure(self, worker):
        """文本向量化失败应更新为 embedding_failed"""
        task = {
            "document_id": "doc_emb_fail",
            "file_path": "/tmp/test.pdf",
            "knowledge_base_id": "kb1",
        }

        worker.pdf_parser.parse.return_value = {
            "markdown": "/tmp/output.md",
            "images": [],
        }
        worker.chunk_splitter.split.return_value = [
            {"content": "test", "page_num": 1, "title": "t"},
        ]
        worker.vectorize_pipeline.process_chunks.side_effect = Exception("Embedding error")

        worker.process_task(task)

        status_calls = []
        for call in worker._update_status.call_args_list:
            status_calls.append(call[0][1])
        assert DocStatus.EMBEDDING_FAILED in status_calls

    def test_save_chunk_meta_integration(self, db_session, worker):
        """保存 chunk 元信息到数据库"""
        chunk = {"content": "测试内容", "page_num": 2, "title": "测试标题"}

        # 替换 Worker 的数据库操作为真实调用
        from offline_process_worker import Worker
        def real_save(chunk_dict, doc_id, kb_id, embedding_id=""):
            from orm_model import Chunk as ChunkModel
            from core.database import get_db
            db = get_db()
            try:
                c = ChunkModel(
                    document_id=doc_id,
                    knowledge_base_id=kb_id,
                    page_num=chunk_dict.get("page_num", 0),
                    content=chunk_dict["content"],
                    title=chunk_dict.get("title", ""),
                    embedding_id=embedding_id,
                )
                db.add(c)
                db.commit()
            finally:
                db.close()

        worker._save_chunk_meta = real_save
        worker._save_chunk_meta(chunk, "doc123", "kb123", "emb456")

        from orm_model import Chunk
        saved = db_session.query(Chunk).filter_by(document_id="doc123").first()
        assert saved is not None
        assert saved.content == "测试内容"
        assert saved.page_num == 2
        assert saved.title == "测试标题"

    def test_save_image_meta_integration(self, db_session, worker):
        """保存图片元信息到数据库"""
        image_info = {"image_id": "img001", "image_path": "/imgs/1.png", "page_num": 3}

        from offline_process_worker import Worker
        def real_save(img_info, doc_id, kb_id):
            from orm_model import Image as ImageModel
            from core.database import get_db
            db = get_db()
            try:
                img = ImageModel(
                    document_id=doc_id,
                    knowledge_base_id=kb_id,
                    page_num=img_info.get("page_num", 0),
                    image_path=img_info["image_path"],
                    embedding_id=img_info.get("embedding_id", ""),
                )
                db.add(img)
                db.commit()
            finally:
                db.close()

        worker._save_image_meta = real_save
        worker._save_image_meta(image_info, "doc_img", "kb_img")

        from orm_model import Image
        saved = db_session.query(Image).filter_by(document_id="doc_img").first()
        assert saved is not None
        assert saved.image_path == "/imgs/1.png"

    def test_process_task_null_markdown(self, worker):
        """解析结果没有 markdown 时仍可继续"""
        task = {
            "document_id": "doc_no_md",
            "file_path": "/tmp/test.pdf",
            "knowledge_base_id": "kb1",
        }

        worker.pdf_parser.parse.return_value = {
            "markdown": "",
            "images": [],
        }
        worker.chunk_splitter.split.return_value = []
        worker.vectorize_pipeline.process_chunks.return_value = []

        # 不应报错
        worker.process_task(task)

    def test_signal_handler(self, worker):
        """信号处理应设置 running=False"""
        worker._signal_handler(None, None)
        assert not worker.running

    def test_process_task_sends_dead_letter_on_failure(self, worker):
        """处理失败应发送死信"""
        task = {
            "document_id": "doc_dlq",
            "file_path": "/tmp/none.pdf",
            "knowledge_base_id": "kb1",
        }

        worker.file_service.download_to_local.side_effect = Exception("Fatal")

        worker.process_task(task)

        worker.kafka.send_dead_letter.assert_called_once()
        args, kwargs = worker.kafka.send_dead_letter.call_args
        assert args[0]["document_id"] == "doc_dlq"
        assert "error" in args[1]
