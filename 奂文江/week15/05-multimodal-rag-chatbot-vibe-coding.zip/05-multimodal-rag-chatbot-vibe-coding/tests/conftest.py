"""pytest 共享夹具"""

import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from orm_model import Base, Document, Chunk, Image, Permission
from models.schemas import (
    ChatRequest, ChatResponse, UploadRequest, UploadResponse,
    SourceInfo, ChatData, DocStatus, ParseTask,
)
from core.database import SessionLocal
from core.file_service import FileService
from core.kafka_service import KafkaService
from core.milvus_service import MilvusService
from core.embedding_service import EmbeddingService
from core.llm_service import LLMService
from worker.chunk_splitter import ChunkSplitter
from worker.pdf_parser import PdfParser
from worker.vectorize_pipeline import VectorizePipeline


# ============================================================
# 数据库夹具 — 使用内存 SQLite
# ============================================================

@pytest.fixture(scope="session")
def engine():
    """全局内存 SQLite 引擎"""
    e = create_engine("sqlite:///:memory:", echo=False)
    Base.metadata.create_all(e)
    return e


@pytest.fixture
def db_session(engine):
    """每个测试一个独立事务，测试回滚不留残留"""
    connection = engine.connect()
    transaction = connection.begin()
    session_maker = sessionmaker(bind=connection)
    session = session_maker()

    yield session

    session.close()
    transaction.rollback()
    connection.close()


@pytest.fixture
def patch_db_session(monkeypatch, db_session):
    """将 core.database.get_db 返回测试 session"""
    def mock_get_db():
        yield db_session

    def mock_get_db_direct():
        return db_session

    monkeypatch.setattr("core.database.get_session", mock_get_db)
    monkeypatch.setattr("core.database.get_db", mock_get_db_direct)
    return db_session


# ============================================================
# 临时文件系统夹具
# ============================================================

@pytest.fixture
def tmp_upload_dir():
    """临时上传目录"""
    with tempfile.TemporaryDirectory() as tmp:
        yield tmp


@pytest.fixture
def tmp_processed_dir():
    """临时处理目录"""
    with tempfile.TemporaryDirectory() as tmp:
        yield tmp


@pytest.fixture
def patch_dirs(monkeypatch, tmp_upload_dir, tmp_processed_dir):
    """覆盖 settings 中的目录路径"""
    import config.settings as cfg
    monkeypatch.setattr(cfg.settings, "UPLOAD_BASE_PATH", tmp_upload_dir)
    monkeypatch.setattr(cfg.settings, "PDF_PROCESSED_DIR", tmp_processed_dir)
    return {"upload": tmp_upload_dir, "processed": tmp_processed_dir}


# ============================================================
# 真实服务实例（部分可用小范围测试）
# ============================================================

@pytest.fixture
def file_service(patch_dirs):
    return FileService()


@pytest.fixture
def chunk_splitter():
    return ChunkSplitter(chunk_size=100, chunk_overlap=20)


# ============================================================
# Mock 服务夹具
# ============================================================

@pytest.fixture
def mock_kafka_producer():
    """Mock Kafka 生产者"""
    with patch("kafka.KafkaProducer") as mock:
        instance = mock.return_value
        instance.send.return_value.get.return_value = MagicMock(
            topic="test", partition=0, offset=0,
        )
        yield instance


@pytest.fixture
def mock_milvus():
    """Mock pymilvus 连接和集合"""
    with patch("pymilvus.connections") as mock_conn, \
         patch("pymilvus.Collection") as mock_collection, \
         patch("pymilvus.utility") as mock_utility:

        mock_utility.has_collection.return_value = False
        mock_collection.return_value.insert.return_value = MagicMock(
            primary_keys=[1, 2, 3],
        )
        mock_collection.return_value.search.return_value = [
            [
                MagicMock(
                    id=1, distance=0.95,
                    entity=MagicMock(to_dict=lambda: {
                        "document_id": "doc1", "chunk_id": "chunk_0",
                        "page_num": 1, "knowledge_base_id": "kb1",
                    }),
                ),
            ]
        ]
        yield {
            "conn": mock_conn,
            "collection": mock_collection,
            "utility": mock_utility,
        }


@pytest.fixture
def mock_bge_embedding():
    """Mock BGE sentence-transformer"""
    with patch("sentence_transformers.SentenceTransformer") as mock_st:
        model = mock_st.return_value
        model.encode.return_value.tolist.return_value = [[0.1] * 1024]
        yield model


@pytest.fixture
def mock_clip_embedding():
    """Mock CLIP sentence-transformer"""
    with patch("sentence_transformers.SentenceTransformer") as mock_st:
        model = mock_st.return_value
        model.encode.return_value.tolist.return_value = [[0.2] * 512]
        yield model


@pytest.fixture
def mock_llm():
    """Mock OpenAI / DashScope LLM 调用"""
    with patch("openai.OpenAI") as mock_openai:
        client = mock_openai.return_value
        choice = MagicMock()
        choice.message.content = "这是 LLM 生成的测试答案。"
        client.chat.completions.create.return_value = MagicMock(choices=[choice])
        yield client


@pytest.fixture
def mock_mineru(mineru_response=None):
    """Mock MinerU API 调用"""
    if mineru_response is None:
        mineru_response = {
            "markdown": "/tmp/test/output.md",
            "images": ["/tmp/test/img1.png", "/tmp/test/img2.png"],
        }

    with patch("requests.post") as mock_post:
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = mineru_response
        mock_post.return_value = resp
        yield mock_post


# ============================================================
# 测试数据构建器
# ============================================================

@pytest.fixture
def sample_document(db_session):
    """创建示例文档记录"""
    doc = Document(
        document_id="test_doc_001",
        knowledge_base_id="kb_001",
        file_name="test.pdf",
        file_hash="abc123",
        file_size=1024,
        uploader="user1",
        status=DocStatus.PENDING,
        original_path="/tmp/test.pdf",
    )
    db_session.add(doc)
    db_session.commit()
    return doc


@pytest.fixture
def sample_chunks():
    return [
        {"content": "第一章 人工智能概述", "page_num": 1, "title": "第一章"},
        {"content": "第二章 机器学习基础 监督学习 无监督学习 强化学习", "page_num": 2, "title": "第二章"},
        {"content": "第三章 深度学习 神经网络 CNN RNN", "page_num": 3, "title": "第三章"},
    ]


@pytest.fixture
def sample_image_paths():
    return ["/tmp/img1.png", "/tmp/img2.png"]


@pytest.fixture
def sample_pdf_content():
    """构造一个简单的测试 PDF 内容（纯文本）"""
    return b"%PDF-1.4 test content"


# ============================================================
# FastAPI TestClient 夹具
# ============================================================

@pytest.fixture
def client(patch_db_session, mock_kafka_producer):
    """FastAPI 测试客户端"""
    from fastapi.testclient import TestClient
    from main import app
    return TestClient(app)
