"""工具模块测试 — retry, logger, limiter"""

import asyncio
import logging
import time

import pytest

from utils.retry import retry
from utils.logger import setup_logger, get_trace_id, set_trace_id, TraceIdFilter
from utils.limiter import TokenBucket, UserRateLimiter


# ============================================================
# retry 装饰器
# ============================================================

class TestRetry:
    """retry 装饰器测试"""

    def test_sync_success_no_retry(self):
        call_count = 0

        @retry(max_retries=2)
        def foo():
            nonlocal call_count
            call_count += 1
            return "ok"

        assert foo() == "ok"
        assert call_count == 1

    def test_sync_retry_then_success(self):
        call_count = 0

        @retry(max_retries=3, delay=0.01)
        def foo():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("temporary error")
            return "ok"

        assert foo() == "ok"
        assert call_count == 3

    def test_sync_retry_exhausted(self):
        call_count = 0

        @retry(max_retries=2, delay=0.01)
        def foo():
            nonlocal call_count
            call_count += 1
            raise ValueError("always fail")

        with pytest.raises(ValueError, match="always fail"):
            foo()
        assert call_count == 3  # 1 original + 2 retries

    # 由于 asyncio 测试循环问题将 retry 测试稍微拆分

    def test_sync_respects_exception_type(self):
        call_count = 0

        @retry(max_retries=2, delay=0.01, exceptions=ValueError)
        def foo():
            nonlocal call_count
            call_count += 1
            raise TypeError("should not be caught")

        with pytest.raises(TypeError):
            foo()
        assert call_count == 1  # 不会重试，因为 TypeError 不在白名单

    def test_on_retry_callback(self):
        call_count = 0
        callback_args = []

        def on_retry(exc, attempt, max_retries):
            callback_args.append((exc, attempt, max_retries))

        @retry(max_retries=2, delay=0.01, on_retry=on_retry)
        def foo():
            nonlocal call_count
            call_count += 1
            raise ValueError("fail")

        with pytest.raises(ValueError):
            foo()
        assert len(callback_args) == 2

    @pytest.mark.asyncio
    async def test_async_retry_success(self):
        call_count = 0

        @retry(max_retries=2, delay=0.01)
        async def foo():
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ValueError("temp fail")
            return "ok"

        result = await foo()
        assert result == "ok"
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_async_retry_exhausted(self):
        call_count = 0

        @retry(max_retries=1, delay=0.01)
        async def foo():
            nonlocal call_count
            call_count += 1
            raise RuntimeError("fail")

        with pytest.raises(RuntimeError):
            await foo()
        assert call_count == 2


# ============================================================
# logger
# ============================================================

class TestLogger:
    """日志工具测试"""

    def test_setup_logger(self):
        logger = setup_logger("test_logger", level=logging.DEBUG)
        assert logger.name == "test_logger"
        assert logger.level == logging.DEBUG
        assert len(logger.handlers) > 0

    @pytest.mark.asyncio
    async def test_setup_logger_idempotent(self):
        logger = setup_logger("test_idempotent")
        logger2 = setup_logger("test_idempotent")
        assert logger is logger2

    def test_trace_id_initial_empty(self):
        # 在默认 ContextVar 环境中，应返回空字符串
        assert get_trace_id() == ""

    def test_set_trace_id_generates(self):
        tid = set_trace_id()
        assert len(tid) == 16
        assert get_trace_id() == tid

    def test_set_trace_id_custom(self):
        tid = set_trace_id("my_custom_id")
        assert tid == "my_custom_id"
        assert get_trace_id() == "my_custom_id"

    def test_set_trace_id_reset(self):
        set_trace_id("first")
        set_trace_id("second")
        assert get_trace_id() == "second"

    def test_trace_id_filter(self):
        record = logging.LogRecord(
            name="test", level=logging.INFO,
            pathname="", lineno=0, msg="hello", args=(), exc_info=None,
        )
        filter_obj = TraceIdFilter()
        assert filter_obj.filter(record) is True
        assert hasattr(record, "trace_id")
        assert record.trace_id != ""

    def test_setup_logger_uses_trace_id(self):
        logger = setup_logger("trace_test", level=logging.DEBUG)
        has_trace_filter = any(
            isinstance(f, TraceIdFilter) for h in logger.handlers for f in h.filters
        )
        assert has_trace_filter


# ============================================================
# limiter
# ============================================================

class TestTokenBucket:
    """令牌桶限流器测试"""

    def test_init(self):
        bucket = TokenBucket(rate=1.0, burst=5)
        assert bucket.tokens == 5
        assert bucket.rate == 1.0

    def test_acquire_within_burst(self):
        bucket = TokenBucket(rate=10.0, burst=5)
        for _ in range(5):
            assert bucket.acquire() is True

    def test_acquire_exhausted(self):
        bucket = TokenBucket(rate=10.0, burst=2)
        assert bucket.acquire() is True
        assert bucket.acquire() is True
        assert bucket.acquire() is False  # 令牌耗尽

    def test_refill_over_time(self):
        bucket = TokenBucket(rate=10.0, burst=2)
        bucket.acquire()
        bucket.acquire()
        assert bucket.acquire() is False
        # 快进时间
        bucket.last_refill -= 0.2  # 20ms 过去，应补充 2 个令牌
        assert bucket.acquire() is True

    def test_burst_refill_full(self):
        bucket = TokenBucket(rate=5.0, burst=3)
        bucket.acquire()
        bucket.acquire()
        bucket.acquire()
        assert bucket.tokens == 0
        # 快进 1 秒
        bucket.last_refill -= 1.0
        bucket._refill()
        # 应恢复 burst 个令牌
        assert bucket.tokens == 3

    def test_multiple_acquire_tokens(self):
        bucket = TokenBucket(rate=10.0, burst=10)
        assert bucket.acquire(tokens=5) is True
        assert bucket.acquire(tokens=3) is True
        assert bucket.acquire(tokens=3) is False  # 只剩 2 个


class TestUserRateLimiter:
    """按用户限流器测试"""

    def test_default_rate(self):
        limiter = UserRateLimiter(default_rate=5.0)
        assert limiter.default_rate == 5.0

    def test_get_bucket_creates_new(self):
        limiter = UserRateLimiter()
        bucket = limiter.get_bucket("user_a")
        assert bucket is not None
        # 同一个用户返回同一个桶
        assert limiter.get_bucket("user_a") is bucket

    def test_check_returns_bool(self):
        limiter = UserRateLimiter(default_rate=100.0)  # 高速率
        assert limiter.check("user_a") is True

    def test_check_exhausted(self):
        limiter = UserRateLimiter(default_rate=0.1)  # 低速率
        assert limiter.check("user_b") is True
        assert limiter.check("user_b") is True  # burst=2
        assert limiter.check("user_b") is False  # 耗尽

    def test_isolated_users(self):
        """不同用户的限流桶互不影响"""
        limiter = UserRateLimiter(default_rate=0.1)
        limiter.check("user_a")
        limiter.check("user_a")
        assert limiter.check("user_a") is False
        assert limiter.check("user_b") is True  # user_b 还有额度
