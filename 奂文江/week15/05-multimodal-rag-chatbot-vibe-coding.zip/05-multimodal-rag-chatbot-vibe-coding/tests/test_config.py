"""配置模块测试"""

import os
import pytest


class TestSettings:
    """全局配置测试"""

    def test_default_settings(self):
        from config.settings import settings
        assert settings.PROJECT_NAME == "MultiModal RAG Chatbot"
        assert settings.VERSION == "1.0.0"
        assert settings.DEBUG is False
        assert settings.MAX_FILE_SIZE_MB == 100
        assert ".pdf" in settings.ALLOWED_EXTENSIONS
        assert settings.KAFKA_BOOTSTRAP_SERVERS == "localhost:9092"
        assert settings.KAFKA_TOPIC_PARSE == "parse_document_topic"
        assert settings.MILVUS_HOST == "localhost"
        assert settings.MILVUS_PORT == 19530
        assert settings.MILVUS_TEXT_COLLECTION == "text_chunk"
        assert settings.MILVUS_IMAGE_COLLECTION == "image_chunk"
        assert settings.MILVUS_INDEX_TYPE == "IVF_FLAT"
        assert settings.MILVUS_METRIC_TYPE == "IP"
        assert settings.CHUNK_SIZE == 1000
        assert settings.CHUNK_OVERLAP == 200
        assert settings.RETRIEVAL_TOP_K == 5
        assert settings.RATE_LIMIT_PER_USER == 2
        assert settings.LLM_MODEL == "qwen-vl-max"
        assert settings.LLM_TEMPERATURE == 0.7

    def test_oss_default_disabled(self):
        from config.settings import settings
        assert settings.USE_OSS is False
        assert settings.OSS_ENDPOINT == ""

    def test_mineru_default_url(self):
        from config.settings import settings
        assert settings.MINERU_API_URL == "http://127.0.0.1:30000"
        assert settings.MINERU_TIMEOUT == 300

    def test_settings_override_via_env(self, monkeypatch):
        """环境变量应覆盖默认值"""
        monkeypatch.setenv("DEBUG", "true")
        monkeypatch.setenv("KAFKA_BOOTSTRAP_SERVERS", "kafka:9092")
        monkeypatch.setenv("RETRIEVAL_TOP_K", "10")

        # 重新导入以应用环境变量
        import importlib
        import config.settings
        importlib.reload(config.settings)
        s = config.settings.settings

        assert s.DEBUG is True
        assert s.KAFKA_BOOTSTRAP_SERVERS == "kafka:9092"
        assert s.RETRIEVAL_TOP_K == 10

        # 清理：恢复
        monkeypatch.delenv("DEBUG", raising=False)
        monkeypatch.delenv("KAFKA_BOOTSTRAP_SERVERS", raising=False)
        monkeypatch.delenv("RETRIEVAL_TOP_K", raising=False)
        importlib.reload(config.settings)

    def test_database_url_default(self):
        from config.settings import settings
        assert "sqlite" in settings.DATABASE_URL
        assert settings.DATABASE_URL.endswith("rag_data.db")

    def test_worker_defaults(self):
        from config.settings import settings
        assert settings.WORKER_CONCURRENCY == 5
        assert settings.WORKER_POLL_TIMEOUT == 1.0

    def test_embedding_defaults(self):
        from config.settings import settings
        assert settings.EMBEDDING_BATCH_SIZE == 16
        assert settings.BGE_API_URL == ""
        assert settings.CLIP_API_URL == ""

    def test_milvus_dimensions(self):
        from config.settings import settings
        assert settings.MILVUS_TEXT_DIM == 1024
        assert settings.MILVUS_IMAGE_DIM == 512

    def test_kafka_config(self):
        from config.settings import settings
        assert settings.KAFKA_PARTITIONS == 3
        assert settings.KAFKA_REPLICATION_FACTOR == 3
        assert settings.KAFKA_PRODUCE_RETRIES == 3
        assert settings.KAFKA_CONSUME_RETRIES == 2

    def test_llm_timeout(self):
        from config.settings import settings
        assert settings.LLM_TIMEOUT == 30
        assert settings.LLM_MAX_RETRIES == 2
        assert settings.LLM_MAX_CONTEXT_LENGTH == 8192
