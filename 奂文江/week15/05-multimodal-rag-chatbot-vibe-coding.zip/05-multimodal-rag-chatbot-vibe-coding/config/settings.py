"""全局配置管理"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings:
    # ---- 项目基础 ----
    PROJECT_NAME: str = "MultiModal RAG Chatbot"
    VERSION: str = "1.0.0"
    DEBUG: bool = os.getenv("DEBUG", "false").lower() == "true"

    # ---- 文件存储 ----
    UPLOAD_BASE_PATH: str = os.getenv("UPLOAD_BASE_PATH", str(BASE_DIR / "uploads"))
    OSS_ENDPOINT: str = os.getenv("OSS_ENDPOINT", "")
    OSS_ACCESS_KEY: str = os.getenv("OSS_ACCESS_KEY", "")
    OSS_SECRET_KEY: str = os.getenv("OSS_SECRET_KEY", "")
    OSS_BUCKET: str = os.getenv("OSS_BUCKET", "")
    USE_OSS: bool = os.getenv("USE_OSS", "false").lower() == "true"

    # ---- 上传限制 ----
    MAX_FILE_SIZE_MB: int = int(os.getenv("MAX_FILE_SIZE_MB", "100"))
    ALLOWED_EXTENSIONS: set = {".pdf"}

    # ---- MySQL / SQLite ----
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        f"sqlite:///{BASE_DIR}/rag_data.db"
    )

    # ---- Kafka ----
    KAFKA_BOOTSTRAP_SERVERS: str = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
    KAFKA_TOPIC_PARSE: str = "parse_document_topic"
    KAFKA_TOPIC_DLQ: str = "parse_document_topic_dlq"
    KAFKA_PARTITIONS: int = 3
    KAFKA_REPLICATION_FACTOR: int = 3
    KAFKA_PRODUCE_RETRIES: int = 3
    KAFKA_CONSUME_RETRIES: int = 2

    # ---- Milvus ----
    MILVUS_HOST: str = os.getenv("MILVUS_HOST", "localhost")
    MILVUS_PORT: int = int(os.getenv("MILVUS_PORT", "19530"))
    MILVUS_ALIAS: str = "default"
    MILVUS_TEXT_COLLECTION: str = "text_chunk"
    MILVUS_IMAGE_COLLECTION: str = "image_chunk"
    MILVUS_TEXT_DIM: int = int(os.getenv("MILVUS_TEXT_DIM", "1024"))     # BGE-small-zh
    MILVUS_IMAGE_DIM: int = int(os.getenv("MILVUS_IMAGE_DIM", "512"))     # jina-clip-v2
    MILVUS_INDEX_TYPE: str = "IVF_FLAT"
    MILVUS_METRIC_TYPE: str = "IP"
    MILVUS_NLIST: int = 1024

    # ---- Embedding 模型 ----
    BGE_MODEL_PATH: str = os.getenv("BGE_MODEL_PATH", "/root/autodl-tmp/models/BAAI/bge-small-zh-v1.5")
    BGE_DEVICE: str = os.getenv("BGE_DEVICE", "cpu")
    CLIP_MODEL_PATH: str = os.getenv("CLIP_MODEL_PATH", "/root/autodl-tmp/models/jinaai/jina-clip-v2")
    CLIP_DEVICE: str = os.getenv("CLIP_DEVICE", "cpu")
    EMBEDDING_BATCH_SIZE: int = int(os.getenv("EMBEDDING_BATCH_SIZE", "16"))

    # ---- LLM (Qwen-VL via DashScope) ----
    DASHSCOPE_API_KEY: str = os.getenv("DASHSCOPE_API_KEY", "")
    LLM_MODEL: str = os.getenv("LLM_MODEL", "qwen-vl-max")
    LLM_TIMEOUT: int = int(os.getenv("LLM_TIMEOUT", "30"))
    LLM_MAX_RETRIES: int = int(os.getenv("LLM_MAX_RETRIES", "2"))
    LLM_MAX_CONTEXT_LENGTH: int = int(os.getenv("LLM_MAX_CONTEXT_LENGTH", "8192"))
    LLM_TEMPERATURE: float = float(os.getenv("LLM_TEMPERATURE", "0.7"))

    # ---- PDF 解析 ----
    MINERU_API_URL: str = os.getenv("MINERU_API_URL", "http://127.0.0.1:30000")
    MINERU_TIMEOUT: int = int(os.getenv("MINERU_TIMEOUT", "300"))
    DEEPSEEK_OCR_API_KEY: str = os.getenv("DEEPSEEK_OCR_API_KEY", "")
    DEEPSEEK_OCR_URL: str = os.getenv("DEEPSEEK_OCR_URL", "https://api.deepseek.com/v1/ocr")
    PDF_PROCESSED_DIR: str = os.getenv("PDF_PROCESSED_DIR", str(BASE_DIR / "processed"))

    # ---- 分块参数 ----
    CHUNK_SIZE: int = int(os.getenv("CHUNK_SIZE", "1000"))
    CHUNK_OVERLAP: int = int(os.getenv("CHUNK_OVERLAP", "200"))

    # ---- 检索参数 ----
    RETRIEVAL_TOP_K: int = int(os.getenv("RETRIEVAL_TOP_K", "5"))

    # ---- 限流 ----
    RATE_LIMIT_PER_USER: int = int(os.getenv("RATE_LIMIT_PER_USER", "2"))  # req/s

    # ---- Worker ----
    WORKER_CONCURRENCY: int = int(os.getenv("WORKER_CONCURRENCY", "5"))
    WORKER_POLL_TIMEOUT: float = float(os.getenv("WORKER_POLL_TIMEOUT", "1.0"))

    # ---- 模型服务地址（BGE/CLIP 远程调用） ----
    BGE_API_URL: str = os.getenv("BGE_API_URL", "")
    CLIP_API_URL: str = os.getenv("CLIP_API_URL", "")


settings = Settings()
