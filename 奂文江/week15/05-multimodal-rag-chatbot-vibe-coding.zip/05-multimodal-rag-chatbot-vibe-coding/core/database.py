"""数据库会话管理"""
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, scoped_session

from config.settings import settings
from orm_model import Base

# 根据数据库类型配置连接参数
if settings.DATABASE_URL.startswith("sqlite"):
    engine = create_engine(
        settings.DATABASE_URL,
        connect_args={"check_same_thread": False},
        echo=settings.DEBUG,
    )

    @event.listens_for(engine, "connect")
    def _set_sqlite_pragma(dbapi_connection, connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()
else:
    engine = create_engine(
        settings.DATABASE_URL,
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,
        echo=settings.DEBUG,
    )

SessionFactory = sessionmaker(bind=engine)
SessionLocal = scoped_session(SessionFactory)


def init_db():
    """初始化数据库表"""
    Base.metadata.create_all(engine)


def get_session():
    """获取数据库会话（上下文管理器）"""
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def get_db():
    """直接获取数据库会话"""
    return SessionLocal()


def ensure_db():
    """确保数据库已初始化（幂等）"""
    import os
    db_path = settings.DATABASE_URL.replace("sqlite:///", "")
    if db_path.startswith("sqlite"):
        db_dir = os.path.dirname(db_path)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir, exist_ok=True)
    init_db()
