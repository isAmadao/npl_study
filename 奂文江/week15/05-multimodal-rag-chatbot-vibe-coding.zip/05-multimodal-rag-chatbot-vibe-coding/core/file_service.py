"""文件存储服务（本地 / OSS）"""
import hashlib
import os
import shutil
from pathlib import Path

from config.settings import settings
from utils.logger import logger


class FileService:
    """文件存储抽象，支持本地文件系统和 OSS（MinIO/S3）"""

    def __init__(self):
        self.base_path = Path(settings.UPLOAD_BASE_PATH)
        self.base_path.mkdir(parents=True, exist_ok=True)
        self.use_oss = settings.USE_OSS

    def _get_doc_dir(self, document_id: str) -> Path:
        p = self.base_path / document_id
        p.mkdir(parents=True, exist_ok=True)
        return p

    def compute_md5(self, file_path: str | Path) -> str:
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()

    def compute_md5_bytes(self, data: bytes) -> str:
        return hashlib.md5(data).hexdigest()

    def save_upload(self, document_id: str, file_stream, original_name: str) -> str:
        """保存上传文件。返回存储路径。"""
        doc_dir = self._get_doc_dir(document_id)
        ext = Path(original_name).suffix
        dest = doc_dir / f"{document_id}{ext}"
        with open(dest, "wb") as f:
            shutil.copyfileobj(file_stream, f)
        logger.info("File saved: %s (size=%d)", dest, dest.stat().st_size)
        return str(dest)

    def download_to_local(self, remote_path: str, local_path: str | Path) -> str:
        """从存储下载文件到本地临时目录。"""
        local = Path(local_path)
        local.parent.mkdir(parents=True, exist_ok=True)

        if self.use_oss:
            # TODO: OSS 下载
            raise NotImplementedError("OSS download not yet implemented")
        else:
            src = Path(remote_path)
            if not src.exists():
                raise FileNotFoundError(f"File not found: {remote_path}")
            shutil.copy2(str(src), str(local))

        logger.info("File downloaded: %s -> %s", remote_path, local_path)
        return str(local)

    def ensure_dir(self, path: str | Path) -> str:
        p = Path(path)
        p.mkdir(parents=True, exist_ok=True)
        return str(p)
