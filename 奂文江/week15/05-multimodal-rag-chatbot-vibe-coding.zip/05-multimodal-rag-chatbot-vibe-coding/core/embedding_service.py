"""向量化服务（BGE + CLIP）"""
from typing import Optional

import numpy as np

from config.settings import settings
from utils.logger import logger
from utils.retry import retry


class EmbeddingService:
    """向量化服务。支持本地模型加载和远程 API 调用。"""

    def __init__(self):
        self.bge_model = None
        self.clip_model = None
        self.bge_loaded = False
        self.clip_loaded = False

    def _load_bge_local(self):
        if self.bge_loaded:
            return
        try:
            from sentence_transformers import SentenceTransformer
            self.bge_model = SentenceTransformer(
                settings.BGE_MODEL_PATH,
                device=settings.BGE_DEVICE,
            )
            self.bge_loaded = True
            logger.info("BGE model loaded: %s", settings.BGE_MODEL_PATH)
        except Exception as e:
            logger.error("Failed to load BGE model: %s", e)
            raise

    def _load_clip_local(self):
        if self.clip_loaded:
            return
        try:
            from sentence_transformers import SentenceTransformer
            self.clip_model = SentenceTransformer(
                settings.CLIP_MODEL_PATH,
                device=settings.CLIP_DEVICE,
            )
            self.clip_loaded = True
            logger.info("CLIP model loaded: %s", settings.CLIP_MODEL_PATH)
        except Exception as e:
            logger.error("Failed to load CLIP model: %s", e)
            raise

    @retry(max_retries=2, delay=0.5)
    def embed_text(self, text: str | list[str]) -> list[float]:
        """BGE 文本向量化"""
        texts = [text] if isinstance(text, str) else text

        if settings.BGE_API_URL:
            return self._remote_embed(texts, settings.BGE_API_URL)

        self._load_bge_local()
        embeddings = self.bge_model.encode(
            texts,
            batch_size=settings.EMBEDDING_BATCH_SIZE,
            show_progress_bar=False,
            normalize_embeddings=True,
        )
        result = embeddings.tolist()
        return result[0] if isinstance(text, str) else result

    @retry(max_retries=2, delay=0.5)
    def embed_text_clip(self, text: str | list[str]) -> list[float]:
        """CLIP 文本向量化"""
        texts = [text] if isinstance(text, str) else text

        if settings.CLIP_API_URL:
            return self._remote_embed(texts, settings.CLIP_API_URL, task="text")

        self._load_clip_local()
        embeddings = self.clip_model.encode(
            texts,
            batch_size=settings.EMBEDDING_BATCH_SIZE,
            show_progress_bar=False,
            normalize_embeddings=True,
        )
        result = embeddings.tolist()
        return result[0] if isinstance(text, str) else result

    @retry(max_retries=2, delay=0.5)
    def embed_image(self, image_path: str | list[str]) -> list[float]:
        """CLIP 图片向量化"""
        paths = [image_path] if isinstance(image_path, str) else image_path

        if settings.CLIP_API_URL:
            return self._remote_embed(paths, settings.CLIP_API_URL, task="image")

        self._load_clip_local()
        from PIL import Image
        images = [Image.open(p).convert("RGB") for p in paths]
        embeddings = self.clip_model.encode(
            images,
            batch_size=settings.EMBEDDING_BATCH_SIZE,
            show_progress_bar=False,
            normalize_embeddings=True,
        )
        result = embeddings.tolist()
        return result[0] if isinstance(image_path, str) else result

    def _remote_embed(self, inputs: list, api_url: str, task: str = "text") -> list[float]:
        """通过远程 API 调用向量化"""
        import requests
        payload = {"inputs": inputs, "task": task}
        resp = requests.post(api_url, json=payload, timeout=30)
        resp.raise_for_status()
        return resp.json()["embeddings"]
