"""Kafka 生产 / 消费服务"""
import json
import time

from kafka import KafkaConsumer, KafkaProducer
from kafka.errors import NoBrokersAvailable

from config.settings import settings
from utils.logger import logger
from utils.retry import retry


class KafkaService:
    """Kafka 消息服务"""

    def __init__(self):
        self.bootstrap_servers = settings.KAFKA_BOOTSTRAP_SERVERS
        self.topic_parse = settings.KAFKA_TOPIC_PARSE
        self.topic_dlq = settings.KAFKA_TOPIC_DLQ
        self._producer: KafkaProducer | None = None
        self._consumer: KafkaConsumer | None = None

    def _connect_producer(self) -> KafkaProducer:
        return KafkaProducer(
            bootstrap_servers=self.bootstrap_servers,
            value_serializer=lambda v: json.dumps(v, ensure_ascii=False).encode("utf-8"),
            acks="all",
            retries=settings.KAFKA_PRODUCE_RETRIES,
            max_in_flight_requests_per_connection=1,
        )

    @property
    def producer(self) -> KafkaProducer:
        if self._producer is None:
            self._producer = self._connect_producer()
        return self._producer

    @retry(max_retries=3, delay=0.5, backoff=2.0, exceptions=(NoBrokersAvailable,))
    def send_parse_task(self, message: dict) -> bool:
        """发送解析任务消息。"""
        future = self.producer.send(self.topic_parse, value=message)
        record_metadata = future.get(timeout=5)
        logger.info(
            "Kafka msg sent: topic=%s partition=%d offset=%d msg=%s",
            record_metadata.topic, record_metadata.partition,
            record_metadata.offset, message,
        )
        return True

    def send_dead_letter(self, message: dict, error: str = ""):
        """发送到死信队列。"""
        message["error"] = error
        future = self.producer.send(self.topic_dlq, value=message)
        future.get(timeout=5)
        logger.warning("Msg sent to DLQ: %s", message)

    def create_consumer(self, group_id: str = "parse-worker") -> KafkaConsumer:
        """创建消费者实例。"""
        consumer = KafkaConsumer(
            self.topic_parse,
            bootstrap_servers=self.bootstrap_servers,
            group_id=group_id,
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
            enable_auto_commit=True,
            auto_offset_reset="earliest",
            max_poll_interval_ms=300000,
            session_timeout_ms=30000,
        )
        return consumer

    def close(self):
        if self._producer:
            self._producer.close()
            self._producer = None
        if self._consumer:
            self._consumer.close()
            self._consumer = None
