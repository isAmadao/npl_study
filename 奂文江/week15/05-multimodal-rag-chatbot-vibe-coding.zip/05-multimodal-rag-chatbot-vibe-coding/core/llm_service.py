"""LLM 多模态生成服务（Qwen-VL via DashScope）"""
from typing import Optional

from config.settings import settings
from utils.logger import logger
from utils.retry import retry


class LLMService:
    """多模态生成服务，调用 Qwen-VL"""

    def __init__(self):
        self.api_key = settings.DASHSCOPE_API_KEY
        self.model = settings.LLM_MODEL
        self.timeout = settings.LLM_TIMEOUT
        self.max_retries = settings.LLM_MAX_RETRIES

    @retry(max_retries=2, delay=1.0, backoff=2.0)
    def chat(
        self,
        question: str,
        context_texts: list[dict],
        context_images: list[dict] = None,
    ) -> str:
        """多轮多模态对话生成

        Args:
            question: 用户问题
            context_texts: 文本上下文，每项含 {content, file_name, page_num}
            context_images: 图片上下文，每项含 {image_url, file_name, page_num}

        Returns:
            生成的答案文本
        """
        context_images = context_images or []

        # 构建系统提示
        system_prompt = self._build_system_prompt(context_texts, context_images)

        try:
            from openai import OpenAI
            client = OpenAI(
                api_key=self.api_key,
                base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
                timeout=self.timeout,
            )

            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": self._build_user_content(question, context_images)},
            ]

            response = client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=settings.LLM_TEMPERATURE,
                max_tokens=2048,
                timeout=self.timeout,
            )
            answer = response.choices[0].message.content
            logger.info("LLM response received (input_len=%d)", len(system_prompt) + len(question))
            return answer

        except Exception as e:
            logger.error("LLM call failed: %s", e)
            raise

    def _build_system_prompt(self, texts: list[dict], images: list[dict]) -> str:
        """构建系统提示词"""
        parts = [
            "你是一个多模态文档问答助手。请基于以下提供的文档内容（文本和图片）回答用户的问题。",
            "",
            "## 回答要求",
            "1. 优先使用提供的文档内容作答，不要编造信息",
            "2. 如果提供的内容不足以回答问题，请如实说'暂无相关信息'",
            "3. 每条信息请标注来源：文档名称 + 页码",
            "4. 使用中文回答，简洁准确",
            "",
            "## 参考文本内容",
        ]

        for i, t in enumerate(texts, 1):
            parts.append(f"[{i}] (来源: {t.get('file_name', '未知')} 第{t.get('page_num', '?')}页)")
            parts.append(t.get("content", ""))

        if images:
            parts.append("")
            parts.append("## 参考图片")
            for i, img in enumerate(images, 1):
                parts.append(
                    f"[图片{i}] (来源: {img.get('file_name', '未知')} 第{img.get('page_num', '?')}页)"
                )

        return "\n".join(parts)

    def _build_user_content(self, question: str, images: list[dict]) -> list:
        """构建用户消息内容（支持多模态）"""
        content = [{"type": "text", "text": question}]

        # Qwen-VL 支持图片 URL 输入
        for img in images:
            url = img.get("image_url", "")
            if url:
                content.append({
                    "type": "image_url",
                    "image_url": {"url": url},
                })

        return content
