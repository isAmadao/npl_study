"""Milvus 向量数据库服务"""
from pymilvus import (
    Collection, CollectionSchema, DataType, FieldSchema,
    connections, utility,
)

from config.settings import settings
from utils.logger import logger


class MilvusService:
    """Milvus 向量数据库客户端"""

    def __init__(self):
        self.host = settings.MILVUS_HOST
        self.port = settings.MILVUS_PORT
        self.alias = settings.MILVUS_ALIAS
        self.text_collection_name = settings.MILVUS_TEXT_COLLECTION
        self.image_collection_name = settings.MILVUS_IMAGE_COLLECTION
        self._connected = False

    def connect(self):
        if not self._connected:
            connections.connect(
                alias=self.alias,
                host=self.host,
                port=self.port,
            )
            self._connected = True
            logger.info("Connected to Milvus: %s:%s", self.host, self.port)

    def _create_text_collection(self):
        fields = [
            FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=settings.MILVUS_TEXT_DIM),
            FieldSchema(name="document_id", dtype=DataType.VARCHAR, max_length=64),
            FieldSchema(name="knowledge_base_id", dtype=DataType.VARCHAR, max_length=64),
            FieldSchema(name="chunk_id", dtype=DataType.VARCHAR, max_length=64),
            FieldSchema(name="page_num", dtype=DataType.INT32),
        ]
        schema = CollectionSchema(fields, description="Text chunk vectors")
        collection = Collection(self.text_collection_name, schema)
        collection.create_index(
            field_name="vector",
            index_params={
                "index_type": settings.MILVUS_INDEX_TYPE,
                "metric_type": settings.MILVUS_METRIC_TYPE,
                "params": {"nlist": settings.MILVUS_NLIST},
            },
        )
        collection.load()
        logger.info("Created text collection: %s", self.text_collection_name)
        return collection

    def _create_image_collection(self):
        fields = [
            FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=settings.MILVUS_IMAGE_DIM),
            FieldSchema(name="document_id", dtype=DataType.VARCHAR, max_length=64),
            FieldSchema(name="knowledge_base_id", dtype=DataType.VARCHAR, max_length=64),
            FieldSchema(name="image_id", dtype=DataType.VARCHAR, max_length=64),
            FieldSchema(name="page_num", dtype=DataType.INT32),
            FieldSchema(name="image_path", dtype=DataType.VARCHAR, max_length=512),
        ]
        schema = CollectionSchema(fields, description="Image vectors")
        collection = Collection(self.image_collection_name, schema)
        collection.create_index(
            field_name="vector",
            index_params={
                "index_type": settings.MILVUS_INDEX_TYPE,
                "metric_type": settings.MILVUS_METRIC_TYPE,
                "params": {"nlist": settings.MILVUS_NLIST},
            },
        )
        collection.load()
        logger.info("Created image collection: %s", self.image_collection_name)
        return collection

    def get_or_create_collection(self, name: str):
        """获取或创建集合。"""
        self.connect()
        if utility.has_collection(name):
            collection = Collection(name)
            collection.load()
            logger.info("Loaded collection: %s", name)
            return collection
        if name == self.text_collection_name:
            return self._create_text_collection()
        elif name == self.image_collection_name:
            return self._create_image_collection()
        else:
            raise ValueError(f"Unknown collection: {name}")

    def insert_text_vectors(self, entities: list[dict]) -> list[int]:
        """插入文本向量。"""
        collection = self.get_or_create_collection(self.text_collection_name)
        ids = collection.insert(entities)
        collection.flush()
        logger.info("Inserted %d text vectors", len(entities))
        return ids.primary_keys

    def insert_image_vectors(self, entities: list[dict]) -> list[int]:
        """插入图片向量。"""
        collection = self.get_or_create_collection(self.image_collection_name)
        ids = collection.insert(entities)
        collection.flush()
        logger.info("Inserted %d image vectors", len(entities))
        return ids.primary_keys

    def search_text(
        self,
        query_vector: list[float],
        knowledge_base_id: str,
        top_k: int = 5,
    ) -> list[dict]:
        """文本向量检索。"""
        collection = self.get_or_create_collection(self.text_collection_name)
        search_params = {
            "metric_type": settings.MILVUS_METRIC_TYPE,
            "params": {"nprobe": 16},
        }
        results = collection.search(
            data=[query_vector],
            anns_field="vector",
            param=search_params,
            limit=top_k,
            expr=f'knowledge_base_id == "{knowledge_base_id}"',
            output_fields=["document_id", "chunk_id", "page_num", "knowledge_base_id"],
        )
        return self._format_results(results)

    def search_image(
        self,
        query_vector: list[float],
        knowledge_base_id: str,
        top_k: int = 5,
    ) -> list[dict]:
        """图片向量检索。"""
        collection = self.get_or_create_collection(self.image_collection_name)
        search_params = {
            "metric_type": settings.MILVUS_METRIC_TYPE,
            "params": {"nprobe": 16},
        }
        results = collection.search(
            data=[query_vector],
            anns_field="vector",
            param=search_params,
            limit=top_k,
            expr=f'knowledge_base_id == "{knowledge_base_id}"',
            output_fields=["document_id", "image_id", "page_num", "image_path", "knowledge_base_id"],
        )
        return self._format_results(results)

    def _format_results(self, results) -> list[dict]:
        hits = []
        for result in results[0]:
            hits.append({
                "id": result.id,
                "distance": result.distance,
                **result.entity.to_dict(),
            })
        return hits

    def drop_collection(self, name: str):
        if utility.has_collection(name):
            utility.drop_collection(name)
            logger.info("Dropped collection: %s", name)

    def close(self):
        if self._connected:
            connections.disconnect(self.alias)
            self._connected = False
            logger.info("Disconnected from Milvus")
