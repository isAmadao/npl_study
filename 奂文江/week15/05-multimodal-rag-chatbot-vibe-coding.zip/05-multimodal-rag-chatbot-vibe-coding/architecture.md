# 多模态 RAG 聊天机器人 — 系统架构设计

## 一、整体架构总览

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Client Layer                                  │
│                    Streamlit Web UI / HTTP Client                          │
└──────────────────────┬──────────────────────────────────────────────────────┘
                       │
                       │ HTTP
                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Gateway / API Layer                              │
│              ┌─────────────────────────┐  ┌─────────────────────────┐      │
│              │  文件上传 API            │  │  多模态问答 API          │      │
│              │  POST /upload/document  │  │  POST /chat             │      │
│              │  - 格式校验              │  │  - 参数校验              │      │
│              │  - 大小校验              │  │  - 权限校验              │      │
│              │  - 幂等性校验(MD5)       │  │  - 限流                 │      │
│              └───────────┬─────────────┘  └───────────┬─────────────┘      │
└──────────────────────────┼────────────────────────────┼──────────────────────┘
                           │                            │
                           ▼                            ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        Service Layer                                       │
│  ┌────────────────────────────┐  ┌──────────────────────────────────────┐  │
│  │    Upload Service          │  │    Chat Service                     │  │
│  │  - 文件存储(本地/OSS)      │  │  - 文本检索(BGE → Milvus)          │  │
│  │  - 元信息写入(MySQL)       │  │  - 图片检索(CLIP → Milvus)         │  │
│  │  - Kafka 消息发送          │  │  - 上下文构建(图文混合)             │  │
│  │  - 状态管理                │  │  - 多模态生成(Qwen-VL)             │  │
│  └────────────┬───────────────┘  │  - 来源追溯                        │  │
│               │                  └──────────────────────────────────────┘  │
│               ▼                                                            │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │              Offline Worker (文档解析 Worker)                        │  │
│  │  1. Kafka 消息消费            4. Markdown 分块                       │  │
│  │  2. PDF 下载                  5. 向量化(BGE + CLIP)                 │  │
│  │  3. PDF 解析(MinerU/OCR)     6. 向量写入 Milvus + 元信息写 MySQL   │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────┬──────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         Infrastructure Layer                               │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌────────────────────────┐     │
│  │  MySQL   │  │  Kafka   │  │  Milvus  │  │  Object Storage       │     │
│  │ 元信息DB │  │ 消息队列  │  │ 向量数据库│  │ (本地/OSS)             │     │
│  │ - 文档表  │  │ - 任务消息│  │ - 文本向量│  │ - PDF 源文件          │     │
│  │ - Chunk表 │  │ - 死信队列│  │ - 图片向量│  │ - 解析输出(MD/图片)   │     │
│  │ - 图片表  │  │          │  │          │  │                        │     │
│  │ - 权限表  │  │          │  │          │  │                        │     │
│  └──────────┘  └──────────┘  └──────────┘  └────────────────────────┘     │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 二、分层架构详解

### 1. Gateway / API Layer

接收客户端请求，负责前置校验和路由转发。

```
请求 → 格式校验 → 大小校验 → 幂等性校验 → 权限校验 → 限流 → Service Layer
```

| 组件 | 职责 |
|------|------|
| 请求校验器 | 检查 Content-Type、文件格式、必填参数 |
| 限流器 | 基于令牌桶，单用户 2 req/s |
| 权限拦截器 | 验证 user_id 对 knowledge_base_id 的访问权限 |
| 日志中间件 | 注入 trace_id，记录请求/响应全链路 |

---

### 2. Service Layer — 核心业务

#### 2.1 Upload Service

```
                        ┌──────────────────┐
                        │    Client        │
                        │   Upload PDF     │
                        └────────┬─────────┘
                                 │ POST /upload/document
                                 ▼
                        ┌──────────────────┐
                        │ 1. 文件校验       │
                        │   - 格式(.pdf)    │
                        │   - 大小(<100MB)  │
                        │   - MD5 幂等性    │
                        └────────┬─────────┘
                                 ▼
                        ┌──────────────────┐
                        │ 2. 文件存储       │ ←──→ [OSS/本地]
                        │   uuid命名        │
                        └────────┬─────────┘
                                 ▼
                        ┌──────────────────┐
                        │ 3. 元信息落库     │ ←──→ [MySQL]
                        │   状态: pending   │
                        └────────┬─────────┘
                                 ▼
                        ┌──────────────────┐
                        │ 4. Kafka 消息发送 │ ←──→ [Kafka]
                        │   重试3次        │     parse_document_topic
                        │   失败→send_failed│
                        └────────┬─────────┘
                                 ▼
                        ┌──────────────────┐
                        │ 5. 返回document_id│
                        └──────────────────┘
```

#### 2.2 Chat Service

```
                        ┌──────────────────┐
                        │    Client        │
                        │   Ask Question   │
                        └────────┬─────────┘
                                 │ POST /chat
                                 ▼
                        ┌──────────────────┐
                        │ 1. 参数&权限校验  │
                        └────────┬─────────┘
                                 ▼
                        ┌──────────────────────────────────┐
                        │ 2. 多模态检索(并行)              │
                        │  ┌─────────────────┐             │
                        │  │ 文本检索         │             │
                        │  │ BGE→Milvus      │             │
                        │  │ Top-K           │             │
                        │  └────────┬────────┘             │
                        │           │                      │
                        │  ┌────────▼────────┐             │
                        │  │ 图片检索         │             │
                        │  │ CLIP→Milvus     │             │
                        │  │ Top-K           │             │
                        │  └─────────────────┘             │
                        └────────┬─────────────────────────┘
                                 ▼
                        ┌──────────────────┐
                        │ 3. 上下文构建     │
                        │   图文混合Prompt  │
                        │   来源标记        │
                        └────────┬─────────┘
                                 ▼
                        ┌──────────────────┐
                        │ 4. LLM 生成      │ ←──→ [Qwen-VL]
                        │   重试2次        │
                        │   超时30s        │
                        └────────┬─────────┘
                                 ▼
                        ┌──────────────────┐
                        │ 5. 返回答案+来源  │
                        └──────────────────┘
```

#### 2.3 Offline Worker (核心枢纽)

```
┌────────────────────────────────────────────────────────────────────┐
│                     Offline Process Worker                         │
│                                                                    │
│  Kafka Consumer ──→ 消息解析 ──→ 状态更新(parsing)                │
│                                                                    │
│  ┌─────────────┐    ┌──────────────┐    ┌────────────────────┐    │
│  │ Stage 1     │    │ Stage 2      │    │ Stage 3            │    │
│  │ 下载PDF     │───→│ PDF解析      │───→│ 输出存储           │    │
│  │ 重试2次     │    │ MinerU/OCR   │    │ MD + 图片 → OSS   │    │
│  │ dl_failed   │    │ parse_failed │    │                    │    │
│  └─────────────┘    └──────────────┘    └────────┬───────────┘    │
│                                                   │                │
│  ┌─────────────┐    ┌──────────────┐              │                │
│  │ Stage 6     │←───│ Stage 5      │←─────────────┘                │
│  │ 写入Milvus  │    │ 向量化       │                               │
│  │ + MySQL     │    │ BGE + CLIP   │    ┌────────────────────┐    │
│  │ completed   │    │ emb_failed   │    │ Stage 4            │    │
│  └─────────────┘    └──────────────┘    │ Markdown 分块      │    │
│                                          │ 1000token/200overlap│   │
│                                          └────────────────────┘    │
└────────────────────────────────────────────────────────────────────┘
```

---

### 3. Data Layer

#### 3.1 MySQL 表结构设计

```
┌─────────────────────────────────────────────────────────────────┐
│                     MySQL 表关系图                              │
│                                                                 │
│  ┌──────────────────────┐     ┌──────────────────────────────┐ │
│  │     documents        │     │     chunks                  │ │
│  ├──────────────────────┤     ├──────────────────────────────┤ │
│  │ document_id (PK)     │──┬──│ chunk_id (PK)               │ │
│  │ knowledge_base_id    │  │  │ document_id (FK)            │ │
│  │ file_name            │  │  │ knowledge_base_id           │ │
│  │ file_hash (MD5)      │  │  │ page_num                    │ │
│  │ uploader             │  │  │ content                     │ │
│  │ upload_time          │  │  │ title                       │ │
│  │ status               │  │  │ embedding_id (Milvus ID)    │ │
│  │ original_path        │  │  └──────────────────────────────┘ │
│  │ markdown_path        │  │                                   │
│  │ error_msg            │  │  ┌──────────────────────────────┐ │
│  └──────────────────────┘  ├──│     images                  │ │
│                             │  ├──────────────────────────────┤ │
│  ┌──────────────────────┐  │  │ image_id (PK)               │ │
│  │   permissions        │  │  │ document_id (FK)            │ │
│  ├──────────────────────┤  │  │ knowledge_base_id           │ │
│  │ user_id              │  │  │ page_num                    │ │
│  │ knowledge_base_id    │  │  │ image_path                  │ │
│  │ role (rw/admin)      │  │  │ embedding_id (Milvus ID)    │ │
│  │ UNIQUE(user_id,kb_id)│  │  └──────────────────────────────┘ │
│  └──────────────────────┘  │                                   │
│                            │  status 枚举:                     │
│                            │  pending→parsing→completed/failed │
└────────────────────────────────────────────────────────────────┘
```

#### 3.2 Milvus Collection 设计

```yaml
text_collection:
  name: text_chunk
  fields:
    - id: int64 (主键, auto_id)
    - vector: float_vector (BGE, dim=1024)
    - document_id: int64
    - knowledge_base_id: int64
    - chunk_id: varchar
    - page_num: int32
  index:
    type: IVF_FLAT
    metric: IP (内积)
    nlist: 1024
  partition:
    by: knowledge_base_id

image_collection:
  name: image_chunk
  fields:
    - id: int64 (主键, auto_id)
    - vector: float_vector (CLIP, dim=512)
    - document_id: int64
    - knowledge_base_id: int64
    - image_id: varchar
    - page_num: int32
    - image_path: varchar
  index:
    type: IVF_FLAT
    metric: IP
    nlist: 1024
  partition:
    by: knowledge_base_id
```

#### 3.3 Kafka Topic 设计

```yaml
topic: parse_document_topic
partitions: 3
replication_factor: 3
acks: all

dead_letter_topic: parse_document_topic_dlq

消息体:
{
  "document_id": "xxx",
  "file_path": "xxx",
  "knowledge_base_id": "xxx",
  "upload_time": "2026-05-20T10:00:00Z",
  "retry_count": 0
}
```

---

## 三、数据流全景图

### 上传 + 解析链路

```
User ──→ Streamlit Upload ──→ 校验 ──→ 存OSS + 写MySQL(pending) ──→ Kafka
                                                                        │
                                                                        ▼
                                                                   Worker消费
                                                                        │
                                                                  ┌─────┴─────┐
                                                                  │           │
                                                               MinerU   DeepSeek-OCR
                                                                  │           │
                                                                  └─────┬─────┘
                                                                        │
                                                                  Markdown + 图片
                                                                        │
                                                              ┌─────────┴─────────┐
                                                              │                   │
                                                         文本分块(BGE向量)   图片(CLIP向量)
                                                              │                   │
                                                              └─────────┬─────────┘
                                                                        │
                                                              ┌─────────┴─────────┐
                                                              │                   │
                                                          写入Milvus        写入MySQL
                                                          (向量)           (元信息)
                                                                        │
                                                                  status=completed
```

### 问答链路

```
User ──→ Streamlit Chat ──→ 权限校验 ──→ 并行检索 ──→ Prompt构建 ──→ Qwen-VL ──→ 答案+来源
                                          │
                                    ┌─────┴─────┐
                                    │           │
                                BGE查询     CLIP查询
                                    │           │
                                ┌───┴───┐  ┌───┴───┐
                                │Milvus │  │Milvus │
                                │文本集合│  │图片集合│
                                └───────┘  └───────┘
```

---

## 四、部署架构

```
                 ┌───────────────────────┐
                 │     Nginx (反向代理)   │
                 │    负载均衡 + 限流     │
                 └───────┬───────┬───────┘
                         │       │
                 ┌───────┘       └───────┐
                 │                       │
         ┌───────▼───────┐       ┌───────▼───────┐
         │ Streamlit     │       │ Streamlit     │
         │ Instance 1    │       │ Instance 2    │
         │ (Upload+Chat) │       │ (Upload+Chat) │
         └───────┬───────┘       └───────┬───────┘
                 │                       │
                 └───────────┬───────────┘
                             │
                    ┌────────▼────────┐
                    │  Kafka Cluster  │
                    │  (3 Brokers)    │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │  Worker Pool    │
                    │  (5 并发解析)   │
                    └─────────────────┘

         ┌──────────────┬──────────────┬──────────────┐
         │              │              │              │
    ┌────▼────┐   ┌────▼────┐   ┌────▼────┐   ┌─────▼─────┐
    │ MySQL   │   │ Milvus  │   │  OSS    │   │ 模型服务   │
    │ 主从    │   │ 集群    │   │ 对象存储 │   │ BGE/CLIP   │
    └─────────┘   └─────────┘   └──────────┘   │ Qwen-VL   │
                                                └───────────┘
```

---

## 五、组件职责矩阵

| 组件 | 数量 | 语言/框架 | 核心职责 | 关键指标 |
|------|------|-----------|---------|---------|
| Streamlit UI × 2 | 1+ | Python/Streamlit | 上传页面 + 聊天页面 | 首屏加载 < 2s |
| Upload API | 内嵌 | Python/FastAPI | 文件校验、存储、发消息 | 响应 < 5s, 100+ 并发 |
| Chat API | 内嵌 | Python/FastAPI | 检索、上下文构建、生成 | 响应 < 10s, 100+ 并发 |
| Offline Worker | 5 | Python | PDF解析、分块、向量化 | 100页 < 5min |
| Kafka | 3 | Kafka | 异步解耦、削峰填谷 | 延迟 < 10s |
| Milvus | 3+ | Milvus | 向量存储与检索 | 检索 < 500ms |
| MySQL | 1主2从 | MySQL | 元数据管理 | 写入 < 100ms |
| OSS | 1 | MinIO/S3 | 文件持久化 | 上传 < 1s/10MB |
| BGE | 1 | Sentence-Transformer | 文本向量化 | 单次 < 200ms |
| CLIP | 1 | Jina-CLIP | 图文向量化 | 单次 < 300ms |
| Qwen-VL | 1 | DashScope API | 多模态生成 | 生成 < 8s |
| MinerU | 1 | MinerU | PDF解析(MD+图片) | 100页 < 4min |
| DeepSeek-OCR | 1 | API | PDF解析(备选) | 100页 < 3min |

---

## 六、容错与降级策略

```
解析容错:
  MinerU 失败 ──→ 自动切换 DeepSeek-OCR ──→ 都失败 → status=parse_failed

消息容错:
  生产重试(3次) ──→ 失败 → status=send_failed ──→ 死信队列

消费容错:
  消费重试(2次) ──→ 失败 → 死信队列

模型降级:
  BGE/CLIP 不可用 ──→ 返回 "检索服务维护中"
  Qwen-VL 不可用  ──→ 返回 "生成服务维护中"
  Milvus 不可用    ──→ 降级为仅文本关键词检索(后续迭代)
```

---

## 七、目录结构设计

```
project_root/
├── web_demo.py                    # Streamlit 入口
├── web_page_upload.py             # 上传页面
├── web_page_chat.py               # 聊天页面
├── offline_process_worker.py      # 离线解析 Worker
├── orm_model.py                   # SQLAlchemy 模型
│
├── api/                           # API 服务层
│   ├── __init__.py
│   ├── upload_api.py              # 上传 API
│   └── chat_api.py                # 问答 API
│
├── core/                          # 核心业务逻辑
│   ├── __init__.py
│   ├── file_service.py            # 文件存储服务
│   ├── kafka_service.py           # Kafka 生产/消费
│   ├── milvus_service.py          # Milvus 客户端
│   ├── embedding_service.py       # BGE/CLIP 向量化
│   └── llm_service.py             # Qwen-VL 调用
│
├── worker/                        # Worker 逻辑
│   ├── __init__.py
│   ├── pdf_parser.py              # MinerU/OCR 解析
│   ├── chunk_splitter.py          # Markdown 分块
│   └── vectorize_pipeline.py      # 向量化流水线
│
├── models/                        # 数据模型
│   ├── __init__.py
│   └── schemas.py                 # Pydantic 模型
│
├── utils/                         # 工具
│   ├── __init__.py
│   ├── config.py                  # 配置管理
│   ├── logger.py                  # 日志 + trace_id
│   ├── retry.py                   # 重试装饰器
│   └── limiter.py                 # 限流器
│
├── config/                        # 配置文件
│   ├── settings.yaml
│   └── settings.py
│
└── tests/                         # 测试
    ├── test_upload.py
    ├── test_worker.py
    ├── test_chat.py
    ├── test_retrieval.py
    └── conftest.py
```
