"""SQLAlchemy ORM 模型"""
import uuid
from datetime import datetime

from sqlalchemy import (
    Column, String, Integer, Text, DateTime, Float,
    Enum, UniqueConstraint, ForeignKey, create_engine, Index,
)
from sqlalchemy.orm import DeclarativeBase, relationship


def gen_uuid() -> str:
    return uuid.uuid4().hex


class Base(DeclarativeBase):
    pass


class Document(Base):
    __tablename__ = "documents"

    document_id = Column(String(64), primary_key=True, default=gen_uuid)
    knowledge_base_id = Column(String(64), nullable=False, index=True)
    file_name = Column(String(255), nullable=False)
    file_hash = Column(String(64), default="")  # MD5
    file_size = Column(Integer, default=0)  # bytes
    uploader = Column(String(64), nullable=False)
    upload_time = Column(DateTime, default=datetime.utcnow)
    status = Column(
        String(32),
        default="pending",
        index=True,
    )
    original_path = Column(String(512), default="")
    markdown_path = Column(String(512), default="")
    error_msg = Column(Text, default="")

    chunks = relationship("Chunk", back_populates="document", cascade="all, delete-orphan")
    images = relationship("Image", back_populates="document", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Document(id={self.document_id}, file={self.file_name}, status={self.status})>"


class Chunk(Base):
    __tablename__ = "chunks"

    chunk_id = Column(String(64), primary_key=True, default=gen_uuid)
    document_id = Column(String(64), ForeignKey("documents.document_id"), nullable=False, index=True)
    knowledge_base_id = Column(String(64), nullable=False, index=True)
    page_num = Column(Integer, default=0)
    content = Column(Text, nullable=False)
    title = Column(String(255), default="")
    embedding_id = Column(String(64), default="")  # Milvus ID

    document = relationship("Document", back_populates="chunks")

    __table_args__ = (
        Index("idx_chunk_doc_page", "document_id", "page_num"),
    )

    def __repr__(self):
        return f"<Chunk(id={self.chunk_id}, doc={self.document_id}, page={self.page_num})>"


class Image(Base):
    __tablename__ = "images"

    image_id = Column(String(64), primary_key=True, default=gen_uuid)
    document_id = Column(String(64), ForeignKey("documents.document_id"), nullable=False, index=True)
    knowledge_base_id = Column(String(64), nullable=False, index=True)
    page_num = Column(Integer, default=0)
    image_path = Column(String(512), nullable=False)
    embedding_id = Column(String(64), default="")

    document = relationship("Document", back_populates="images")

    def __repr__(self):
        return f"<Image(id={self.image_id}, doc={self.document_id}, path={self.image_path})>"


class Permission(Base):
    __tablename__ = "permissions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(64), nullable=False)
    knowledge_base_id = Column(String(64), nullable=False)
    role = Column(String(16), default="read")  # read / write / admin

    __table_args__ = (
        UniqueConstraint("user_id", "knowledge_base_id", name="uq_user_kb"),
        Index("idx_perm_user", "user_id"),
        Index("idx_perm_kb", "knowledge_base_id"),
    )

    def __repr__(self):
        return f"<Permission(user={self.user_id}, kb={self.knowledge_base_id}, role={self.role})>"
