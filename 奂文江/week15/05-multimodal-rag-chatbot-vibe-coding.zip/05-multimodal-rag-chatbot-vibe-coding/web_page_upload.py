"""Streamlit 文件管理页面"""
import os
from datetime import datetime

import streamlit as st
from sqlalchemy import desc

from core.database import get_db, ensure_db
from orm_model import Document, Permission
from models.schemas import DocStatus
from utils.logger import set_trace_id, logger

# 确保数据库已初始化
ensure_db()


def show_upload_page():
    st.title("文件管理")
    st.markdown("上传 PDF 文档，系统将自动解析并构建向量索引。")

    # ---- 上传区域 ----
    with st.expander("上传新文档", expanded=True):
        col1, col2 = st.columns(2)
        with col1:
            knowledge_base_id = st.text_input("知识库 ID", value="default")
        with col2:
            uploader = st.text_input("上传者", value="admin")

        uploaded_file = st.file_uploader(
            "选择 PDF 文件",
            type=["pdf"],
            help="仅支持 PDF 格式，最大 100MB",
        )

        if uploaded_file and st.button("上传", type="primary"):
            if uploaded_file.size > 100 * 1024 * 1024:
                st.error("文件大小超过限制（最大 100MB）")
            else:
                with st.spinner("正在上传和解析..."):
                    try:
                        # 调用上传 API（内联调用）
                        import io
                        from api.upload_api import file_service, kafka_service
                        from orm_model import Document
                        import uuid

                        trace_id = set_trace_id()
                        file_bytes = uploaded_file.getvalue()
                        file_hash = file_service.compute_md5_bytes(file_bytes)

                        db = get_db()
                        try:
                            # 幂等性校验
                            existing = db.query(Document).filter(
                                Document.file_hash == file_hash,
                                Document.knowledge_base_id == knowledge_base_id,
                            ).first()
                            if existing:
                                st.warning(f"文件已存在（doc_id: {existing.document_id}）")
                                st.info(f"文档 ID: {existing.document_id} | 状态: {existing.status}")
                                return

                            document_id = uuid.uuid4().hex
                            dest_path = file_service.save_upload(
                                document_id,
                                io.BytesIO(file_bytes),
                                uploaded_file.name,
                            )

                            doc = Document(
                                document_id=document_id,
                                knowledge_base_id=knowledge_base_id,
                                file_name=uploaded_file.name,
                                file_hash=file_hash,
                                file_size=uploaded_file.size,
                                uploader=uploader,
                                upload_time=datetime.utcnow(),
                                status=DocStatus.PENDING,
                                original_path=dest_path,
                            )
                            db.add(doc)
                            db.commit()

                            kafka_msg = {
                                "document_id": document_id,
                                "file_path": dest_path,
                                "knowledge_base_id": knowledge_base_id,
                                "upload_time": datetime.utcnow().isoformat(),
                            }
                            kafka_service.send_parse_task(kafka_msg)

                            st.success(f"上传成功！文档 ID: {document_id}")
                        except Exception as e:
                            db.rollback()
                            st.error(f"上传失败: {e}")
                            logger.error("Upload failed: %s", e)
                        finally:
                            db.close()
                    except Exception as e:
                        st.error(f"系统错误: {e}")

    # ---- 文档列表 ----
    st.subheader("文档列表")

    # 筛选
    col1, col2, col3 = st.columns(3)
    with col1:
        filter_kb = st.text_input("筛选知识库 ID", value="")
    with col2:
        filter_status = st.selectbox(
            "筛选状态",
            ["全部"] + DocStatus.CHOICES,
        )
    with col3:
        if st.button("刷新列表"):
            st.rerun()

    db = get_db()
    try:
        query = db.query(Document)
        if filter_kb:
            query = query.filter(Document.knowledge_base_id == filter_kb)
        if filter_status != "全部":
            query = query.filter(Document.status == filter_status)
        query = query.order_by(desc(Document.upload_time))

        docs = query.all()
        if not docs:
            st.info("暂无文档记录")
        else:
            for doc in docs:
                with st.container(border=True):
                    col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
                    with col1:
                        st.write(f"**{doc.file_name}**")
                        st.caption(f"ID: {doc.document_id} | KB: {doc.knowledge_base_id}")
                    with col2:
                        st.write(f"状态: **{doc.status}**")
                    with col3:
                        size_mb = doc.file_size / 1024 / 1024 if doc.file_size else 0
                        st.write(f"{size_mb:.1f} MB")
                    with col4:
                        st.write(doc.upload_time.strftime("%m-%d %H:%M") if doc.upload_time else "-")

                    if doc.error_msg:
                        st.error(f"错误信息: {doc.error_msg}")
    finally:
        db.close()
