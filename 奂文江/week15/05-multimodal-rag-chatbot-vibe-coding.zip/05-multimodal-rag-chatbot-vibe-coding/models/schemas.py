"""Pydantic 数据模型"""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


# ---------- Upload ----------

class UploadRequest(BaseModel):
    knowledge_base_id: str
    uploader: str


class UploadResponse(BaseModel):
    code: int = 200
    data: dict | None = None
    message: str = "success"

    @classmethod
    def ok(cls, document_id: str, is_duplicate: bool = False):
        return cls(data={"document_id": document_id, "is_duplicate": is_duplicate})

    @classmethod
    def error(cls, code: int, message: str):
        return cls(code=code, message=message)


# ---------- Chat ----------

class ChatRequest(BaseModel):
    user_id: str
    knowledge_base_id: str
    question: str = Field(..., min_length=1, max_length=4096)
    top_k: int = Field(default=5, ge=1, le=50)


class SourceInfo(BaseModel):
    file_name: str
    page_num: int
    type: str  # "text" | "image"


class ChatData(BaseModel):
    answer: str
    sources: list[SourceInfo] = []


class ChatResponse(BaseModel):
    code: int = 200
    data: ChatData | None = None
    message: str = "success"

    @classmethod
    def ok(cls, answer: str, sources: list[SourceInfo]):
        return cls(data=ChatData(answer=answer, sources=sources))

    @classmethod
    def error(cls, code: int, message: str):
        return cls(code=code, message=message)


# ---------- Document Status ----------

class DocStatus:
    PENDING = "pending"
    PARSING = "parsing"
    COMPLETED = "completed"
    DOWNLOAD_FAILED = "download_failed"
    PARSE_FAILED = "parse_failed"
    EMBEDDING_FAILED = "embedding_failed"
    SEND_FAILED = "send_failed"
    UPLOAD_FAILED = "upload_failed"

    CHOICES = [
        PENDING, PARSING, COMPLETED,
        DOWNLOAD_FAILED, PARSE_FAILED, EMBEDDING_FAILED,
        SEND_FAILED, UPLOAD_FAILED,
    ]


# ---------- Kafka Message ----------

class ParseTask(BaseModel):
    document_id: str
    file_path: str
    knowledge_base_id: str
    upload_time: str = ""
    retry_count: int = 0
