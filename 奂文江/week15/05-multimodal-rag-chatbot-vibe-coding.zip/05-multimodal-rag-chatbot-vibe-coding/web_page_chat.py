"""Streamlit 图文对话页面"""
import streamlit as st

from core.database import get_db, ensure_db
from core.embedding_service import EmbeddingService
from core.llm_service import LLMService
from core.milvus_service import MilvusService
from orm_model import Permission
from utils.logger import set_trace_id, logger
from utils.limiter import UserRateLimiter

ensure_db()

# 全局服务实例
embedding = EmbeddingService()
llm = LLMService()
milvus = MilvusService()
limiter = UserRateLimiter(2)


def show_chat_page():
    st.title("图文对话")
    st.markdown("基于已解析的文档进行多模态问答。")

    # ---- 侧边栏配置 ----
    with st.sidebar:
        st.subheader("对话配置")
        user_id = st.text_input("用户 ID", value="admin")
        knowledge_base_id = st.text_input("知识库 ID", value="default")
        top_k = st.slider("检索数量 (top_k)", min_value=1, max_value=20, value=5)

        st.divider()
        st.caption("提示：支持文本和图片相关的问题。")

    # ---- 权限检查 ----
    db = get_db()
    try:
        perm = db.query(Permission).filter(
            Permission.user_id == user_id,
            Permission.knowledge_base_id == knowledge_base_id,
        ).first()
        if not perm:
            st.warning(f"用户 {user_id} 暂无知识库 {knowledge_base_id} 的访问权限")
            st.info("请在数据库 permissions 表中添加权限记录")
    finally:
        db.close()

    # ---- 聊天历史 ----
    if "chat_messages" not in st.session_state:
        st.session_state.chat_messages = []

    for msg in st.session_state.chat_messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg.get("sources"):
                with st.expander("来源信息"):
                    for s in msg["sources"]:
                        st.caption(f"📄 {s.file_name} | 第{s.page_num}页 | 类型: {s.type}")

    # ---- 输入 ----
    if prompt := st.chat_input("请输入您的问题..."):
        st.session_state.chat_messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        # 限流检查
        if not limiter.check(user_id):
            st.error("请求过于频繁，请稍后重试")
            return

        # 生成回答
        with st.chat_message("assistant"):
            with st.spinner("正在检索和生成..."):
                try:
                    trace_id = set_trace_id()

                    # 1. 文本检索
                    logger.info("Text retrieval: kb=%s, top_k=%d", knowledge_base_id, top_k)
                    text_vec = embedding.embed_text(prompt)
                    text_results = milvus.search_text(text_vec, knowledge_base_id, top_k)

                    # 2. 图片检索
                    logger.info("Image retrieval: kb=%s, top_k=%d", knowledge_base_id, top_k)
                    image_vec = embedding.embed_text_clip(prompt)
                    image_results = milvus.search_image(image_vec, knowledge_base_id, top_k)

                    # 3. 构建上下文
                    context_texts = []
                    context_images = []
                    sources = []

                    for r in text_results:
                        sources.append({
                            "file_name": r.get("document_id", ""),
                            "page_num": r.get("page_num", 0),
                            "type": "text",
                        })
                        context_texts.append({
                            "content": f"文档={r.get('document_id')} 第{r.get('page_num', 0)}页",
                            "file_name": r.get("document_id", ""),
                            "page_num": r.get("page_num", 0),
                        })

                    for r in image_results:
                        sources.append({
                            "file_name": r.get("document_id", ""),
                            "page_num": r.get("page_num", 0),
                            "type": "image",
                        })
                        context_images.append({
                            "image_url": r.get("image_path", ""),
                            "file_name": r.get("document_id", ""),
                            "page_num": r.get("page_num", 0),
                        })

                    # 4. LLM 生成
                    if not context_texts and not context_images:
                        answer = "暂无相关信息"
                    else:
                        answer = llm.chat(prompt, context_texts, context_images)

                    # 5. 展示结果
                    st.markdown(answer)
                    if sources:
                        with st.expander("来源信息"):
                            for s in sources:
                                st.caption(f"📄 {s['file_name']} | 第{s['page_num']}页 | 类型: {s['type']}")

                    st.session_state.chat_messages.append({
                        "role": "assistant",
                        "content": answer,
                        "sources": sources,
                    })

                except Exception as e:
                    error_msg = f"生成失败: {e}"
                    st.error(error_msg)
                    logger.error("Chat error: %s", e)
