"""Streamlit 多页面入口"""
import streamlit as st

st.set_page_config(
    page_title="多模态 RAG 聊天机器人",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.sidebar.title("多模态 RAG")
st.sidebar.markdown("基于 PDF 文档的图文问答系统")
st.sidebar.divider()

# 导航
page = st.sidebar.radio(
    "导航",
    ["文件管理", "图文对话"],
    help="文件管理：上传和查看 PDF 文档\n图文对话：基于文档进行问答",
)

st.sidebar.divider()
st.sidebar.caption("v1.0 | 引擎: BGE + CLIP + Qwen-VL")

# 页面路由
if page == "文件管理":
    from web_page_upload import show_upload_page
    show_upload_page()
else:
    from web_page_chat import show_chat_page
    show_chat_page()
