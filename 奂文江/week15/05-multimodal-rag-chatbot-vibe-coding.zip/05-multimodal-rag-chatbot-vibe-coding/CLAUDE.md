# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

多模态 RAG 聊天机器人 — 从 PDF 文档（图文混排）中检索相关文本和图像，结合 LLM 生成答案。

## 核心架构

```
Client (Streamlit UI)
    │
    ├── 文件管理页面 ──→ 上传 API ──→ Kafka ──→ Offline Worker ──→ Milvus + MySQL
    │
    └── 图文对话页面 ──→ 检索 API ──→ BGE/CLIP ──→ Milvus ──→ Qwen-VL ──→ 答案
```

## 目录结构

```
project_root/
├── web_demo.py                    # Streamlit 入口（页面路由）
├── web_page_upload.py             # 文件管理页面（上传 + 文档列表）
├── web_page_chat.py               # 图文对话页面（多模态问答）
├── offline_process_worker.py      # 离线解析 Worker（Kafka 消费者）
├── main.py                        # FastAPI 应用入口
├── orm_model.py                   # SQLAlchemy 模型
│
├── api/                           # HTTP API 层
│   ├── upload_api.py              # POST /api/upload/document
│   ├── chat_api.py                # POST /api/chat
│   └── router.py                  # 路由汇总
│
├── core/                          # 核心业务服务
│   ├── database.py                # 数据库会话管理
│   ├── file_service.py            # 文件存储（本地/OSS）
│   ├── kafka_service.py           # Kafka 生产/消费
│   ├── milvus_service.py          # Milvus 向量数据库
│   ├── embedding_service.py       # BGE + CLIP 向量化
│   └── llm_service.py             # Qwen-VL 多模态生成
│
├── worker/                        # 离线 Worker 模块
│   ├── pdf_parser.py              # MinerU/DeepSeek-OCR 解析
│   ├── chunk_splitter.py          # Markdown 分块
│   └── vectorize_pipeline.py      # 向量化流水线
│
├── models/                        # 数据模型
│   └── schemas.py                 # Pydantic 请求/响应模型
│
├── config/                        # 配置
│   └── settings.py                # 全局配置（环境变量）
│
├── utils/                         # 工具
│   ├── retry.py                   # 重试装饰器
│   ├── logger.py                  # 日志 + trace_id
│   └── limiter.py                 # 令牌桶限流器
│
└── requirements.txt               # 依赖清单
```

## 服务依赖

| 服务 | 用途 | 本地默认端口 |
|------|------|-------------|
| Kafka | 消息队列（parse_document_topic） | localhost:9092 |
| Milvus | 向量数据库（text_chunk + image_chunk） | localhost:19530 |
| MySQL/SQLite | 元信息数据库（文档/Chunk/图片/权限表） | 可配置 |
| MinerU | PDF 解析引擎（主） | http://127.0.0.1:30000 |
| DeepSeek-OCR | PDF 解析引擎（备） | API |
| BGE | 文本向量化（bge-small-zh-v1.5） | 本地/API |
| CLIP | 图文向量化（jina-clip-v2） | 本地/API |
| Qwen-VL | 多模态生成模型 | DashScope API |

## 启动方式

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 启动 FastAPI 服务（可选，供外部调用）
python main.py

# 3. 启动 Streamlit Web UI
streamlit run web_demo.py

# 4. 启动离线文档处理 Worker（需先启动 Kafka）
python offline_process_worker.py
```

## 文档上传处理流程

1. PDF 上传（页面或 API）→ 校验格式/大小 → MD5 幂等校验
2. 保存到 `uploads/{document_id}/{document_id}.pdf`
3. 写 MySQL documents 表，状态 `pending`
4. 发 Kafka 消息到 `parse_document_topic`
5. Worker 消费 → 下载 PDF → MinerU 解析（失败切 DeepSeek-OCR）
6. Markdown 分块（1000token + 200overlap）
7. BGE 文本向量化 → 写入 Milvus text_chunk 集合
8. CLIP 图片向量化 → 写入 Milvus image_chunk 集合
9. Chunk/图片元信息写入 MySQL
10. 更新文档状态为 `completed`

## 问答流程

1. 权限校验 → 限流（2 req/s）
2. 用户提问 → BGE 向量化 → Milvus 文本检索（Top-K）
3. CLIP 向量化 → Milvus 图片检索（Top-K）
4. 图文上下文拼接（含来源标记）
5. 送 Qwen-VL 生成答案
6. 返回答案 + 来源列表（文档名 + 页码）

## 文档状态枚举

pending → parsing → completed
                    → download_failed / parse_failed / embedding_failed
send_failed / upload_failed

## 测试

```bash
# 运行测试（待完善）
pytest tests/
```

## 配置方式

所有配置通过环境变量读取，默认值在 `config/settings.py` 中。
可创建 `.env` 文件覆盖配置，或直接设置环境变量。
