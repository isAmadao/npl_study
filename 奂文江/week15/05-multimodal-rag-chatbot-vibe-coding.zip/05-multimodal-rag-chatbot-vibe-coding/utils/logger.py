"""日志配置 + trace_id 支持"""
import logging
import sys
import uuid
from contextvars import ContextVar
from typing import Optional

trace_id_var: ContextVar[str] = ContextVar("trace_id", default="")


def get_trace_id() -> str:
    return trace_id_var.get()


def set_trace_id(trace_id: Optional[str] = None) -> str:
    if not trace_id:
        trace_id = uuid.uuid4().hex[:16]
    trace_id_var.set(trace_id)
    return trace_id


class TraceIdFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.trace_id = get_trace_id() or "-"
        return True


def setup_logger(name: str = "rag", level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.handlers.clear()

    fmt = (
        "%(asctime)s | %(levelname)-5s | trace=%(trace_id)s | "
        "%(name)s | %(message)s"
    )
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter(fmt))
    handler.addFilter(TraceIdFilter())
    logger.addHandler(handler)
    return logger


logger = setup_logger()
