"""限流器（令牌桶）"""
import asyncio
import time
from collections import defaultdict
from threading import Lock


class TokenBucket:
    """令牌桶限流器"""

    def __init__(self, rate: float, burst: int = 1):
        self.rate = rate
        self.burst = burst
        self.tokens = burst
        self.last_refill = time.monotonic()
        self._lock = Lock()

    def _refill(self):
        now = time.monotonic()
        elapsed = now - self.last_refill
        self.tokens = min(self.burst, self.tokens + elapsed * self.rate)
        self.last_refill = now

    def acquire(self, tokens: int = 1) -> bool:
        with self._lock:
            self._refill()
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True
            return False


class UserRateLimiter:
    """按用户限流"""

    def __init__(self, default_rate: float = 2.0):
        self.default_rate = default_rate
        self._buckets: dict[str, TokenBucket] = {}
        self._lock = Lock()

    def get_bucket(self, user_id: str) -> TokenBucket:
        with self._lock:
            if user_id not in self._buckets:
                self._buckets[user_id] = TokenBucket(self.default_rate, burst=2)
            return self._buckets[user_id]

    def check(self, user_id: str) -> bool:
        return self.get_bucket(user_id).acquire(1)
