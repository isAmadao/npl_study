"""重试装饰器"""
import asyncio
import functools
import logging
import time
from typing import Optional, Type, Union

logger = logging.getLogger(__name__)


def retry(
    max_retries: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: Union[Type[Exception], tuple] = Exception,
    on_retry: Optional[callable] = None,
):
    """同步/异步函数重试装饰器。

    Args:
        max_retries: 最大重试次数
        delay: 初始重试延迟（秒）
        backoff: 延迟倍数
        exceptions: 需要重试的异常类型
        on_retry: 每次重试前的回调，参数：(exc, attempt, max_retries)
    """
    def decorator(func):
        is_async = asyncio.iscoroutinefunction(func)

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            last_exc = None
            wait = delay
            for attempt in range(1, max_retries + 2):  # 第1次是原调用
                try:
                    return await func(*args, **kwargs)
                except exceptions as e:
                    last_exc = e
                    if attempt > max_retries:
                        raise
                    if on_retry:
                        on_retry(e, attempt, max_retries)
                    logger.warning(
                        "%s failed (attempt %d/%d): %s. Retrying in %.1fs...",
                        func.__name__, attempt, max_retries, e, wait,
                    )
                    await asyncio.sleep(wait)
                    wait *= backoff

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            last_exc = None
            wait = delay
            for attempt in range(1, max_retries + 2):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exc = e
                    if attempt > max_retries:
                        raise
                    if on_retry:
                        on_retry(e, attempt, max_retries)
                    logger.warning(
                        "%s failed (attempt %d/%d): %s. Retrying in %.1fs...",
                        func.__name__, attempt, max_retries, e, wait,
                    )
                    time.sleep(wait)
                    wait *= backoff

        return async_wrapper if is_async else sync_wrapper
    return decorator
