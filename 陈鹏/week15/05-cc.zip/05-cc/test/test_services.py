"""
服务层测试
"""
import pytest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestRAGService:
    """RAG 服务测试"""

    def test_text_split(self):
        """测试文本分块"""
        from app.services.rag_service import rag_service

        text = "这是一段测试文本，用于验证滑动窗口分块功能。" * 20
        chunks = rag_service.split_text(text, chunk_size=50, overlap=10)

        assert len(chunks) > 1
        for chunk in chunks:
            assert len(chunk) <= 60


class TestDatabase:
    """数据库测试"""

    def test_create_tables(self):
        """测试表创建"""
        from app.models.database import Base

        assert Base.metadata.tables

    def test_session(self):
        """测试会话"""
        from sqlalchemy import text
        from app.models.database import SessionLocal

        db = SessionLocal()
        try:
            db.execute(text("SELECT 1"))
        finally:
            db.close()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])