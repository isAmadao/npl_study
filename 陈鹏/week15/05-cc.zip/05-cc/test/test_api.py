
"""
API 接口测试
"""
import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@pytest.fixture
def client():
    """创建测试客户端"""
    from app.main import app
    return TestClient(app)


class TestHealthCheck:
    """健康检查测试"""

    def test_health(self, client):
        """测试健康检查接口"""
        with patch("app.services.elasticsearch.es_client.health_check", return_value=True):
            response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"


class TestKnowledgeBaseAPI:
    """知识库 API 测试"""

    def test_create_knowledge_base(self, client):
        """测试创建知识库"""
        response = client.post(
            "/api/v1/knowledge_bases",
            json={
                "title": "测试知识库",
                "category": "测试",
                "description": "这是一个测试知识库"
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert data["response_code"] == 200
        assert data["data"]["title"] == "测试知识库"

    def test_list_knowledge_bases(self, client):
        """测试获取知识库列表"""
        response = client.get("/api/v1/knowledge_bases")
        assert response.status_code == 200
        data = response.json()
        assert "data" in data
        assert "total" in data

    def test_get_knowledge_base(self, client):
        """测试获取单个知识库"""
        create_response = client.post(
            "/api/v1/knowledge_bases",
            json={"title": "获取测试", "category": "测试"}
        )
        kb_id = create_response.json()["data"]["id"]

        response = client.get(f"/api/v1/knowledge_bases/{kb_id}")
        assert response.status_code == 200
        data = response.json()
        assert data["response_code"] == 200

    def test_update_knowledge_base(self, client):
        """测试更新知识库"""
        create_response = client.post(
            "/api/v1/knowledge_bases",
            json={"title": "更新测试", "category": "测试"}
        )
        kb_id = create_response.json()["data"]["id"]

        response = client.put(
            f"/api/v1/knowledge_bases/{kb_id}",
            json={"title": "更新后的标题"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["title"] == "更新后的标题"

    def test_delete_knowledge_base(self, client):
        """测试删除知识库"""
        create_response = client.post(
            "/api/v1/knowledge_bases",
            json={"title": "删除测试", "category": "测试"}
        )
        kb_id = create_response.json()["data"]["id"]

        response = client.delete(f"/api/v1/knowledge_bases/{kb_id}")
        assert response.status_code == 200
        assert response.json()["response_code"] == 200


class TestDocumentAPI:
    """文档 API 测试"""

    def test_list_documents(self, client):
        """测试获取文档列表"""
        kb_response = client.post(
            "/api/v1/knowledge_bases",
            json={"title": "文档测试知识库", "category": "测试"}
        )
        kb_id = kb_response.json()["data"]["id"]

        response = client.get(f"/api/v1/documents?knowledge_base_id={kb_id}")
        assert response.status_code == 200
        data = response.json()
        assert "data" in data
        assert data["total"] == 0


class TestAIAPI:
    """AI 能力 API 测试"""

    def test_embedding(self, client):
        """测试文本嵌入"""
        response = client.post(
            "/api/v1/embedding",
            json={"text": "测试文本", "model": "bge-small-zh-v1.5"}
        )
        assert response.status_code in [200, 500]

    def test_search(self, client):
        """测试检索接口"""
        response = client.post(
            "/api/v1/search",
            json={
                "knowledge_base_id": 1,
                "query": "测试查询",
                "top_k": 10
            }
        )
        assert response.status_code in [200, 500]

    def test_chat(self, client):
        """测试对话接口"""
        response = client.post(
            "/api/v1/chat",
            json={
                "knowledge_base_id": 1,
                "messages": [{"role": "user", "content": "你好"}]
            }
        )
        assert response.status_code in [200, 500]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])