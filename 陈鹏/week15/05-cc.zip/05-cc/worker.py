#!/usr/bin/env python
"""
文档解析 Worker 启动脚本

启动方式:
    python worker.py                    # 前台运行
    python worker.py --workers 4        # 启动 4 个 Worker 进程

环境变量:
    KAFKA_BOOTSTRAP_SERVERS: Kafka 集群地址
    KAFKA_CONSUMER_GROUP: 消费者组名称
"""
import os
import sys
import argparse
import multiprocessing


def main():
    parser = argparse.ArgumentParser(description="多模态 RAG 文档解析 Worker")
    parser.add_argument("--workers", type=int, default=1, help="Worker 进程数")
    args = parser.parse_args()

    print("=" * 60)
    print("多模态 RAG 文档解析 Worker")
    print("=" * 60)

    # 添加项目路径
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

    from app.core.config import settings

    if not settings.KAFKA_ENABLED:
        print("错误: Kafka 未启用，请在配置中设置 KAFKA_ENABLED=True")
        print("当前使用本地模式，无需启动 Worker")
        sys.exit(1)

    print(f"Kafka 服务器: {settings.KAFKA_BOOTSTRAP_SERVERS}")
    print(f"消费者组: {settings.KAFKA_CONSUMER_GROUP}")
    print(f"Topic: {settings.KAFKA_PARSE_TOPIC}")
    print(f"Worker 数量: {args.workers}")
    print("=" * 60)

    if args.workers > 1:
        # 多进程模式
        processes = []
        for i in range(args.workers):
            p = multiprocessing.Process(target=run_worker, args=(i,))
            p.start()
            processes.append(p)
            print(f"Worker {i} 已启动 (PID: {p.pid})")

        # 等待所有进程
        for p in processes:
            p.join()
    else:
        # 单进程模式
        run_worker(0)


def run_worker(worker_id: int):
    """运行单个 Worker"""
    from app.services.kafka_consumer import KafkaConsumerService

    print(f"Worker {worker_id} 开始运行...")
    consumer = KafkaConsumerService()
    consumer.start(blocking=True)


if __name__ == "__main__":
    main()
