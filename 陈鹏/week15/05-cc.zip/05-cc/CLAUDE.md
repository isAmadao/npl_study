# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

多模态 RAG 系统项目，支持 PDF 文档深度解析、图表/图像理解、跨模态检索和图文混合问答。

## 核心架构

```
PDF 文档 → MinerU 解析 → 文本/表格/图像分离
    ↓
图像 → CLIP/Qwen-VL → 特征提取 + 文本描述
    ↓
文本 + 图像描述 → CLIP 向量化 → 向量数据库
    ↓
用户查询 → 跨模态检索 → 文本+图像 Context → LLM 问答
```

## 技术栈

- **PDF 解析**: MinerU（本地部署）
- **多模态模型**: CLIP / Qwen-VL
- **向量数据库**: Milvus 或 Elasticsearch dense_vector
- **LLM**: 通义千问（OpenAI 兼容 API）
- **消息队列**: Kafka（分布式文档处理）
- **后端框架**: FastAPI

## 模型配置

使用阿里云通义千问 API：

```python
from langchain_openai import ChatOpenAI
llm = ChatOpenAI(
    model="qwen-flash",
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    api_key="your-api-key"
)
```

## 开发要求

1. 实现现有接口（参考 04-government-advanced-rag 项目结构）
2. 编写需求文档和测试逻辑
3. 完成架构设计和初步代码

## 参考项目

- `04-government-advanced-rag`: RAG 流水线、ES 索引结构、分块算法

## 环境变量

```bash
OPENAI_API_KEY=your_dashscope_key
OPENAI_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
```