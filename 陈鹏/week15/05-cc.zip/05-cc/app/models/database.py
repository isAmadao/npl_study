"""
数据库模型定义
"""
from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from datetime import datetime
import os

from app.core.config import settings

# 确保数据目录存在
os.makedirs("data", exist_ok=True)

# 创建数据库引擎
if settings.DB_ENGINE == "sqlite":
    engine = create_engine(f"sqlite:///{settings.DB_PATH}", echo=False)
else:
    engine = create_engine(
        f"{settings.DB_ENGINE}://{settings.DB_USERNAME}:{settings.DB_PASSWORD}"
        f"@{settings.DB_HOST}:{settings.DB_PORT}/{settings.DB_DATABASE}",
        echo=False
    )

Base = declarative_base()


class KnowledgeBase(Base):
    """知识库表"""
    __tablename__ = 'knowledge_base'

    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String(255), nullable=False)
    category = Column(String(100))
    description = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    documents = relationship("Document", back_populates="knowledge_base")


class Document(Base):
    """文档表"""
    __tablename__ = 'document'

    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String(255), nullable=False)
    category = Column(String(100))
    knowledge_base_id = Column(Integer, ForeignKey('knowledge_base.id'))
    file_path = Column(String(500))
    file_type = Column(String(50))
    file_size = Column(Integer, default=0)
    parse_status = Column(String(20), default="pending")
    total_pages = Column(Integer, default=0)
    total_chunks = Column(Integer, default=0)
    total_images = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    knowledge_base = relationship("KnowledgeBase", back_populates="documents")
    chunks = relationship("DocumentChunk", back_populates="document")
    images = relationship("ExtractedImage", back_populates="document")


class DocumentChunk(Base):
    """文档分块表"""
    __tablename__ = 'document_chunk'

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(Integer, ForeignKey('document.id'))
    knowledge_base_id = Column(Integer, ForeignKey('knowledge_base.id'))
    page_number = Column(Integer)
    chunk_index = Column(Integer)
    content = Column(Text)
    content_type = Column(String(20), default="text")
    created_at = Column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="chunks")


class ExtractedImage(Base):
    """提取的图像表"""
    __tablename__ = 'extracted_image'

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(Integer, ForeignKey('document.id'))
    page_number = Column(Integer)
    image_path = Column(String(500))
    image_type = Column(String(50))
    description = Column(Text)
    width = Column(Integer, default=0)
    height = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="images")


# 创建所有表
Base.metadata.create_all(engine)

# 创建会话
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    """获取数据库会话"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()