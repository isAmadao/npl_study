"""
文档管理路由
"""
import os
import uuid
import time
from fastapi import APIRouter, Depends, UploadFile, File, Form, BackgroundTasks, HTTPException
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.database import get_db, KnowledgeBase, Document, SessionLocal
from app.schemas.responses import (
    DocumentInfo, DocumentListResponse, DocumentResponse,
    ParseStatusResponse, UploadResponse
)
from app.services.rag_service import rag_service
from app.services.elasticsearch import es_client
from app.services.kafka_producer import kafka_producer

router = APIRouter(prefix="/documents", tags=["文档管理"])


def process_document(document_id: int, file_path: str, knowledge_base_id: int, title: str):
    """后台处理文档（本地模式）"""
    db = SessionLocal()
    try:
        doc = db.query(Document).filter(Document.id == document_id).first()
        if doc:
            doc.parse_status = "processing"
            db.commit()

        result = rag_service.index_document(document_id, knowledge_base_id, file_path, title)

        doc = db.query(Document).filter(Document.id == document_id).first()
        if doc:
            doc.parse_status = "completed"
            doc.total_pages = result["total_pages"]
            doc.total_chunks = result["total_chunks"]
            doc.total_images = result["total_images"]
            db.commit()

    except Exception as e:
        print(f"文档处理失败: {e}")
        doc = db.query(Document).filter(Document.id == document_id).first()
        if doc:
            doc.parse_status = "failed"
            db.commit()
    finally:
        db.close()


def dispatch_parse_task(document_id: int, file_path: str, knowledge_base_id: int, title: str) -> bool:
    """
    分发解析任务

    优先使用 Kafka 分布式处理，失败则使用本地后台任务

    Returns:
        是否通过 Kafka 分发成功
    """
    if settings.KAFKA_ENABLED:
        success = kafka_producer.send_parse_task(
            document_id=document_id,
            knowledge_base_id=knowledge_base_id,
            file_path=file_path,
            title=title
        )
        if success:
            print(f"解析任务已发送到 Kafka: document_id={document_id}")
            return True
        else:
            print(f"Kafka 发送失败，降级到本地处理: document_id={document_id}")

    return False


@router.get("", response_model=DocumentListResponse)
def list_documents(
    knowledge_base_id: int,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """获取文档列表"""
    start_time = time.time()

    query = db.query(Document).filter(Document.knowledge_base_id == knowledge_base_id)
    total = query.count()
    records = query.offset(skip).limit(limit).all()

    data = [
        DocumentInfo(
            id=r.id,
            title=r.title,
            category=r.category or "",
            knowledge_base_id=r.knowledge_base_id,
            file_type=r.file_type or "",
            file_size=r.file_size,
            file_path=r.file_path or "",
            parse_status=r.parse_status,
            total_pages=r.total_pages,
            total_chunks=r.total_chunks,
            total_images=r.total_images,
            created_at=r.created_at
        ) for r in records
    ]

    return DocumentListResponse(
        request_id=str(uuid.uuid4()),
        data=data,
        total=total,
        processing_time=time.time() - start_time
    )


@router.get("/{id}", response_model=DocumentResponse)
def get_document(id: int, db: Session = Depends(get_db)):
    """获取文档详情"""
    start_time = time.time()

    record = db.query(Document).filter(Document.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail="文档不存在")

    data = DocumentInfo(
        id=record.id,
        title=record.title,
        category=record.category or "",
        knowledge_base_id=record.knowledge_base_id,
        file_type=record.file_type or "",
        file_size=record.file_size,
        file_path=record.file_path or "",
        parse_status=record.parse_status,
        total_pages=record.total_pages,
        total_chunks=record.total_chunks,
        total_images=record.total_images,
        created_at=record.created_at
    )

    return DocumentResponse(
        request_id=str(uuid.uuid4()),
        data=data,
        processing_time=time.time() - start_time
    )


@router.post("", response_model=UploadResponse)
async def upload_document(
    knowledge_base_id: int = Form(...),
    title: str = Form(...),
    category: str = Form(""),
    file: UploadFile = File(...),
    background_tasks: BackgroundTasks = None,
    db: Session = Depends(get_db)
):
    """上传文档"""
    start_time = time.time()

    kb = db.query(KnowledgeBase).filter(KnowledgeBase.id == knowledge_base_id).first()
    if not kb:
        raise HTTPException(status_code=404, detail="知识库不存在")

    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    file_ext = os.path.splitext(file.filename)[1]
    file_name = f"{uuid.uuid4()}{file_ext}"
    file_path = os.path.join(settings.UPLOAD_DIR, file_name)

    content = await file.read()
    with open(file_path, "wb") as f:
        f.write(content)

    document = Document(
        title=title,
        category=category,
        knowledge_base_id=knowledge_base_id,
        file_path=file_path,
        file_type=file.content_type,
        file_size=len(content),
        parse_status="pending"
    )
    db.add(document)
    db.commit()
    db.refresh(document)

    # 分发解析任务：优先 Kafka，失败则本地处理
    kafka_sent = dispatch_parse_task(document.id, file_path, knowledge_base_id, title)

    if not kafka_sent:
        # Kafka 未启用或发送失败，使用本地后台任务
        background_tasks.add_task(
            process_document,
            document.id, file_path, knowledge_base_id, title
        )

    response_msg = "文档上传成功"
    if kafka_sent:
        response_msg += "，已发送到 Kafka 队列等待解析"
    else:
        response_msg += "，正在后台解析"

    return UploadResponse(
        request_id=str(uuid.uuid4()),
        document_id=document.id,
        file_name=file.filename,
        file_size=len(content),
        file_type=file.content_type,
        response_msg=response_msg,
        processing_time=time.time() - start_time
    )


@router.get("/{id}/status", response_model=ParseStatusResponse)
def get_parse_status(id: int, db: Session = Depends(get_db)):
    """获取文档解析状态"""
    start_time = time.time()

    record = db.query(Document).filter(Document.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail="文档不存在")

    progress = 0.0
    if record.total_pages > 0:
        progress = min((record.total_chunks / (record.total_pages * 5)) * 100, 100.0)

    return ParseStatusResponse(
        request_id=str(uuid.uuid4()),
        document_id=id,
        status=record.parse_status,
        parsed_pages=record.total_pages,
        total_pages=record.total_pages,
        extracted_images=record.total_images,
        progress=progress,
        processing_time=time.time() - start_time
    )


@router.delete("/{id}")
def delete_document(id: int, db: Session = Depends(get_db)):
    """删除文档"""
    start_time = time.time()

    record = db.query(Document).filter(Document.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail="文档不存在")

    try:
        es_client.delete_by_document(id)
    except Exception:
        pass

    if record.file_path and os.path.exists(record.file_path):
        os.remove(record.file_path)

    db.delete(record)
    db.commit()

    return {
        "request_id": str(uuid.uuid4()),
        "response_code": 200,
        "response_msg": "文档删除成功",
        "processing_time": time.time() - start_time
    }