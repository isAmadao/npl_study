"""
知识库管理路由
"""
import uuid
import time
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Optional

from app.models.database import get_db, KnowledgeBase, Document
from app.schemas.responses import (
    KnowledgeBaseCreate, KnowledgeBaseUpdate, KnowledgeBaseInfo,
    KnowledgeBaseListResponse, KnowledgeBaseResponse
)
from app.services.elasticsearch import es_client

router = APIRouter(prefix="/knowledge_bases", tags=["知识库管理"])


@router.get("", response_model=KnowledgeBaseListResponse)
def list_knowledge_bases(
    skip: int = 0,
    limit: int = 100,
    category: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """获取知识库列表"""
    start_time = time.time()

    query = db.query(KnowledgeBase)
    if category:
        query = query.filter(KnowledgeBase.category == category)

    total = query.count()
    records = query.offset(skip).limit(limit).all()

    data = []
    for r in records:
        doc_count = db.query(Document).filter(Document.knowledge_base_id == r.id).count()
        data.append(KnowledgeBaseInfo(
            id=r.id,
            title=r.title,
            category=r.category or "",
            description=r.description or "",
            document_count=doc_count,
            created_at=r.created_at,
            updated_at=r.updated_at
        ))

    return KnowledgeBaseListResponse(
        request_id=str(uuid.uuid4()),
        data=data,
        total=total,
        processing_time=time.time() - start_time
    )


@router.get("/{id}", response_model=KnowledgeBaseResponse)
def get_knowledge_base(id: int, db: Session = Depends(get_db)):
    """获取单个知识库"""
    start_time = time.time()

    record = db.query(KnowledgeBase).filter(KnowledgeBase.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail="知识库不存在")

    doc_count = db.query(Document).filter(Document.knowledge_base_id == id).count()
    data = KnowledgeBaseInfo(
        id=record.id,
        title=record.title,
        category=record.category or "",
        description=record.description or "",
        document_count=doc_count,
        created_at=record.created_at,
        updated_at=record.updated_at
    )

    return KnowledgeBaseResponse(
        request_id=str(uuid.uuid4()),
        data=data,
        processing_time=time.time() - start_time
    )


@router.post("", response_model=KnowledgeBaseResponse)
def create_knowledge_base(req: KnowledgeBaseCreate, db: Session = Depends(get_db)):
    """创建知识库"""
    start_time = time.time()

    record = KnowledgeBase(
        title=req.title,
        category=req.category,
        description=req.description
    )
    db.add(record)
    db.commit()
    db.refresh(record)

    data = KnowledgeBaseInfo(
        id=record.id,
        title=record.title,
        category=record.category or "",
        description=record.description or "",
        document_count=0,
        created_at=record.created_at,
        updated_at=record.updated_at
    )

    return KnowledgeBaseResponse(
        request_id=str(uuid.uuid4()),
        data=data,
        response_msg="知识库创建成功",
        processing_time=time.time() - start_time
    )


@router.put("/{id}", response_model=KnowledgeBaseResponse)
def update_knowledge_base(id: int, req: KnowledgeBaseUpdate, db: Session = Depends(get_db)):
    """更新知识库"""
    start_time = time.time()

    record = db.query(KnowledgeBase).filter(KnowledgeBase.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail="知识库不存在")

    if req.title:
        record.title = req.title
    if req.category:
        record.category = req.category
    if req.description:
        record.description = req.description
    db.commit()
    db.refresh(record)

    doc_count = db.query(Document).filter(Document.knowledge_base_id == id).count()
    data = KnowledgeBaseInfo(
        id=record.id,
        title=record.title,
        category=record.category or "",
        description=record.description or "",
        document_count=doc_count,
        created_at=record.created_at,
        updated_at=record.updated_at
    )

    return KnowledgeBaseResponse(
        request_id=str(uuid.uuid4()),
        data=data,
        response_msg="知识库更新成功",
        processing_time=time.time() - start_time
    )


@router.delete("/{id}")
def delete_knowledge_base(id: int, db: Session = Depends(get_db)):
    """删除知识库"""
    start_time = time.time()

    record = db.query(KnowledgeBase).filter(KnowledgeBase.id == id).first()
    if not record:
        raise HTTPException(status_code=404, detail="知识库不存在")

    # 删除关联文档的 ES 数据
    documents = db.query(Document).filter(Document.knowledge_base_id == id).all()
    for doc in documents:
        try:
            es_client.delete_by_document(doc.id)
        except Exception:
            pass

    db.query(Document).filter(Document.knowledge_base_id == id).delete()
    db.delete(record)
    db.commit()

    return {
        "request_id": str(uuid.uuid4()),
        "response_code": 200,
        "response_msg": "知识库删除成功",
        "processing_time": time.time() - start_time
    }