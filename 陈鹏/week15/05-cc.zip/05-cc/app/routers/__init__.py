# routers 包初始化
from app.routers import knowledge_base, document, ai