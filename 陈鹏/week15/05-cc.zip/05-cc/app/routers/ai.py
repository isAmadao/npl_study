"""
AI 能力路由 - 嵌入、检索、对话
"""
import uuid
import time
from fastapi import APIRouter, HTTPException

from app.core.config import settings
from app.schemas.responses import (
    EmbeddingRequest, EmbeddingResponse,
    MultimodalEmbeddingRequest, MultimodalEmbeddingResponse,
    SearchRequest, SearchResponse, SearchResult,
    ChatRequest, ChatResponse, ChatMessage,
    ImageUnderstandingRequest, ImageUnderstandingResponse,
    RerankRequest, RerankResponse
)
from app.services.rag_service import rag_service, embedding_service

router = APIRouter(tags=["AI 能力"])


@router.post("/embedding", response_model=EmbeddingResponse)
def get_embedding(req: EmbeddingRequest):
    """文本嵌入接口"""
    start_time = time.time()

    try:
        text = req.text if isinstance(req.text, list) else [req.text]
        vectors = embedding_service.get_text_embedding(text)

        return EmbeddingResponse(
            request_id=str(uuid.uuid4()),
            vectors=vectors.tolist(),
            dims=vectors.shape[1] if len(vectors.shape) > 1 else len(vectors),
            model=req.model,
            processing_time=time.time() - start_time
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"嵌入失败: {str(e)}")


@router.post("/multimodal_embedding", response_model=MultimodalEmbeddingResponse)
def get_multimodal_embedding(req: MultimodalEmbeddingRequest):
    """多模态嵌入接口"""
    start_time = time.time()

    try:
        text_vector = None
        image_vector = None

        if req.text:
            text_vector = embedding_service.get_text_embedding(req.text).tolist()

        if req.image_path:
            image_vector = embedding_service.get_image_embedding(req.image_path).tolist()

        return MultimodalEmbeddingResponse(
            request_id=str(uuid.uuid4()),
            text_vector=text_vector,
            image_vector=image_vector,
            dims=settings.MULTIMODAL_DIMS,
            processing_time=time.time() - start_time
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"多模态嵌入失败: {str(e)}")


@router.post("/search", response_model=SearchResponse)
def search(req: SearchRequest):
    """跨模态检索接口"""
    start_time = time.time()

    try:
        results = rag_service.search(
            query=req.query,
            knowledge_base_id=req.knowledge_base_id,
            top_k=req.top_k,
            search_type=req.search_type
        )

        search_results = [
            SearchResult(
                chunk_id=str(r.get("chunk_id", "")),
                document_id=r.get("document_id", 0),
                page_number=r.get("page_number", 0),
                content=r.get("content", ""),
                score=r.get("score", 0.0),
                content_type=r.get("content_type", "text"),
                image_path=r.get("image_path"),
                image_description=r.get("image_description")
            ) for r in results
        ]

        return SearchResponse(
            request_id=str(uuid.uuid4()),
            results=search_results,
            total=len(search_results),
            processing_time=time.time() - start_time
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"检索失败: {str(e)}")


@router.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    """RAG 对话接口（支持图文混排）"""
    start_time = time.time()

    try:
        messages = [{"role": m.role, "content": m.content} for m in req.messages]
        result = rag_service.chat(
            knowledge_base_id=req.knowledge_base_id,
            messages=messages,
            include_images=req.include_images
        )

        # 构建来源列表
        sources = [
            SearchResult(
                chunk_id=str(s.get("chunk_id", "")),
                document_id=s.get("document_id", 0),
                page_number=s.get("page_number", 0),
                content=s.get("content", ""),
                score=s.get("score", 0.0),
                content_type=s.get("content_type", "text"),
                image_path=s.get("image_path"),
                image_description=s.get("image_description")
            ) for s in result.get("sources", [])
        ]

        # 构建相关图像列表
        related_images = [
            img.get("image_path", "") for img in result.get("related_images", [])
            if img.get("image_path")
        ]

        return ChatResponse(
            request_id=str(uuid.uuid4()),
            messages=[ChatMessage(role=m["role"], content=m["content"]) for m in result["messages"]],
            related_images=related_images,
            sources=sources,
            processing_time=time.time() - start_time
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"对话失败: {str(e)}")


@router.post("/image/understand", response_model=ImageUnderstandingResponse)
def understand_image(req: ImageUnderstandingRequest):
    """图像理解接口"""
    start_time = time.time()

    try:
        description = rag_service.describe_image(req.image_path)

        return ImageUnderstandingResponse(
            request_id=str(uuid.uuid4()),
            description=description,
            processing_time=time.time() - start_time
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"图像理解失败: {str(e)}")


@router.post("/rerank", response_model=RerankResponse)
def rerank(req: RerankRequest):
    """重排序接口"""
    start_time = time.time()

    scores = [0.5] * len(req.documents)
    return RerankResponse(
        request_id=str(uuid.uuid4()),
        scores=scores,
        ranked_indices=list(range(len(req.documents))),
        processing_time=time.time() - start_time
    )