"""
FastAPI 应用初始化
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.routers import knowledge_base, document, ai


def create_app() -> FastAPI:
    """创建 FastAPI 应用"""
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        docs_url="/docs",
        redoc_url="/redoc"
    )

    # CORS 中间件
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # 注册路由
    app.include_router(knowledge_base.router, prefix=settings.API_PREFIX)
    app.include_router(document.router, prefix=settings.API_PREFIX)
    app.include_router(ai.router, prefix=settings.API_PREFIX)

    # 健康检查
    @app.get("/health")
    def health_check():
        """健康检查接口"""
        from app.services.elasticsearch import es_client
        from app.services.kafka_producer import kafka_producer

        es_healthy = es_client.health_check()
        kafka_healthy = kafka_producer.health_check() if settings.KAFKA_ENABLED else None

        return {
            "status": "healthy" if es_healthy else "degraded",
            "version": settings.APP_VERSION,
            "services": {
                "elasticsearch": "healthy" if es_healthy else "unhealthy",
                "kafka": "healthy" if kafka_healthy else ("disabled" if kafka_healthy is None else "unhealthy")
            }
        }

    # Kafka 状态接口
    @app.get("/kafka/status")
    def kafka_status():
        """Kafka 状态接口"""
        if not settings.KAFKA_ENABLED:
            return {
                "enabled": False,
                "message": "Kafka 未启用，使用本地后台任务处理"
            }

        from app.services.kafka_producer import kafka_producer
        healthy = kafka_producer.health_check()

        return {
            "enabled": True,
            "healthy": healthy,
            "bootstrap_servers": settings.KAFKA_BOOTSTRAP_SERVERS,
            "parse_topic": settings.KAFKA_PARSE_TOPIC,
            "consumer_group": settings.KAFKA_CONSUMER_GROUP
        }

    return app


app = create_app()