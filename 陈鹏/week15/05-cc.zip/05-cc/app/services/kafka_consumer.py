"""
Kafka 消费者 - 处理文档解析任务
可独立部署为 Worker 服务
"""
import json
import time
import signal
import sys
import threading
from typing import Callable, Dict, Optional
from datetime import datetime

from app.core.config import settings


class KafkaConsumerService:
    """Kafka 消费者服务"""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._consumer = None
            cls._instance._running = False
            cls._instance._handlers = {}
        return cls._instance

    def _init_consumer(self):
        """初始化 Kafka 消费者"""
        if not settings.KAFKA_ENABLED:
            print("Kafka 未启用")
            return False

        try:
            from kafka import KafkaConsumer
            from kafka.errors import NoBrokersAvailable

            self._consumer = KafkaConsumer(
                settings.KAFKA_PARSE_TOPIC,
                bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
                group_id=settings.KAFKA_CONSUMER_GROUP,
                value_deserializer=lambda m: json.loads(m.decode('utf-8')),
                key_deserializer=lambda m: m.decode('utf-8') if m else None,
                auto_offset_reset='earliest',
                enable_auto_commit=False,  # 手动提交，确保处理成功后再提交
                max_poll_records=settings.KAFKA_MAX_POLL_RECORDS,
                session_timeout_ms=30000,
                heartbeat_interval_ms=10000
            )
            print(f"Kafka 消费者初始化成功: {settings.KAFKA_BOOTSTRAP_SERVERS}, topic={settings.KAFKA_PARSE_TOPIC}")
            return True
        except ImportError:
            print("kafka-python 未安装，请运行: pip install kafka-python")
            return False
        except Exception as e:
            print(f"Kafka 消费者初始化失败: {e}")
            return False

    def register_handler(self, task_type: str, handler: Callable):
        """
        注册任务处理器

        Args:
            task_type: 任务类型
            handler: 处理函数，接收 task dict，返回 bool 表示是否成功
        """
        self._handlers[task_type] = handler
        print(f"注册任务处理器: {task_type}")

    def _handle_parse_task(self, task: Dict) -> bool:
        """
        处理文档解析任务

        Args:
            task: 任务数据

        Returns:
            是否处理成功
        """
        from app.models.database import SessionLocal, Document
        from app.services.rag_service import rag_service

        document_id = task.get("document_id")
        knowledge_base_id = task.get("knowledge_base_id")
        file_path = task.get("file_path")
        title = task.get("title", "")

        db = SessionLocal()
        try:
            # 更新状态为处理中
            doc = db.query(Document).filter(Document.id == document_id).first()
            if not doc:
                print(f"文档不存在: {document_id}")
                return False

            if doc.parse_status == "completed":
                print(f"文档已解析: {document_id}")
                return True

            doc.parse_status = "processing"
            db.commit()

            # 执行解析和索引
            result = rag_service.index_document(
                document_id=document_id,
                knowledge_base_id=knowledge_base_id,
                file_path=file_path,
                title=title
            )

            # 更新状态为完成
            doc = db.query(Document).filter(Document.id == document_id).first()
            doc.parse_status = "completed"
            doc.total_pages = result["total_pages"]
            doc.total_chunks = result["total_chunks"]
            doc.total_images = result["total_images"]
            db.commit()

            print(f"文档解析完成: {document_id}, pages={result['total_pages']}, chunks={result['total_chunks']}, images={result['total_images']}")
            return True

        except Exception as e:
            print(f"文档解析失败: {document_id}, error={e}")
            # 更新状态为失败
            try:
                doc = db.query(Document).filter(Document.id == document_id).first()
                if doc:
                    doc.parse_status = "failed"
                    db.commit()
            except Exception:
                pass
            return False

        finally:
            db.close()

    def _process_message(self, message) -> bool:
        """
        处理单条消息

        Args:
            message: Kafka 消息

        Returns:
            是否处理成功
        """
        try:
            task = message.value
            task_type = task.get("task_type", "unknown")

            print(f"收到任务: {task.get('task_id')}, type={task_type}")

            # 查找处理器
            handler = self._handlers.get(task_type)
            if handler:
                return handler(task)
            elif task_type == "document_parse":
                return self._handle_parse_task(task)
            else:
                print(f"未知任务类型: {task_type}")
                return False

        except Exception as e:
            print(f"处理消息异常: {e}")
            return False

    def start(self, blocking: bool = True):
        """
        启动消费者

        Args:
            blocking: 是否阻塞运行
        """
        if not self._init_consumer():
            print("消费者初始化失败，无法启动")
            return

        self._running = True
        print("Kafka 消费者启动，等待消息...")

        # 注册信号处理
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        # 注册默认处理器
        if "document_parse" not in self._handlers:
            self.register_handler("document_parse", self._handle_parse_task)

        def consume_loop():
            while self._running:
                try:
                    # 批量拉取消息
                    records = self._consumer.poll(timeout_ms=1000)

                    for topic_partition, messages in records.items():
                        for message in messages:
                            if not self._running:
                                break

                            success = self._process_message(message)

                            if success:
                                # 手动提交偏移量
                                self._consumer.commit()

                except Exception as e:
                    print(f"消费异常: {e}")
                    time.sleep(1)

            # 关闭消费者
            if self._consumer:
                self._consumer.close()
                print("Kafka 消费者已关闭")

        if blocking:
            consume_loop()
        else:
            thread = threading.Thread(target=consume_loop, daemon=True)
            thread.start()
            return thread

    def _signal_handler(self, signum, frame):
        """信号处理器"""
        print(f"收到信号 {signum}，正在停止消费者...")
        self._running = False

    def stop(self):
        """停止消费者"""
        self._running = False

    def health_check(self) -> bool:
        """健康检查"""
        if not self._consumer:
            return False
        try:
            return self._consumer.bootstrap_connected()
        except Exception:
            return False


# 全局消费者实例
kafka_consumer = KafkaConsumerService()


def run_worker():
    """运行 Worker 进程入口"""
    print("=" * 50)
    print("多模态 RAG 文档解析 Worker")
    print("=" * 50)

    consumer = KafkaConsumerService()
    consumer.start(blocking=True)


if __name__ == "__main__":
    run_worker()
