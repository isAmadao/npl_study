"""
多模态 RAG 核心服务
"""
import os
import shutil
import datetime
import numpy as np
from typing import List, Dict, Optional, Union
from openai import OpenAI

import torch
from sentence_transformers import SentenceTransformer
from PIL import Image

from app.core.config import settings
from app.services.elasticsearch import es_client
from app.services.mineru_service import mineru_service


class EmbeddingService:
    """嵌入模型服务"""

    _instance = None
    _initialized = False
    _models = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def _ensure_initialized(self):
        """延迟初始化模型"""
        if not EmbeddingService._initialized:
            self._load_models()
            EmbeddingService._initialized = True

    def _load_models(self):
        """加载模型"""
        # 文本嵌入模型
        try:
            if os.path.exists(settings.EMBEDDING_MODEL_PATH):
                self._models["text"] = SentenceTransformer(settings.EMBEDDING_MODEL_PATH)
            else:
                self._models["text"] = SentenceTransformer(settings.EMBEDDING_MODEL)
        except Exception as e:
            print(f"文本嵌入模型加载失败: {e}")

        # CLIP 多模态模型
        if settings.USE_MULTIMODAL:
            try:
                from transformers import CLIPModel, CLIPProcessor
                if os.path.exists(settings.MULTIMODAL_MODEL_PATH):
                    self._models["clip"] = CLIPModel.from_pretrained(settings.MULTIMODAL_MODEL_PATH)
                    self._models["clip_processor"] = CLIPProcessor.from_pretrained(settings.MULTIMODAL_MODEL_PATH)
                else:
                    self._models["clip"] = CLIPModel.from_pretrained(settings.MULTIMODAL_MODEL)
                    self._models["clip_processor"] = CLIPProcessor.from_pretrained(settings.MULTIMODAL_MODEL)
            except Exception as e:
                print(f"CLIP 模型加载失败: {e}")

    def get_text_embedding(self, text: Union[str, List[str]]) -> np.ndarray:
        """获取文本嵌入向量"""
        self._ensure_initialized()
        model = self._models.get("text")
        if model:
            return model.encode(text, normalize_embeddings=True)
        raise RuntimeError("文本嵌入模型未加载")

    def get_image_embedding(self, image_path: str) -> np.ndarray:
        """获取图像嵌入向量 (CLIP)"""
        self._ensure_initialized()
        clip_model = self._models.get("clip")
        processor = self._models.get("clip_processor")

        if not clip_model or not processor:
            raise RuntimeError("CLIP 模型未加载")

        image = Image.open(image_path).convert("RGB")
        inputs = processor(images=image, return_tensors="pt")

        with torch.no_grad():
            features = clip_model.get_image_features(**inputs)
            features = features / features.norm(dim=-1, keepdim=True)

        return features.cpu().numpy().flatten()


class RAGService:
    """RAG 核心服务"""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def _ensure_initialized(self):
        """延迟初始化"""
        if not self._initialized:
            self.embedding_service = EmbeddingService()
            self.llm_client = OpenAI(
                api_key=settings.LLM_API_KEY,
                base_url=settings.LLM_BASE_URL
            )
            self._initialized = True

    def split_text(self, text: str, chunk_size: int = None, overlap: int = None) -> List[str]:
        """文本分块"""
        chunk_size = chunk_size or settings.CHUNK_SIZE
        overlap = overlap or settings.CHUNK_OVERLAP

        chunks = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            chunk = text[start:end]
            if chunk.strip():
                chunks.append(chunk)
            start = start + chunk_size - overlap
        return chunks

    def parse_pdf(self, file_path: str, use_mineru: bool = True) -> Dict:
        """
        解析 PDF 文档

        Args:
            file_path: PDF 文件路径
            use_mineru: 是否使用 MinerU 解析，False 则使用 pdfplumber

        Returns:
            解析结果，包含 pages, tables, images, markdown_content, total_pages
        """
        if use_mineru and settings.USE_MINERU:
            try:
                return mineru_service.parse_pdf(file_path)
            except Exception as e:
                print(f"MinerU 解析失败，降级到 pdfplumber: {e}")

        # 降级方案：使用 pdfplumber
        return self._parse_pdf_plumber(file_path)

    def _parse_pdf_plumber(self, file_path: str) -> Dict:
        """使用 pdfplumber 解析 PDF（降级方案）"""
        import pdfplumber

        result = {
            "pages": [],
            "tables": [],
            "images": [],
            "markdown_content": "",
            "total_pages": 0
        }

        try:
            pdf = pdfplumber.open(file_path)
            result["total_pages"] = len(pdf.pages)

            for page_num, page in enumerate(pdf.pages):
                text = page.extract_text() or ""
                page_data = {
                    "page_number": page_num,
                    "text": text,
                    "tables": [],
                    "images": []
                }

                tables = page.extract_tables() or []
                for table in tables:
                    if table:
                        page_data["tables"].append(table)
                        result["tables"].append({"page": page_num, "data": table})

                result["pages"].append(page_data)
                result["markdown_content"] += f"\n## 第 {page_num + 1} 页\n\n{text}\n"

        except Exception as e:
            print(f"PDF 解析失败: {e}")

        return result

    def index_document(self, document_id: int, knowledge_base_id: int,
                       file_path: str, title: str) -> Dict:
        """
        索引文档到 ES

        包括：
        - 文本分块索引
        - 表格索引
        - 图像索引（提取 + 描述 + 向量化）
        """
        self._ensure_initialized()

        # 使用 MinerU 解析 PDF
        parse_result = self.parse_pdf(file_path, use_mineru=True)
        total_chunks = 0
        total_images = 0

        # 确保图像存储目录存在
        os.makedirs(settings.IMAGE_DIR, exist_ok=True)

        # 1. 索引文本分块
        for page_data in parse_result["pages"]:
            page_num = page_data["page_number"]
            text = page_data.get("text", "")

            if text.strip():
                # 索引整页文本
                embedding = self.embedding_service.get_text_embedding(text)
                chunk_data = {
                    "document_id": document_id,
                    "knowledge_base_id": knowledge_base_id,
                    "page_number": page_num,
                    "chunk_index": 0,
                    "content": text,
                    "content_type": "page",
                    "text_embedding": embedding.tolist(),
                    "multimodal_embedding": embedding.tolist()
                }
                es_client.index_chunk(chunk_data)
                total_chunks += 1

            # 分块索引
            chunks = self.split_text(text)
            if chunks:
                chunk_embeddings = self.embedding_service.get_text_embedding(chunks)
                for idx, chunk in enumerate(chunks):
                    if chunk.strip():
                        chunk_data = {
                            "document_id": document_id,
                            "knowledge_base_id": knowledge_base_id,
                            "page_number": page_num,
                            "chunk_index": idx + 1,
                            "content": chunk,
                            "content_type": "text",
                            "text_embedding": chunk_embeddings[idx].tolist(),
                            "multimodal_embedding": chunk_embeddings[idx].tolist()
                        }
                        es_client.index_chunk(chunk_data)
                        total_chunks += 1

        # 2. 索引表格
        for table_info in parse_result.get("tables", []):
            table_content = self._table_to_text(table_info)
            if table_content.strip():
                embedding = self.embedding_service.get_text_embedding(table_content)
                chunk_data = {
                    "document_id": document_id,
                    "knowledge_base_id": knowledge_base_id,
                    "page_number": table_info.get("page", 0),
                    "chunk_index": total_chunks,
                    "content": table_content,
                    "content_type": "table",
                    "text_embedding": embedding.tolist(),
                    "multimodal_embedding": embedding.tolist()
                }
                es_client.index_chunk(chunk_data)
                total_chunks += 1

        # 3. 索引图像
        for image_info in parse_result.get("images", []):
            image_path = image_info.get("image_path", "")
            if not image_path or not os.path.exists(image_path):
                continue

            try:
                # 复制图像到统一存储目录
                image_name = f"doc_{document_id}_img_{total_images}{os.path.splitext(image_path)[1]}"
                dest_path = os.path.join(settings.IMAGE_DIR, image_name)
                shutil.copy(image_path, dest_path)

                # 生成图像描述
                description = image_info.get("caption", "")
                if not description:
                    description = self.describe_image(dest_path)

                # 获取图像嵌入
                image_embedding = self.embedding_service.get_image_embedding(dest_path)

                # 索引到 ES
                image_data = {
                    "document_id": document_id,
                    "knowledge_base_id": knowledge_base_id,
                    "page_number": image_info.get("page", 0),
                    "image_path": dest_path,
                    "image_type": image_info.get("image_type", "figure"),
                    "description": description,
                    "image_embedding": image_embedding.tolist()
                }
                es_client.index_image(image_data)
                total_images += 1

            except Exception as e:
                print(f"图像索引失败 {image_path}: {e}")

        return {
            "total_pages": parse_result["total_pages"],
            "total_chunks": total_chunks,
            "total_images": total_images
        }

    def _table_to_text(self, table_info: Dict) -> str:
        """将表格转换为文本格式"""
        if "html" in table_info:
            # MinerU 输出的 HTML 表格
            return f"表格: {table_info.get('caption', '')}\n{table_info['html']}"
        elif "data" in table_info:
            # pdfplumber 输出的二维数组
            rows = table_info["data"]
            text_lines = []
            for row in rows:
                if row:
                    text_lines.append(" | ".join(str(cell) if cell else "" for cell in row))
            return f"表格:\n" + "\n".join(text_lines)
        return ""

    def search(self, query: str, knowledge_base_id: int,
               top_k: int = 10, search_type: str = "all") -> List[Dict]:
        """
        跨模态检索

        Args:
            query: 查询文本
            knowledge_base_id: 知识库 ID
            top_k: 返回结果数量
            search_type: 检索类型 - "text"(仅文本), "image"(仅图像), "all"(全部)

        Returns:
            检索结果列表
        """
        self._ensure_initialized()
        results = []
        query_embedding = self.embedding_service.get_text_embedding(query)

        # 文本检索
        if search_type in ["text", "all"]:
            text_results = self._search_text(query, query_embedding, knowledge_base_id)
            results.extend(text_results)

        # 图像检索
        if search_type in ["image", "all"]:
            image_results = self._search_images(query_embedding, knowledge_base_id)
            results.extend(image_results)

        # 按分数排序并截取 top_k
        results.sort(key=lambda x: x.get("score", 0), reverse=True)
        return results[:top_k]

    def _search_text(self, query: str, query_embedding: np.ndarray,
                     knowledge_base_id: int) -> List[Dict]:
        """文本检索（BM25 + 向量 + RRF 融合）"""
        results = []

        # BM25 文本检索
        bm25_query = {
            "query": {
                "bool": {
                    "must": [{"match": {"content": query}}],
                    "filter": [{"term": {"knowledge_base_id": knowledge_base_id}}]
                }
            },
            "size": 50
        }
        bm25_results = es_client.search_chunks(bm25_query)

        # 向量检索
        vector_query = {
            "knn": {
                "field": "text_embedding",
                "query_vector": query_embedding.tolist(),
                "k": 50,
                "num_candidates": 100
            }
        }
        vector_results = es_client.search_chunks(vector_query)

        # RRF 融合
        k = 60
        fusion_scores = {}
        id_to_record = {}

        for idx, hit in enumerate(bm25_results.get("hits", {}).get("hits", [])):
            doc_id = hit["_id"]
            fusion_scores[doc_id] = fusion_scores.get(doc_id, 0) + 1 / (idx + k)
            id_to_record[doc_id] = {
                "chunk_id": doc_id,
                "document_id": hit["_source"].get("document_id"),
                "page_number": hit["_source"].get("page_number"),
                "content": hit["_source"].get("content"),
                "content_type": hit["_source"].get("content_type"),
                "score": hit["_score"]
            }

        for idx, hit in enumerate(vector_results.get("hits", {}).get("hits", [])):
            doc_id = hit["_id"]
            fusion_scores[doc_id] = fusion_scores.get(doc_id, 0) + 1 / (idx + k)
            if doc_id not in id_to_record:
                id_to_record[doc_id] = {
                    "chunk_id": doc_id,
                    "document_id": hit["_source"].get("document_id"),
                    "page_number": hit["_source"].get("page_number"),
                    "content": hit["_source"].get("content"),
                    "content_type": hit["_source"].get("content_type"),
                    "score": hit["_score"]
                }

        sorted_ids = sorted(fusion_scores.items(), key=lambda x: x[1], reverse=True)
        for doc_id, score in sorted_ids[:30]:
            record = id_to_record[doc_id]
            record["score"] = score
            results.append(record)

        return results

    def _search_images(self, query_embedding: np.ndarray,
                       knowledge_base_id: int) -> List[Dict]:
        """图像向量检索"""
        results = []

        try:
            # 使用 CLIP 向量检索图像
            image_query = {
                "knn": {
                    "field": "image_embedding",
                    "query_vector": query_embedding.tolist(),
                    "k": 20,
                    "num_candidates": 50
                },
                "query": {
                    "term": {"knowledge_base_id": knowledge_base_id}
                }
            }
            image_results = es_client.search_images(image_query)

            for hit in image_results.get("hits", {}).get("hits", []):
                source = hit["_source"]
                results.append({
                    "chunk_id": hit["_id"],
                    "document_id": source.get("document_id"),
                    "page_number": source.get("page_number"),
                    "content": source.get("description", ""),
                    "content_type": "image",
                    "image_path": source.get("image_path"),
                    "image_description": source.get("description"),
                    "image_type": source.get("image_type"),
                    "score": hit["_score"]
                })
        except Exception as e:
            print(f"图像检索失败: {e}")

        return results

    def chat(self, knowledge_base_id: int, messages: List[Dict],
             include_images: bool = False) -> Dict:
        """
        RAG 对话（支持图文混排）

        Args:
            knowledge_base_id: 知识库 ID
            messages: 对话历史
            include_images: 是否在上下文中包含图像信息

        Returns:
            包含 messages, sources, related_images 的字典
        """
        self._ensure_initialized()

        sources = []
        related_images = []

        if len(messages) == 1:
            query = messages[0]["content"]

            # 跨模态检索
            search_results = self.search(
                query, knowledge_base_id,
                top_k=settings.CHUNK_CANDIDATE,
                search_type="all" if include_images else "text"
            )

            # 构建上下文
            text_contexts = []
            for r in search_results:
                sources.append(r)
                if r.get("content_type") == "image":
                    related_images.append({
                        "image_path": r.get("image_path"),
                        "description": r.get("content", ""),
                        "image_type": r.get("image_type")
                    })
                    # 图像描述也加入上下文
                    if r.get("content"):
                        text_contexts.append(f"[图像] {r.get('content')}")
                else:
                    text_contexts.append(r.get("content", ""))

            context = "\n\n".join(text_contexts)

            prompt = f"""当前时间: {datetime.datetime.now()}
你是一个专业的文档分析助手。请根据以下资料回答问题。
如果资料中包含图像描述，请结合图像信息进行分析。

资料:
{context}

问题: {query}"""

            response = self.llm_client.chat.completions.create(
                model=settings.LLM_MODEL,
                messages=[{"role": "user", "content": prompt}],
                top_p=0.7,
                temperature=0.9
            )
            assistant_msg = response.choices[0].message.content
            messages.append({"role": "assistant", "content": assistant_msg})
        else:
            response = self.llm_client.chat.completions.create(
                model=settings.LLM_MODEL,
                messages=messages,
                top_p=0.7,
                temperature=0.9
            )
            messages.append({"role": "assistant", "content": response.choices[0].message.content})

        return {"messages": messages, "sources": sources, "related_images": related_images}

    def describe_image(self, image_path: str) -> str:
        """描述图像"""
        self._ensure_initialized()
        try:
            prompt = f"请描述这张图像的内容: {image_path}"
            response = self.llm_client.chat.completions.create(
                model=settings.LLM_MODEL,
                messages=[{"role": "user", "content": prompt}]
            )
            return response.choices[0].message.content
        except Exception as e:
            return f"图像描述失败: {str(e)}"


# 全局服务实例
rag_service = RAGService()
embedding_service = EmbeddingService()