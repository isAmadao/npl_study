"""
Elasticsearch 客户端
"""
from elasticsearch import Elasticsearch
from app.core.config import settings


class ESClient:
    """Elasticsearch 客户端封装"""

    def __init__(self):
        self.client = None

    def _ensure_client(self):
        """延迟初始化客户端"""
        if self.client is None:
            self.client = self._create_client()
            self._init_indices()

    def _create_client(self) -> Elasticsearch:
        """创建 ES 客户端"""
        if settings.ES_USERNAME and settings.ES_PASSWORD:
            return Elasticsearch(
                [{"host": settings.ES_HOST, "port": settings.ES_PORT, "scheme": settings.ES_SCHEME}],
                basic_auth=(settings.ES_USERNAME, settings.ES_PASSWORD)
            )
        return Elasticsearch(
            [{"host": settings.ES_HOST, "port": settings.ES_PORT, "scheme": settings.ES_SCHEME}]
        )

    def _init_indices(self):
        """初始化索引"""
        # 文档分块索引
        chunk_mapping = {
            "mappings": {
                "properties": {
                    "document_id": {"type": "integer"},
                    "knowledge_base_id": {"type": "integer"},
                    "page_number": {"type": "integer"},
                    "chunk_index": {"type": "integer"},
                    "content": {
                        "type": "text",
                        "analyzer": "ik_max_word",
                        "search_analyzer": "ik_max_word"
                    },
                    "content_type": {"type": "keyword"},
                    "text_embedding": {
                        "type": "dense_vector",
                        "dims": settings.EMBEDDING_DIMS,
                        "index": True,
                        "similarity": "cosine"
                    },
                    "multimodal_embedding": {
                        "type": "dense_vector",
                        "dims": settings.MULTIMODAL_DIMS,
                        "index": True,
                        "similarity": "cosine"
                    }
                }
            }
        }

        if not self.client.indices.exists(index="chunks"):
            self.client.indices.create(index="chunks", body=chunk_mapping)

        # 图像索引
        image_mapping = {
            "mappings": {
                "properties": {
                    "document_id": {"type": "integer"},
                    "knowledge_base_id": {"type": "integer"},
                    "page_number": {"type": "integer"},
                    "image_path": {"type": "text"},
                    "image_type": {"type": "keyword"},
                    "description": {"type": "text", "analyzer": "ik_max_word"},
                    "image_embedding": {
                        "type": "dense_vector",
                        "dims": settings.MULTIMODAL_DIMS,
                        "index": True,
                        "similarity": "cosine"
                    }
                }
            }
        }

        if not self.client.indices.exists(index="images"):
            self.client.indices.create(index="images", body=image_mapping)

    def index_chunk(self, chunk_data: dict):
        """索引文档分块"""
        self._ensure_client()
        return self.client.index(index="chunks", document=chunk_data)

    def index_image(self, image_data: dict):
        """索引图像"""
        self._ensure_client()
        return self.client.index(index="images", document=image_data)

    def search_chunks(self, query: dict):
        """搜索文档分块"""
        self._ensure_client()
        return self.client.search(index="chunks", body=query)

    def search_images(self, query: dict):
        """搜索图像"""
        self._ensure_client()
        return self.client.search(index="images", body=query)

    def delete_by_document(self, document_id: int):
        """删除文档相关数据"""
        self._ensure_client()
        self.client.delete_by_query(
            index="chunks",
            body={"query": {"term": {"document_id": document_id}}}
        )
        self.client.delete_by_query(
            index="images",
            body={"query": {"term": {"document_id": document_id}}}
        )

    def health_check(self) -> bool:
        """健康检查"""
        try:
            self._ensure_client()
            return self.client.ping()
        except Exception:
            return False


# 全局 ES 客户端（懒加载）
es_client = ESClient()