"""
Kafka 生产者 - 发送文档解析任务
"""
import json
import time
from typing import Dict, Optional
from datetime import datetime

from app.core.config import settings


class KafkaProducerService:
    """Kafka 生产者服务"""

    _instance = None
    _producer = None
    _initialized = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def _ensure_initialized(self):
        """延迟初始化"""
        if not self._initialized:
            self._init_producer()
            self._initialized = True

    def _init_producer(self):
        """初始化 Kafka 生产者"""
        if not settings.KAFKA_ENABLED:
            print("Kafka 未启用，使用本地处理模式")
            return

        try:
            from kafka import KafkaProducer

            self._producer = KafkaProducer(
                bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
                value_serializer=lambda v: json.dumps(v, ensure_ascii=False).encode('utf-8'),
                key_serializer=lambda k: str(k).encode('utf-8') if k else None,
                acks='all',  # 等待所有副本确认
                retries=3,
                max_in_flight_requests_per_connection=1
            )
            print(f"Kafka 生产者初始化成功: {settings.KAFKA_BOOTSTRAP_SERVERS}")
        except ImportError:
            print("kafka-python 未安装，请运行: pip install kafka-python")
            self._producer = None
        except Exception as e:
            print(f"Kafka 生产者初始化失败: {e}")
            self._producer = None

    def send_parse_task(
        self,
        document_id: int,
        knowledge_base_id: int,
        file_path: str,
        title: str,
        priority: int = 0
    ) -> bool:
        """
        发送文档解析任务到 Kafka

        Args:
            document_id: 文档 ID
            knowledge_base_id: 知识库 ID
            file_path: 文件路径
            title: 文档标题
            priority: 优先级（0-9，数字越大优先级越高）

        Returns:
            是否发送成功
        """
        self._ensure_initialized()

        if not self._producer:
            return False

        task = {
            "task_id": f"parse_{document_id}_{int(time.time() * 1000)}",
            "task_type": "document_parse",
            "document_id": document_id,
            "knowledge_base_id": knowledge_base_id,
            "file_path": file_path,
            "title": title,
            "priority": priority,
            "created_at": datetime.now().isoformat(),
            "retry_count": 0
        }

        try:
            future = self._producer.send(
                settings.KAFKA_PARSE_TOPIC,
                key=str(document_id),
                value=task
            )
            # 等待发送确认
            result = future.get(timeout=10)
            print(f"解析任务已发送: document_id={document_id}, partition={result.partition}, offset={result.offset}")
            return True
        except Exception as e:
            print(f"发送解析任务失败: {e}")
            return False

    def send_batch_parse_tasks(self, tasks: list) -> Dict:
        """
        批量发送解析任务

        Args:
            tasks: 任务列表，每个任务包含 document_id, knowledge_base_id, file_path, title

        Returns:
            发送结果统计
        """
        self._ensure_initialized()

        results = {"success": 0, "failed": 0, "total": len(tasks)}

        if not self._producer:
            results["failed"] = len(tasks)
            return results

        for task in tasks:
            success = self.send_parse_task(
                document_id=task["document_id"],
                knowledge_base_id=task["knowledge_base_id"],
                file_path=task["file_path"],
                title=task.get("title", "")
            )
            if success:
                results["success"] += 1
            else:
                results["failed"] += 1

        return results

    def health_check(self) -> bool:
        """健康检查"""
        if not self._producer:
            return False
        try:
            # 获取集群元数据
            self._producer.bootstrap_connected()
            return True
        except Exception:
            return False

    def close(self):
        """关闭生产者"""
        if self._producer:
            self._producer.flush()
            self._producer.close()
            self._producer = None
            self._initialized = False


# 全局生产者实例
kafka_producer = KafkaProducerService()
