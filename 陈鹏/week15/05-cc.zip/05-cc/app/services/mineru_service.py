"""
MinerU PDF 解析服务
支持文本、图像、表格提取
"""
import os
import json
import subprocess
import shutil
from typing import Dict, List, Optional
from pathlib import Path

from app.core.config import settings


class MinerUService:
    """MinerU PDF 解析服务"""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def _ensure_initialized(self):
        """延迟初始化"""
        if not self._initialized:
            self._check_mineru_installed()
            self._initialized = True

    def _check_mineru_installed(self) -> bool:
        """检查 MinerU 是否安装"""
        try:
            result = subprocess.run(
                ["mineru", "--version"],
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0
        except Exception:
            return False

    def parse_pdf(
        self,
        file_path: str,
        output_dir: Optional[str] = None,
        extract_images: bool = True
    ) -> Dict:
        """
        使用 MinerU 解析 PDF 文档

        Args:
            file_path: PDF 文件路径
            output_dir: 输出目录，默认为 data/mineru_output/{filename}
            extract_images: 是否提取图像

        Returns:
            解析结果，包含 pages, tables, images, markdown_content
        """
        self._ensure_initialized()

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"PDF 文件不存在: {file_path}")

        # 准备输出目录
        filename = os.path.splitext(os.path.basename(file_path))[0]
        if output_dir is None:
            output_dir = os.path.join(settings.UPLOAD_DIR, "mineru_output", filename)
        os.makedirs(output_dir, exist_ok=True)

        # 构建 MinerU 命令
        cmd = [
            "mineru",
            "-p", file_path,
            "-o", output_dir
        ]

        try:
            # 执行解析
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=600  # 10分钟超时
            )

            if result.returncode != 0:
                print(f"MinerU 解析失败: {result.stderr}")
                return self._fallback_parse(file_path, output_dir)

            # 解析输出结果
            return self._parse_mineru_output(output_dir, filename)

        except subprocess.TimeoutExpired:
            print("MinerU 解析超时")
            return self._fallback_parse(file_path, output_dir)
        except Exception as e:
            print(f"MinerU 解析异常: {e}")
            return self._fallback_parse(file_path, output_dir)

    def _parse_mineru_output(self, output_dir: str, filename: str) -> Dict:
        """
        解析 MinerU 输出结果

        MinerU 输出结构:
        output_dir/
            {filename}/
                {filename}.md      # Markdown 内容
                {filename}_content_list.json  # 结构化内容
                images/            # 提取的图像
        """
        result = {
            "pages": [],
            "tables": [],
            "images": [],
            "markdown_content": "",
            "total_pages": 0
        }

        # 查找输出目录
        pdf_output_dir = os.path.join(output_dir, filename)
        if not os.path.exists(pdf_output_dir):
            # 尝试查找实际输出目录
            for item in os.listdir(output_dir):
                item_path = os.path.join(output_dir, item)
                if os.path.isdir(item_path):
                    pdf_output_dir = item_path
                    break

        # 读取 Markdown 内容
        md_file = os.path.join(pdf_output_dir, f"{filename}.md")
        if os.path.exists(md_file):
            with open(md_file, "r", encoding="utf-8") as f:
                result["markdown_content"] = f.read()

        # 读取结构化内容 JSON
        content_list_file = os.path.join(pdf_output_dir, f"{filename}_content_list.json")
        if os.path.exists(content_list_file):
            with open(content_list_file, "r", encoding="utf-8") as f:
                content_list = json.load(f)
                result = self._process_content_list(content_list, result)

        # 收集提取的图像
        images_dir = os.path.join(pdf_output_dir, "images")
        if os.path.exists(images_dir):
            for img_name in os.listdir(images_dir):
                img_path = os.path.join(images_dir, img_name)
                if os.path.isfile(img_path):
                    result["images"].append({
                        "image_path": img_path,
                        "image_name": img_name,
                        "image_type": self._get_image_type(img_name)
                    })

        return result

    def _process_content_list(self, content_list: List[Dict], result: Dict) -> Dict:
        """
        处理 MinerU 输出的 content_list.json

        内容类型包括:
        - text: 文本块
        - title: 标题
        - table: 表格 (HTML 格式)
        - image: 图像
        - equation: 公式
        """
        current_page = {"page_number": 0, "text": "", "tables": [], "images": []}
        page_number = 0

        for item in content_list:
            item_type = item.get("type", "")
            content = item.get("content", "")

            if item_type == "text":
                current_page["text"] += content + "\n"

            elif item_type == "title":
                level = item.get("level", 1)
                prefix = "#" * level
                current_page["text"] += f"\n{prefix} {content}\n"

            elif item_type == "table":
                # 表格以 HTML 格式存储
                table_html = item.get("html", content)
                result["tables"].append({
                    "page": page_number,
                    "html": table_html,
                    "caption": item.get("caption", "")
                })
                current_page["tables"].append(table_html)

            elif item_type == "image":
                img_path = item.get("img_path", "")
                if img_path:
                    result["images"].append({
                        "image_path": img_path,
                        "image_type": "figure",
                        "caption": item.get("caption", ""),
                        "page": page_number
                    })
                    current_page["images"].append(img_path)

            elif item_type == "equation":
                # 公式以 LaTeX 格式存储
                latex = item.get("latex", content)
                current_page["text"] += f"\n$$\n{latex}\n$$\n"

            # 检测分页（MinerU 可能不显式标记分页）
            if item.get("page"):
                if item["page"] != page_number:
                    if current_page["text"].strip():
                        result["pages"].append(current_page)
                    page_number = item["page"]
                    current_page = {
                        "page_number": page_number,
                        "text": "",
                        "tables": [],
                        "images": []
                    }

        # 添加最后一页
        if current_page["text"].strip():
            result["pages"].append(current_page)

        result["total_pages"] = len(result["pages"])
        return result

    def _get_image_type(self, filename: str) -> str:
        """根据文件名推断图像类型"""
        filename_lower = filename.lower()
        if "chart" in filename_lower or "fig" in filename_lower:
            return "chart"
        elif "table" in filename_lower:
            return "table_image"
        elif "diagram" in filename_lower:
            return "diagram"
        else:
            return "figure"

    def _fallback_parse(self, file_path: str, output_dir: str) -> Dict:
        """
        降级解析方案：使用 pdfplumber
        """
        import pdfplumber

        result = {
            "pages": [],
            "tables": [],
            "images": [],
            "markdown_content": "",
            "total_pages": 0
        }

        try:
            pdf = pdfplumber.open(file_path)
            result["total_pages"] = len(pdf.pages)

            for page_num, page in enumerate(pdf.pages):
                text = page.extract_text() or ""
                page_data = {
                    "page_number": page_num,
                    "text": text,
                    "tables": [],
                    "images": []
                }

                tables = page.extract_tables() or []
                for table in tables:
                    if table:
                        page_data["tables"].append(table)
                        result["tables"].append({"page": page_num, "data": table})

                result["pages"].append(page_data)
                result["markdown_content"] += f"\n## 第 {page_num + 1} 页\n\n{text}\n"

        except Exception as e:
            print(f"pdfplumber 解析失败: {e}")

        return result

    def parse_pdf_via_api(
        self,
        file_path: str,
        api_url: str = "http://localhost:8000"
    ) -> Dict:
        """
        通过 MinerU API 服务解析 PDF

        适用于已部署 mineru-api 的场景

        Args:
            file_path: PDF 文件路径
            api_url: MinerU API 地址

        Returns:
            解析结果
        """
        import requests

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"PDF 文件不存在: {file_path}")

        try:
            with open(file_path, "rb") as f:
                files = {"file": (os.path.basename(file_path), f, "application/pdf")}
                response = requests.post(
                    f"{api_url}/parse",
                    files=files,
                    timeout=600
                )

            if response.status_code == 200:
                return response.json()
            else:
                raise Exception(f"API 调用失败: {response.status_code}")

        except Exception as e:
            print(f"MinerU API 解析失败: {e}")
            return self._fallback_parse(file_path, "")


# 全局服务实例
mineru_service = MinerUService()
