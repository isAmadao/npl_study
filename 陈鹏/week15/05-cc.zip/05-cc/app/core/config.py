"""
系统配置
"""
import os
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """系统配置"""
    # 服务配置
    APP_NAME: str = "Multimodal RAG System"
    APP_VERSION: str = "1.0.0"
    API_PREFIX: str = "/api/v1"
    PORT: int = 6020

    # 数据库配置
    DB_ENGINE: str = "sqlite"
    DB_PATH: str = "data/multimodal_rag.db"

    # Elasticsearch 配置
    ES_HOST: str = "localhost"
    ES_PORT: int = 9200
    ES_SCHEME: str = "http"
    ES_USERNAME: str = ""
    ES_PASSWORD: str = ""

    # LLM 配置 (通义千问)
    LLM_BASE_URL: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    LLM_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    LLM_MODEL: str = "qwen-flash"

    # 嵌入模型配置
    EMBEDDING_MODEL: str = "bge-small-zh-v1.5"
    EMBEDDING_MODEL_PATH: str = "/root/hf-models/bge-small-zh-v1.5/"
    EMBEDDING_DIMS: int = 512

    # 多模态模型配置 (CLIP)
    MULTIMODAL_MODEL: str = "clip-vit-base-patch32"
    MULTIMODAL_MODEL_PATH: str = "/root/hf-models/clip-vit-base-patch32/"
    MULTIMODAL_DIMS: int = 512
    USE_MULTIMODAL: bool = True

    # RAG 配置
    CHUNK_SIZE: int = 256
    CHUNK_OVERLAP: int = 20
    CHUNK_CANDIDATE: int = 10

    # 文件存储配置
    UPLOAD_DIR: str = "data/uploads"
    IMAGE_DIR: str = "data/images"

    # MinerU 配置
    USE_MINERU: bool = True
    MINERU_API_URL: str = "http://localhost:8000"  # MinerU API 服务地址（可选）
    MINERU_TIMEOUT: int = 600  # 解析超时时间（秒）

    # Kafka 配置
    KAFKA_ENABLED: bool = False  # 是否启用 Kafka 分布式处理
    KAFKA_BOOTSTRAP_SERVERS: str = "localhost:9092"  # Kafka 集群地址
    KAFKA_PARSE_TOPIC: str = "document-parse"  # 文档解析任务 Topic
    KAFKA_RESULT_TOPIC: str = "parse-result"  # 解析结果 Topic
    KAFKA_CONSUMER_GROUP: str = "multimodal-rag-worker"  # 消费者组
    KAFKA_MAX_POLL_RECORDS: int = 10  # 单次拉取最大消息数

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()