# core 包初始化
from app.core.config import settings