"""
Pydantic 数据模型定义 - API 请求/响应
"""
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime


# ==================== 通用响应 ====================

class BaseResponse(BaseModel):
    request_id: str = Field(default_factory=lambda: "", description="请求ID")
    response_code: int = Field(default=200, description="响应代码")
    response_msg: str = Field(default="success", description="响应信息")
    processing_time: float = Field(default=0.0, description="处理耗时(秒)")


# ==================== 知识库 ====================

class KnowledgeBaseCreate(BaseModel):
    title: str = Field(..., description="知识库名称")
    category: str = Field(default="", description="分类")
    description: str = Field(default="", description="描述")


class KnowledgeBaseUpdate(BaseModel):
    title: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None


class KnowledgeBaseInfo(BaseModel):
    id: int
    title: str
    category: str
    description: str
    document_count: int = 0
    created_at: datetime
    updated_at: datetime


class KnowledgeBaseListResponse(BaseResponse):
    data: List[KnowledgeBaseInfo]
    total: int


class KnowledgeBaseResponse(BaseResponse):
    data: Optional[KnowledgeBaseInfo]


# ==================== 文档 ====================

class DocumentCreate(BaseModel):
    knowledge_base_id: int
    title: str
    category: str = Field(default="")


class DocumentInfo(BaseModel):
    id: int
    title: str
    category: str
    knowledge_base_id: int
    file_type: str
    file_size: int
    file_path: str
    parse_status: str
    total_pages: int
    total_chunks: int
    total_images: int
    created_at: datetime


class DocumentListResponse(BaseResponse):
    data: List[DocumentInfo]
    total: int


class DocumentResponse(BaseResponse):
    data: Optional[DocumentInfo]


class ParseStatusResponse(BaseResponse):
    document_id: int
    status: str
    parsed_pages: int
    total_pages: int
    extracted_images: int
    progress: float = Field(default=0.0, description="解析进度 0-100")


# ==================== 嵌入 ====================

class EmbeddingRequest(BaseModel):
    text: str | List[str]
    model: str = Field(default="bge-small-zh-v1.5")


class EmbeddingResponse(BaseResponse):
    vectors: List[List[float]]
    dims: int
    model: str


class MultimodalEmbeddingRequest(BaseModel):
    text: Optional[str] = None
    image_path: Optional[str] = None
    model: str = Field(default="clip-vit-base-patch32")


class MultimodalEmbeddingResponse(BaseResponse):
    text_vector: Optional[List[float]]
    image_vector: Optional[List[float]]
    dims: int


# ==================== 检索 ====================

class SearchRequest(BaseModel):
    knowledge_base_id: int
    query: str
    top_k: int = Field(default=10, ge=1, le=100)
    search_type: str = Field(default="all")
    use_rerank: bool = Field(default=False)


class SearchResult(BaseModel):
    chunk_id: str
    document_id: int
    page_number: int
    content: str
    score: float
    content_type: str
    image_path: Optional[str] = None
    image_description: Optional[str] = None
    document_title: Optional[str] = None


class SearchResponse(BaseResponse):
    results: List[SearchResult]
    total: int


# ==================== 图像理解 ====================

class ImageUnderstandingRequest(BaseModel):
    image_path: str
    task: str = Field(default="describe")


class ImageUnderstandingResponse(BaseResponse):
    description: str
    structured_data: Optional[Dict[str, Any]] = None
    image_type: Optional[str] = None


# ==================== RAG 对话 ====================

class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    knowledge_base_id: int
    messages: List[ChatMessage]
    include_images: bool = Field(default=False)
    top_k: int = Field(default=5)


class ChatResponse(BaseResponse):
    messages: List[ChatMessage]
    related_images: List[str] = Field(default_factory=list)
    sources: List[SearchResult] = Field(default_factory=list)


# ==================== 重排序 ====================

class RerankRequest(BaseModel):
    query: str
    documents: List[str]
    model: str = Field(default="bge-reranker-base")


class RerankResponse(BaseResponse):
    scores: List[float]
    ranked_indices: List[int]


# ==================== 文件上传 ====================

class UploadResponse(BaseResponse):
    document_id: int
    file_name: str
    file_size: int
    file_type: str