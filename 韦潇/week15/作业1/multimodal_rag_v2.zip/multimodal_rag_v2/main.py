from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import upload_router, document_router, chat_router, admin_router
from app.core.config import config

app = FastAPI(
    title=config.app.name,
    version=config.app.version,
    debug=config.app.debug
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(upload_router)
app.include_router(document_router)
app.include_router(chat_router)
app.include_router(admin_router)


@app.get("/")
async def root():
    return {
        "message": "多模态RAG聊天机器人 API",
        "version": config.app.version,
        "docs": "/docs"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=config.app.host,
        port=config.app.port,
        reload=config.app.debug
    )
