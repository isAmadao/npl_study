import streamlit as st
import requests
import json
from datetime import datetime

st.set_page_config(
    page_title="多模态RAG聊天机器人",
    page_icon="🤖",
    layout="wide"
)


API_BASE_URL = "http://localhost:8000"


def check_api_health():
    try:
        response = requests.get(f"{API_BASE_URL}/health", timeout=2)
        return response.status_code == 200
    except:
        return False


def upload_document(file):
    try:
        files = {"file": (file.name, file.getvalue(), "application/pdf")}
        response = requests.post(f"{API_BASE_URL}/upload/document", files=files, timeout=30)
        return response.json()
    except Exception as e:
        return {"success": False, "message": str(e)}


def get_documents(status=None, page=1, page_size=10):
    try:
        params = {"page": page, "page_size": page_size}
        if status:
            params["status"] = status
        response = requests.get(f"{API_BASE_URL}/documents", params=params, timeout=5)
        return response.json()
    except Exception as e:
        return {"success": False, "message": str(e)}


def delete_document(file_id):
    try:
        response = requests.delete(f"{API_BASE_URL}/documents/{file_id}", timeout=5)
        return response.json()
    except Exception as e:
        return {"success": False, "message": str(e)}


def chat(question, top_k=5):
    try:
        response = requests.post(
            f"{API_BASE_URL}/chat",
            json={"question": question, "top_k": top_k},
            timeout=60
        )
        return response.json()
    except Exception as e:
        return {"success": False, "error_code": "ERR_QA_FAILED", "message": str(e)}


def render_markdown_with_images(markdown_text):
    import re
    pattern = re.compile(r'!\[.*?\]\((.*?)\)')

    last_pos = 0
    for match in pattern.finditer(markdown_text):
        st.markdown(markdown_text[last_pos:match.start()], unsafe_allow_html=True)

        img_url = match.group(1)
        try:
            st.image(img_url, width=400)
        except:
            st.warning(f"无法加载图片: {img_url}")

        last_pos = match.end()

    st.markdown(markdown_text[last_pos:], unsafe_allow_html=True)


def main():
    st.title("🤖 多模态RAG聊天机器人")

    api_healthy = check_api_health()
    if not api_healthy:
        st.error("⚠️ 无法连接到后端API服务，请确保FastAPI服务正在运行（python main.py）")
        st.info("启动命令：uvicorn main:app --reload --port 8000")
        return

    st.success("✅ 已连接到后端API服务")

    page = st.sidebar.selectbox(
        "选择功能",
        ["📤 文档上传", "📚 文档管理", "💬 智能问答"]
    )

    if page == "📤 文档上传":
        st.header("文档上传")
        st.markdown("上传PDF文档，系统将自动解析并建立多模态知识库")

        uploaded_file = st.file_uploader(
            "选择PDF文件",
            type=["pdf"],
            help="支持PDF格式文档"
        )

        if uploaded_file is not None:
            col1, col2 = st.columns([1, 2])
            with col1:
                st.info(f"已选择: **{uploaded_file.name}**")
                st.info(f"文件大小: {len(uploaded_file.getvalue()) / 1024 / 1024:.2f} MB")

            with col2:
                if st.button("🚀 开始上传", type="primary"):
                    with st.spinner("上传中..."):
                        result = upload_document(uploaded_file)

                        if result.get("success"):
                            st.success(f"✅ {result.get('message')}")
                            st.info(f"文件ID: {result.get('file_id')}")

                            st.info("⏳ 文档正在后台解析中，请稍后到'文档管理'页面查看进度")
                        else:
                            st.error(f"❌ 上传失败: {result.get('message', '未知错误')}")

    elif page == "📚 文档管理":
        st.header("文档管理")

        col1, col2, col3 = st.columns(3)
        with col1:
            status_filter = st.selectbox(
                "状态筛选",
                [None, "uploading", "processing", "completed", "failed"],
                format_func=lambda x: "全部" if x is None else x
            )
        with col2:
            page_num = st.number_input("页码", min_value=1, value=1, step=1)
        with col3:
            page_size = st.selectbox("每页数量", [10, 20, 50], index=0)

        with st.spinner("加载中..."):
            result = get_documents(status=status_filter, page=page_num, page_size=page_size)

        if result.get("success"):
            st.info(f"共 {result.get('total', 0)} 个文档")

            documents = result.get("documents", [])
            if documents:
                for doc in documents:
                    with st.expander(f"📄 {doc['filename']}", expanded=False):
                        col1, col2, col3 = st.columns([2, 1, 1])
                        with col1:
                            st.write(f"**状态**: {doc['filestate']}")
                            st.write(f"**大小**: {doc.get('file_size', 0) / 1024 / 1024:.2f} MB")
                            st.write(f"**分块数**: {doc.get('chunk_count', 0)}")
                            st.write(f"**上传时间**: {doc.get('created_at', 'N/A')}")

                        with col2:
                            st.write(f"**文件ID**: {doc['id']}")

                        with col3:
                            if st.button("🗑️ 删除", key=f"delete_{doc['id']}"):
                                delete_result = delete_document(doc['id'])
                                if delete_result.get("success"):
                                    st.success("删除成功")
                                    st.rerun()
                                else:
                                    st.error(f"删除失败: {delete_result.get('message', '未知错误')}")

                        if doc.get("error_message"):
                            st.error(f"错误信息: {doc['error_message']}")
            else:
                st.info("暂无文档，请先上传文档")
        else:
            st.error(f"加载失败: {result.get('message', '未知错误')}")

    elif page == "💬 智能问答":
        st.header("智能问答")
        st.markdown("基于已上传的文档，智能回答您的问题")

        if "messages" not in st.session_state:
            st.session_state.messages = []

        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                if message["role"] == "assistant":
                    render_markdown_with_images(message["content"])
                else:
                    st.markdown(message["content"])

        question = st.chat_input(
            "请输入您的问题...",
            key="chat_input"
        )

        if question:
            st.session_state.messages.append({"role": "user", "content": question})
            with st.chat_message("user"):
                st.markdown(question)

            with st.chat_message("assistant"):
                with st.spinner("思考中..."):
                    result = chat(question)

                    if result.get("success", True):
                        answer = result.get("answer", "")
                        sources = result.get("sources", [])

                        render_markdown_with_images(answer)

                        if sources:
                            with st.expander("📚 参考来源", expanded=False):
                                for idx, source in enumerate(sources, 1):
                                    st.write(f"**来源 {idx}**: {source.get('file_name', '未知')}")
                                    if source.get("page"):
                                        st.write(f"页码: {source['page']}")
                                    st.write(f"相似度: {source.get('score', 0):.2%}")
                                    st.write(f"内容: {source.get('content', '')[:200]}...")
                                    st.divider()

                        st.session_state.messages.append({"role": "assistant", "content": answer})
                    else:
                        error_msg = result.get("message", "未知错误")
                        st.error(f"❌ 问答生成失败: {error_msg}")
                        st.info("请确保文档已解析完成（状态为completed）")

        if st.button("🗑️ 清空对话"):
            st.session_state.messages = []
            st.rerun()


if __name__ == "__main__":
    main()
