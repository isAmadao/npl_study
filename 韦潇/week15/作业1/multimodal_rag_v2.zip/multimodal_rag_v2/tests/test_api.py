import unittest
from fastapi.testclient import TestClient
from main import app


class TestAPIEndpoints(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_health_endpoint(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data["success"])
        self.assertEqual(data["message"], "系统运行正常")

    def test_root_endpoint(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("message", data)
        self.assertIn("version", data)

    def test_upload_document_requires_file(self):
        response = self.client.post("/upload/document")
        self.assertNotEqual(response.status_code, 200)

    def test_upload_document_validates_type(self):
        from io import BytesIO
        response = self.client.post(
            "/upload/document",
            files={"file": ("test.txt", BytesIO(b"test content"), "text/plain")}
        )
        self.assertEqual(response.status_code, 400)

    @patch('app.api.upload.send_parse_task')
    @patch('app.core.database.Session')
    def test_upload_document_success(self, mock_session, mock_kafka):
        from io import BytesIO
        import os

        with patch('os.makedirs'), \
             patch('builtins.open', MagicMock()), \
             patch.object(mock_session, 'add'), \
             patch.object(mock_session, 'commit'), \
             patch.object(mock_session, 'refresh'):

            mock_record = Mock()
            mock_record.id = 1
            mock_record.filename = "test.pdf"
            mock_session.query.return_value.filter.return_value.first.return_value = None
            mock_session.query.return_value.filter.return_value.first.side_effect = [None, mock_record]

            response = self.client.post(
                "/upload/document",
                files={"file": ("test.pdf", BytesIO(b"PDF content"), "application/pdf")}
            )

    def test_list_documents(self):
        response = self.client.get("/documents")
        self.assertEqual(response.status_code, 200)

    def test_list_documents_with_pagination(self):
        response = self.client.get("/documents?page=1&page_size=10")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("total", data)
        self.assertIn("documents", data)

    def test_chat_endpoint_requires_question(self):
        response = self.client.post("/chat", json={})
        self.assertNotEqual(response.status_code, 200)

    @patch('app.api.chat.RetrieverService')
    @patch('app.api.chat.QAChainService')
    def test_chat_endpoint_success(self, mock_qa, mock_retriever):
        mock_retriever_instance = Mock()
        mock_retriever.return_value = mock_retriever_instance
        mock_retriever_instance.search.return_value = [
            {
                "text": "测试内容",
                "file_name": "test.pdf",
                "score": 0.95
            }
        ]

        mock_qa_instance = Mock()
        mock_qa.return_value = mock_qa_instance
        mock_qa_instance.generate.return_value = "这是测试答案"

        response = self.client.post("/chat", json={
            "question": "测试问题",
            "top_k": 5
        })

        self.assertIn(response.status_code, [200, 500])


class TestDocumentManagement(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_get_nonexistent_document(self):
        response = self.client.get("/documents/999999")
        self.assertEqual(response.status_code, 200)

    def test_delete_nonexistent_document(self):
        response = self.client.delete("/documents/999999")
        self.assertEqual(response.status_code, 200)


if __name__ == '__main__':
    unittest.main()
