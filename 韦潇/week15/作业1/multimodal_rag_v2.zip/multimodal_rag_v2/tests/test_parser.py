import unittest
import os
import tempfile
from app.services.parser import TextChunkService


class TestTextChunkService(unittest.TestCase):
    def setUp(self):
        self.chunker = TextChunkService(chunk_size=256, overlap=50)

    def test_split_empty_lines(self):
        lines = ["", "   ", "\n"]
        result = self.chunker.split_text(lines)
        self.assertEqual(len(result), 0)

    def test_split_normal_text(self):
        lines = ["这是第一句话。", "这是第二句话。", "这是第三句话。"]
        result = self.chunker.split_text(lines)
        self.assertGreater(len(result), 0)
        self.assertIsInstance(result[0], str)

    def test_skip_references(self):
        lines = ["# Introduction", "# References", "# More content"]
        result = self.chunker.split_text(lines)
        for chunk in result:
            self.assertNotIn("# References", chunk)

    def test_skip_citations(self):
        lines = ["[1] Author Name", "Normal text", "[2] Another citation"]
        result = self.chunker.split_text(lines)
        for chunk in result:
            self.assertFalse(chunk.startswith("[1]"))
            self.assertFalse(chunk.startswith("[2]"))

    def test_merge_short_chunks(self):
        lines = ["短", "文本", "合并"]
        result = self.chunker.split_text(lines)
        if len(result) > 0:
            self.assertIn("\n", result[0])

    def test_chunk_size_limit(self):
        lines = ["A" * 300] * 5
        result = self.chunker.split_text(lines)
        for chunk in result:
            if len(chunk) > 256:
                continue
            else:
                self.assertLessEqual(len(chunk), 256)

    def test_markdown_file_splitting(self):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False, encoding='utf-8') as f:
            f.write("# 标题1\n")
            f.write("内容1\n")
            f.write("# 标题2\n")
            f.write("内容2\n")
            temp_path = f.name

        try:
            chunks = self.chunker.split_markdown_file(temp_path)
            self.assertGreater(len(chunks), 0)
            for chunk in chunks:
                self.assertIn("content", chunk)
                self.assertIn("chunk_index", chunk)
        finally:
            os.unlink(temp_path)


if __name__ == '__main__':
    unittest.main()
