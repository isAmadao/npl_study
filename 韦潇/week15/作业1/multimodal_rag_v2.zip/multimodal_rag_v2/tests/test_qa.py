import unittest
from unittest.mock import Mock, patch
from app.services.qa_chain import QAChainService
from app.core.models import SourceItem


class TestQAChainService(unittest.TestCase):
    def setUp(self):
        self.qa_chain = QAChainService()

    def test_format_context_single_source(self):
        sources = [
            SourceItem(
                content="这是测试内容",
                file_name="test.pdf",
                page=1,
                score=0.95
            )
        ]
        context = self.qa_chain._format_context(sources)
        self.assertIn("test.pdf", context)
        self.assertIn("这是测试内容", context)
        self.assertIn("页码: 1", context)

    def test_format_context_multiple_sources(self):
        sources = [
            SourceItem(content="内容1", file_name="doc1.pdf", page=1, score=0.9),
            SourceItem(content="内容2", file_name="doc2.pdf", page=2, score=0.85),
        ]
        context = self.qa_chain._format_context(sources)
        self.assertIn("doc1.pdf", context)
        self.assertIn("doc2.pdf", context)
        self.assertIn("---", context)

    def test_build_prompt_includes_question(self):
        question = "什么是多模态？"
        context = "多模态是指..."
        prompt = self.qa_chain._build_prompt(question, context)
        self.assertIn(question, prompt)
        self.assertIn("回答要求", prompt)

    @patch('app.services.qa_chain.OpenAI')
    def test_generate_returns_string(self, mock_openai_class):
        mock_client = Mock()
        mock_openai_class.return_value = mock_client
        mock_response = Mock()
        mock_response.choices = [Mock(message=Mock(content="这是一个测试答案"))]
        mock_client.chat.completions.create.return_value = mock_response

        qa_chain = QAChainService()
        qa_chain.client = mock_client

        sources = [SourceItem(content="测试", file_name="test.pdf", score=0.9)]
        answer = qa_chain.generate("测试问题", sources)

        self.assertIsInstance(answer, str)

    def test_generate_requires_context(self):
        sources = []
        with self.assertRaises(Exception):
            self.qa_chain.generate("问题", sources)


class TestAnswerQuality(unittest.TestCase):
    def setUp(self):
        self.qa_chain = QAChainService()

    def test_answer_relevance(self):
        pass

    def test_source_attribution(self):
        pass

    def test_image_reference_handling(self):
        sources = [
            SourceItem(
                content="![chart](images/chart.png)\n图表显示销售增长",
                file_name="report.pdf",
                page=5,
                score=0.9
            )
        ]
        context = self.qa_chain._format_context(sources)
        self.assertIn("![chart](images/chart.png)", context)


if __name__ == '__main__':
    unittest.main()
