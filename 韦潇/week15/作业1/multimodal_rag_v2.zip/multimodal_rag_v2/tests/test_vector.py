import unittest
import numpy as np
from unittest.mock import Mock, patch
from app.services.vector_store import VectorStoreService


class TestVectorStoreService(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.vector_store = VectorStoreService()

    def test_encode_text_returns_list(self):
        text = "这是一个测试文本"
        result = self.vector_store.encode_text(text)
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 512)

    def test_encode_text_normalizes_embedding(self):
        text = "测试文本"
        result = self.vector_store.encode_text(text)
        norm = np.linalg.norm(result)
        self.assertAlmostEqual(norm, 1.0, places=5)

    def test_encode_text_handles_markdown_images(self):
        text = "文本内容\n![image](images/test.png)\n更多内容"
        result = self.vector_store.encode_text(text)
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 512)

    def test_encode_multimodal_returns_all_vectors(self):
        text = "测试文本\n![image](test.png)"
        result = self.vector_store.encode_multimodal(text, "/fake/path.md")
        self.assertIn("text_vector", result)
        self.assertIn("clip_text_vector", result)
        self.assertIn("clip_image_vector", result)

    def test_encode_multimodal_vector_dimensions(self):
        text = "测试"
        result = self.vector_store.encode_multimodal(text, "/fake/path.md")
        self.assertEqual(len(result["text_vector"]), 512)
        self.assertEqual(len(result["clip_text_vector"]), 1024)
        self.assertEqual(len(result["clip_image_vector"]), 1024)

    def test_encode_text_empty_string(self):
        text = ""
        result = self.vector_store.encode_text(text)
        self.assertIsInstance(result, list)

    @patch('app.services.vector_store.MilvusClient')
    def test_insert_calls_client(self, mock_client_class):
        mock_client = Mock()
        mock_client_class.return_value = mock_client

        with patch.object(self.vector_store, 'encode_multimodal') as mock_encode:
            mock_encode.return_value = {
                "text_vector": [0.1] * 512,
                "clip_text_vector": [0.1] * 1024,
                "clip_image_vector": [0.1] * 1024
            }

            with patch.object(self.vector_store.client, 'insert') as mock_insert:
                mock_insert.return_value = {"insert_count": 1}

                self.vector_store.insert(
                    file_id=1,
                    file_name="test.pdf",
                    file_path="/path/test.pdf",
                    text="测试内容",
                    page_num=1,
                    chunk_index=0
                )

                mock_insert.assert_called_once()

    def test_get_collection_stats(self):
        stats = self.vector_store.get_collection_stats()
        self.assertIsInstance(stats, int)
        self.assertGreaterEqual(stats, 0)


class TestVectorSearch(unittest.TestCase):
    def setUp(self):
        self.vector_store = VectorStoreService()
        self.query_vector = [0.1] * 512

    @patch('app.services.vector_store.MilvusClient')
    def test_search_returns_list(self, mock_client_class):
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        mock_client.search.return_value = [
            [
                {
                    "id": 1,
                    "entity": {
                        "text": "测试文本",
                        "db_id": 1,
                        "file_name": "test.pdf",
                        "file_path": "/path/test.pdf",
                        "page_num": 1,
                        "chunk_index": 0
                    },
                    "distance": 0.95
                }
            ]
        ]

        with patch.object(self.vector_store, 'client', mock_client):
            results = self.vector_store.search(
                query_vector=self.query_vector,
                top_k=5
            )

        self.assertIsInstance(results, list)
        if len(results) > 0:
            self.assertIn("text", results[0])
            self.assertIn("score", results[0])

    def test_search_with_file_id_filter(self):
        pass


if __name__ == '__main__':
    unittest.main()
