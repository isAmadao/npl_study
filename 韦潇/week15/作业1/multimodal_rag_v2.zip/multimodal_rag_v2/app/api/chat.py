from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from app.core.models import ChatRequest, ChatResponse, SourceItem, ImageItem, ErrorResponse
from app.services.retriever import RetrieverService
from app.services.qa_chain import QAChainService
import json

router = APIRouter(prefix="/chat", tags=["问答"])


@router.post("", response_model=ChatResponse)
async def chat(request: ChatRequest):
    try:
        retriever = RetrieverService()
        qa_chain = QAChainService()

        search_results = retriever.search(
            query=request.question,
            top_k=request.top_k,
            file_id=request.knowledge_base_id
        )

        sources = [
            SourceItem(
                content=result["text"],
                file_name=result["file_name"],
                page=result.get("page_num"),
                score=result["score"],
                file_path=result.get("file_path")
            )
            for result in search_results
        ]

        images = []
        for result in search_results:
            if result.get("images"):
                for img in result["images"]:
                    images.append(ImageItem(
                        url=img["url"],
                        description=img.get("description")
                    ))

        answer = qa_chain.generate(
            question=request.question,
            context=sources
        )

        return ChatResponse(
            answer=answer,
            sources=sources,
            images=images
        )
    except Exception as e:
        return ErrorResponse(
            success=False,
            error_code="ERR_QA_FAILED",
            message=f"问答生成失败: {str(e)}"
        )


@router.post("/stream")
async def chat_stream(request: ChatRequest):
    async def event_generator():
        try:
            retriever = RetrieverService()
            qa_chain = QAChainService()

            search_results = retriever.search(
                query=request.question,
                top_k=request.top_k,
                file_id=request.knowledge_base_id
            )

            sources = [
                SourceItem(
                    content=result["text"],
                    file_name=result["file_name"],
                    page=result.get("page_num"),
                    score=result["score"]
                )
                for result in search_results
            ]

            async for chunk in qa_chain.generate_stream(
                question=request.question,
                context=sources
            ):
                yield f"data: {json.dumps({'content': chunk})}\n\n"

            yield f"data: {json.dumps({'sources': [s.model_dump() for s in sources], 'done': True})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream"
    )
