import os
import uuid
from fastapi import APIRouter, UploadFile, File, HTTPException
from app.core.models import UploadResponse, SuccessResponse, ErrorResponse
from app.core.database import Session, File as FileModel
from app.core.config import config
from app.services.kafka_producer import send_parse_task

router = APIRouter(prefix="/upload", tags=["文档上传"])


@router.post("/document", response_model=UploadResponse)
async def upload_document(file: UploadFile = File(...)):
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(
            status_code=400,
            detail={
                "success": False,
                "error_code": "ERR_FILE_TYPE_INVALID",
                "message": "只支持PDF文件上传"
            }
        )

    file_content = await file.read()
    file_size = len(file_content)

    if file_size > config.storage.max_file_size:
        raise HTTPException(
            status_code=400,
            detail={
                "success": False,
                "error_code": "ERR_FILE_SIZE_EXCEED",
                "message": f"文件大小超过限制（{config.storage.max_file_size // 1024 // 1024}MB）"
            }
        )

    os.makedirs(config.storage.upload_dir, exist_ok=True)
    file_extension = os.path.splitext(file.filename)[1]
    save_name = str(uuid.uuid4())
    save_path = os.path.join(config.storage.upload_dir, save_name + file_extension)

    with open(save_path, "wb") as f:
        f.write(file_content)

    session = Session()
    try:
        file_record = FileModel(
            filename=file.filename,
            filepath=save_path,
            filestate="uploading",
            file_size=file_size
        )
        session.add(file_record)
        session.commit()
        session.refresh(file_record)

        send_parse_task(
            file_name=file.filename,
            file_path=save_path,
            file_id=file_record.id
        )

        return UploadResponse(
            success=True,
            file_id=file_record.id,
            filename=file.filename,
            message="文件上传成功，正在解析中..."
        )
    except Exception as e:
        session.rollback()
        if os.path.exists(save_path):
            os.remove(save_path)
        raise HTTPException(
            status_code=500,
            detail={
                "success": False,
                "error_code": "ERR_UPLOAD_FAILED",
                "message": f"文件上传失败: {str(e)}"
            }
        )
    finally:
        session.close()
