from app.api.upload import router as upload_router
from app.api.document import router as document_router
from app.api.chat import router as chat_router
from app.api.admin import router as admin_router

__all__ = ['upload_router', 'document_router', 'chat_router', 'admin_router']
