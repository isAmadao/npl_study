from fastapi import APIRouter, Query
from typing import Optional
from app.core.models import DocumentListResponse, FileResponse, SuccessResponse, ErrorResponse
from app.core.database import Session, File as FileModel

router = APIRouter(prefix="/documents", tags=["文档管理"])


@router.get("", response_model=DocumentListResponse)
async def list_documents(
    status: Optional[str] = Query(None, description="过滤状态"),
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(10, ge=1, le=100, description="每页数量")
):
    session = Session()
    try:
        query = session.query(FileModel)

        if status:
            query = query.filter(FileModel.filestate == status)

        total = query.count()
        offset = (page - 1) * page_size
        documents = query.order_by(FileModel.created_at.desc()).offset(offset).limit(page_size).all()

        return DocumentListResponse(
            total=total,
            page=page,
            page_size=page_size,
            documents=[FileResponse.model_validate(doc) for doc in documents]
        )
    finally:
        session.close()


@router.get("/{file_id}", response_model=FileResponse)
async def get_document(file_id: int):
    session = Session()
    try:
        document = session.query(FileModel).filter(FileModel.id == file_id).first()
        if not document:
            return ErrorResponse(
                success=False,
                error_code="ERR_FILE_NOT_FOUND",
                message="文档不存在"
            )
        return FileResponse.model_validate(document)
    finally:
        session.close()


@router.delete("/{file_id}", response_model=SuccessResponse)
async def delete_document(file_id: int):
    from app.services.vector_store import VectorStoreService
    import os

    session = Session()
    try:
        document = session.query(FileModel).filter(FileModel.id == file_id).first()
        if not document:
            return ErrorResponse(
                success=False,
                error_code="ERR_FILE_NOT_FOUND",
                message="文档不存在"
            )

        if os.path.exists(document.filepath):
            os.remove(document.filepath)

        vector_store = VectorStoreService()
        vector_store.delete_by_file_id(file_id)

        session.delete(document)
        session.commit()

        return SuccessResponse(
            success=True,
            message="文档删除成功"
        )
    except Exception as e:
        session.rollback()
        return ErrorResponse(
            success=False,
            error_code="ERR_DB_OPERATION",
            message=f"删除失败: {str(e)}"
        )
    finally:
        session.close()
