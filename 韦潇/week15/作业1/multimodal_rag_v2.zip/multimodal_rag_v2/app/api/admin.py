from fastapi import APIRouter
from app.core.models import SuccessResponse

router = APIRouter(prefix="/health", tags=["系统"])


@router.get("")
async def health_check():
    return SuccessResponse(
        success=True,
        message="系统运行正常",
        data={
            "status": "healthy",
            "version": "1.0.0"
        }
    )


@router.get("/stats")
async def get_stats():
    from app.core.database import Session, File as FileModel
    from app.services.vector_store import VectorStoreService

    session = Session()
    try:
        total_docs = session.query(FileModel).count()
        completed_docs = session.query(FileModel).filter(FileModel.filestate == "completed").count()
        processing_docs = session.query(FileModel).filter(FileModel.filestate.in_(["uploading", "processing"])).count()
        failed_docs = session.query(FileModel).filter(FileModel.filestate == "failed").count()

        vector_store = VectorStoreService()
        total_chunks = vector_store.get_collection_stats()

        return SuccessResponse(
            success=True,
            message="统计信息获取成功",
            data={
                "documents": {
                    "total": total_docs,
                    "completed": completed_docs,
                    "processing": processing_docs,
                    "failed": failed_docs
                },
                "vectors": {
                    "total_chunks": total_chunks
                }
            }
        )
    finally:
        session.close()
