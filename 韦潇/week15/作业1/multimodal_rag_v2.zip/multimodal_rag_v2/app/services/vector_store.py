import os
import numpy as np
from typing import List, Dict, Optional
from pymilvus import MilvusClient
from sentence_transformers import SentenceTransformer
from app.core.config import config


class VectorStoreService:
    _instance = None
    _bge_model = None
    _clip_model = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if self._bge_model is None:
            os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
            self._bge_model = SentenceTransformer(config.models.bge_model)
            print("BGE model loaded")

        if self._clip_model is None:
            os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
            self._clip_model = SentenceTransformer(
                config.models.clip_model,
                trust_remote_code=True,
                truncate_dim=1024
            )
            print("CLIP model loaded")

        self.client = MilvusClient(
            uri=config.milvus.uri,
            token=config.milvus.token
        )
        self.collection_name = config.milvus.collection_name

    def encode_text(self, text: str) -> List[float]:
        text_clean = "\n".join([line for line in text.split("\n") if not line.startswith("![]")])
        embedding = self._bge_model.encode(text_clean, normalize_embeddings=True)
        return list(embedding)

    def encode_image(self, image_path: str) -> List[float]:
        embedding = self._clip_model.encode(image_path, normalize_embeddings=True)
        return list(embedding)

    def encode_multimodal(self, text: str, markdown_path: str) -> Dict[str, List[float]]:
        text_with_no_image = "\n".join([line for line in text.split("\n") if not line.startswith("![]")])
        text_with_image = [line for line in text.split("\n") if line.startswith("![]")]

        text_bge_embedding = self.encode_text(text_with_no_image)

        if text_with_no_image:
            text_clip_embedding = self._clip_model.encode(text_with_no_image, normalize_embeddings=True)
            text_clip_embedding = list(text_clip_embedding)
        else:
            text_clip_embedding = [0.0] * 1024

        if len(text_with_image) > 0:
            try:
                image_path_in_text = text_with_image[0].split("](")[1].split(")")[0]
                image_real_path = os.path.join(
                    os.path.dirname(markdown_path),
                    image_path_in_text.split("/")[-1]
                )
                if os.path.exists(image_real_path):
                    image_clip_embedding = self.encode_image(image_real_path)
                else:
                    image_clip_embedding = [0.0] * 1024
            except Exception:
                image_clip_embedding = [0.0] * 1024
        else:
            image_clip_embedding = [0.0] * 1024

        return {
            "text_vector": text_bge_embedding,
            "clip_text_vector": text_clip_embedding,
            "clip_image_vector": image_clip_embedding
        }

    def insert(self, file_id: int, file_name: str, file_path: str,
               text: str, page_num: Optional[int] = None, chunk_index: Optional[int] = None):
        markdown_path = file_path
        vectors = self.encode_multimodal(text, markdown_path)

        data = [
            {
                "text_vector": vectors["text_vector"],
                "clip_text_vector": vectors["clip_text_vector"],
                "clip_image_vector": vectors["clip_image_vector"],
                "text": text,
                "db_id": file_id,
                "file_name": file_name,
                "file_path": file_path,
                "page_num": page_num or 0,
                "chunk_index": chunk_index or 0
            }
        ]

        result = self.client.insert(
            collection_name=self.collection_name,
            data=data
        )

        return result

    def search(self, query_vector: List[float], top_k: int = 5,
               file_id: Optional[int] = None) -> List[Dict]:
        filter_expr = None
        if file_id is not None:
            filter_expr = f"db_id == {file_id}"

        results = self.client.search(
            collection_name=self.collection_name,
            data=[query_vector],
            limit=top_k,
            anns_field="text_vector",
            filter=filter_expr,
            output_fields=["text", "db_id", "file_name", "file_path", "page_num", "chunk_index"]
        )

        return [
            {
                "id": hit["id"],
                "text": hit["entity"]["text"],
                "file_name": hit["entity"]["file_name"],
                "file_path": hit["entity"]["file_path"],
                "page_num": hit["entity"].get("page_num"),
                "chunk_index": hit["entity"].get("chunk_index"),
                "score": hit["distance"]
            }
            for hit in results[0]
        ]

    def delete_by_file_id(self, file_id: int):
        self.client.delete(
            collection_name=self.collection_name,
            filter=f"db_id == {file_id}"
        )

    def get_collection_stats(self) -> int:
        try:
            stats = self.client.get_collection_stats(collection_name=self.collection_name)
            return stats.get("row_count", 0)
        except Exception:
            return 0
