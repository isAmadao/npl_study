import os
import subprocess
import glob
from typing import List, Dict
from app.core.config import config


class PDFParserService:
    def __init__(self):
        self.output_dir = config.storage.processed_dir
        self.mineru_command = config.mineru.command
        self.mineru_url = config.mineru.url
        self.backend = config.mineru.backend

    def parse_pdf(self, file_path: str) -> Dict[str, any]:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")

        os.makedirs(self.output_dir, exist_ok=True)

        file_name = os.path.basename(file_path)
        file_base_name = file_name.split(".")[0]

        try:
            cmd = (
                f"{self.mineru_command} -p {file_path} "
                f"-o {self.output_dir} "
                f"-b {self.backend} "
                f"-u {self.mineru_url}"
            )

            result = subprocess.check_output(
                cmd,
                shell=True,
                timeout=600,
                stderr=subprocess.STDOUT
            )

            markdown_dir = os.path.join(self.output_dir, file_base_name)
            markdown_files = glob.glob(os.path.join(markdown_dir, "**", "*.md"), recursive=True)

            if not markdown_files:
                raise Exception("MinerU解析失败，未生成Markdown文件")

            return {
                "success": True,
                "markdown_files": markdown_files,
                "output_dir": markdown_dir,
                "file_base_name": file_base_name
            }

        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "解析超时（超过10分钟）"
            }
        except subprocess.CalledProcessError as e:
            return {
                "success": False,
                "error": f"MinerU执行失败: {e.output.decode('utf-8', errors='ignore')}"
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }

    def extract_images(self, markdown_dir: str) -> List[str]:
        image_files = glob.glob(os.path.join(markdown_dir, "**", "*.png"), recursive=True)
        image_files.extend(glob.glob(os.path.join(markdown_dir, "**", "*.jpg"), recursive=True))
        image_files.extend(glob.glob(os.path.join(markdown_dir, "**", "*.jpeg"), recursive=True))
        return image_files


class TextChunkService:
    def __init__(self, chunk_size: int = 256, overlap: int = 50):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def split_text(self, lines: List[str]) -> List[str]:
        chunks = []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            if line == "# References":
                continue
            if len(line) > 2:
                if line[0] == "[" and line[1].isdigit():
                    continue

            if len(chunks) == 0:
                chunks.append(line)
            else:
                if len(chunks[-1]) <= self.chunk_size:
                    chunks[-1] += "\n" + line
                else:
                    chunks.append(line)

        return chunks

    def split_markdown_file(self, markdown_path: str) -> List[Dict]:
        lines = open(markdown_path, 'r', encoding='utf-8').readlines()
        chunks = self.split_text(lines)

        return [
            {
                "content": chunk,
                "chunk_index": idx
            }
            for idx, chunk in enumerate(chunks)
        ]
