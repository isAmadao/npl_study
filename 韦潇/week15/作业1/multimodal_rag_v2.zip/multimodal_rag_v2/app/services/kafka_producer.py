from kafka import KafkaProducer
from app.core.config import config
import json

producer = None


def get_kafka_producer():
    global producer
    if producer is None:
        producer = KafkaProducer(
            bootstrap_servers=config.kafka.bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode('utf-8')
        )
    return producer


def send_parse_task(file_name: str, file_path: str, file_id: int):
    producer = get_kafka_producer()
    producer.send(
        config.kafka.topic,
        value={
            "file_name": file_name,
            "file_path": file_path,
            "id": file_id
        }
    )
    producer.flush()
