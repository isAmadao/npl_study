from typing import List, Dict, Optional
from app.services.vector_store import VectorStoreService
from app.core.models import SourceItem
import os


class RetrieverService:
    def __init__(self):
        self.vector_store = VectorStoreService()

    def search(self, query: str, top_k: int = 5, file_id: Optional[int] = None) -> List[Dict]:
        query_vector = self.vector_store.encode_text(query)

        results = self.vector_store.search(
            query_vector=query_vector,
            top_k=top_k,
            file_id=file_id
        )

        for result in results:
            file_dir = os.path.basename(result["file_path"]).split(".")[0]
            if "images/" in result["text"]:
                result["text"] = result["text"].replace(
                    "images/",
                    f"./processed/{file_dir}/vlm/images/"
                )

            if "file_path" in result and os.path.exists(result["file_path"]):
                processed_dir = os.path.join(
                    os.path.dirname(result["file_path"]),
                    os.path.basename(result["file_path"]).split(".")[0]
                )
                if os.path.exists(processed_dir):
                    result["images"] = self._extract_images_from_dir(processed_dir, result["text"])

        return results

    def _extract_images_from_dir(self, dir_path: str, text: str) -> List[Dict]:
        import glob
        images = []

        if "![](" in text:
            image_refs = [line for line in text.split("\n") if line.startswith("![](")]
            for ref in image_refs:
                try:
                    image_name = ref.split("](")[1].split(")")[0].split("/")[-1]
                    image_path = os.path.join(dir_path, "vlm", "images", image_name)
                    if os.path.exists(image_path):
                        images.append({
                            "url": image_path,
                            "description": f"相关图片: {image_name}"
                        })
                except Exception:
                    continue

        return images

    def search_with_rerank(self, query: str, top_k: int = 5, file_id: Optional[int] = None) -> List[Dict]:
        initial_results = self.search(query, top_k * 2, file_id)

        reranked = sorted(
            initial_results,
            key=lambda x: x["score"],
            reverse=True
        )

        return reranked[:top_k]
