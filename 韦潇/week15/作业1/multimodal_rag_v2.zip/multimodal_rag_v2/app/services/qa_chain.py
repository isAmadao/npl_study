from typing import List, AsyncGenerator
from openai import OpenAI
from app.core.config import config
from app.core.models import SourceItem
import asyncio


class QAChainService:
    def __init__(self):
        self.client = OpenAI(
            api_key=config.models.qwen_api_key,
            base_url=config.models.qwen_base_url
        )
        self.model = config.models.qwen_model

    def generate(self, question: str, context: List[SourceItem]) -> str:
        context_text = self._format_context(context)

        prompt = self._build_prompt(question, context_text)

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {'role': 'system', 'content': 'You are a helpful assistant.'},
                {'role': 'user', 'content': prompt}
            ],
            temperature=0.7,
            max_tokens=2000
        )

        return response.choices[0].message.content

    async def generate_stream(self, question: str, context: List[SourceItem]) -> AsyncGenerator[str, None]:
        context_text = self._format_context(context)
        prompt = self._build_prompt(question, context_text)

        response = await asyncio.to_thread(
            self.client.chat.completions.create,
            model=self.model,
            messages=[
                {'role': 'system', 'content': 'You are a helpful assistant.'},
                {'role': 'user', 'content': prompt}
            ],
            temperature=0.7,
            max_tokens=2000,
            stream=True
        )

        for chunk in response:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content

    def _format_context(self, context: List[SourceItem]) -> str:
        context_parts = []
        for idx, item in enumerate(context, 1):
            part = f"[文档 {idx}]\n"
            part += f"文件名: {item.file_name}\n"
            if item.page:
                part += f"页码: {item.page}\n"
            part += f"内容: {item.content}\n"
            context_parts.append(part)

        return "\n---\n".join(context_parts)

    def _build_prompt(self, question: str, context: str) -> str:
        prompt = f"""基于以下资料回答问题。

问题：{question}

相关资料：
{context}

回答要求：
- 回答要客观、有逻辑，要基于提供的资料。
- 如果资料中包含图片链接，则单独一行进行输出，保留图的原始链接，需要将图放在合适的相关内容的位置。
- 答案应该清晰指出信息来源。
"""
        return prompt
