from pydantic import BaseModel
from typing import Optional, List, Any
from datetime import datetime


class FileResponse(BaseModel):
    id: int
    filename: str
    filestate: str
    file_size: int
    chunk_count: int
    created_at: datetime
    updated_at: datetime
    error_message: Optional[str] = None

    class Config:
        from_attributes = True


class UploadResponse(BaseModel):
    success: bool
    file_id: int
    filename: str
    message: str


class DocumentListResponse(BaseModel):
    total: int
    page: int
    page_size: int
    documents: List[FileResponse]


class SourceItem(BaseModel):
    content: str
    file_name: str
    page: Optional[int] = None
    score: float
    file_path: Optional[str] = None


class ImageItem(BaseModel):
    url: str
    description: Optional[str] = None


class ChatRequest(BaseModel):
    question: str
    knowledge_base_id: Optional[int] = None
    top_k: int = 5
    rerank: bool = False


class ChatResponse(BaseModel):
    answer: str
    sources: List[SourceItem]
    images: List[ImageItem]


class ErrorResponse(BaseModel):
    success: bool = False
    message: str
    error_code: str
    details: Optional[Any] = None


class SuccessResponse(BaseModel):
    success: bool = True
    message: str
    data: Optional[Any] = None
