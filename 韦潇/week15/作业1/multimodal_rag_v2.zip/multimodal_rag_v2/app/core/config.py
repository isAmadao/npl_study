import yaml
import os
from typing import Optional
from pydantic import BaseModel


class AppConfig(BaseModel):
    name: str
    version: str
    debug: bool
    host: str
    port: int


class DatabaseConfig(BaseModel):
    type: str
    path: str


class MilvusConfig(BaseModel):
    uri: str
    token: str
    collection_name: str


class KafkaConfig(BaseModel):
    bootstrap_servers: str
    topic: str
    consumer_group: str


class ModelsConfig(BaseModel):
    bge_model: str
    clip_model: str
    qwen_api_key: str
    qwen_base_url: str
    qwen_model: str


class StorageConfig(BaseModel):
    upload_dir: str
    processed_dir: str
    max_file_size: int


class ChunkConfig(BaseModel):
    chunk_size: int
    overlap: int


class RetrievalConfig(BaseModel):
    top_k: int
    rerank: bool


class MineruConfig(BaseModel):
    command: str
    output_dir: str
    backend: str
    url: str


class Config(BaseModel):
    app: AppConfig
    database: DatabaseConfig
    milvus: MilvusConfig
    kafka: KafkaConfig
    models: ModelsConfig
    storage: StorageConfig
    chunk: ChunkConfig
    retrieval: RetrievalConfig
    mineru: MineruConfig


def load_config(config_path: str = "config.yaml") -> Config:
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"配置文件不存在: {config_path}")

    with open(config_path, 'r', encoding='utf-8') as f:
        config_dict = yaml.safe_load(f)

    return Config(**config_dict)


config = load_config()
