import os
import sys
import glob
from kafka import KafkaConsumer
import json
from app.services.parser import PDFParserService, TextChunkService
from app.services.vector_store import VectorStoreService
from app.core.database import Session, File as FileModel

os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'


class OfflineWorker:
    def __init__(self):
        self.parser = PDFParserService()
        self.chunker = TextChunkService()
        self.vector_store = VectorStoreService()
        self.consumer = KafkaConsumer(
            "rag-data",
            bootstrap_servers="localhost:9092",
            enable_auto_commit=True,
            value_deserializer=lambda v: json.loads(v.decode('utf-8')),
        )

    def process_message(self, message: dict):
        file_name = message['file_name']
        file_path = message['file_path']
        file_id = message['id']

        session = Session()
        try:
            file_record = session.query(FileModel).filter(FileModel.id == file_id).first()
            if not file_record:
                print(f"文件记录不存在: {file_id}")
                return

            file_record.filestate = "processing"
            session.commit()

            print(f"开始解析文件: {file_name}")
            parse_result = self.parser.parse_pdf(file_path)

            if not parse_result["success"]:
                file_record.filestate = "failed"
                file_record.error_message = parse_result.get("error")
                session.commit()
                print(f"解析失败: {parse_result.get('error')}")
                return

            markdown_files = parse_result["markdown_files"]
            if not markdown_files:
                file_record.filestate = "failed"
                file_record.error_message = "未找到Markdown文件"
                session.commit()
                return

            markdown_file = markdown_files[0]
            print(f"解析完成，开始分块: {markdown_file}")
            chunks = self.chunker.split_markdown_file(markdown_file)

            chunk_count = 0
            for chunk_info in chunks:
                try:
                    self.vector_store.insert(
                        file_id=file_id,
                        file_name=file_name,
                        file_path=file_path,
                        text=chunk_info["content"],
                        chunk_index=chunk_info["chunk_index"]
                    )
                    chunk_count += 1
                except Exception as e:
                    print(f"存储chunk失败: {e}")
                    continue

            file_record.filestate = "completed"
            file_record.chunk_count = chunk_count
            session.commit()

            print(f"文件处理完成: {file_name}, chunks: {chunk_count}")

        except Exception as e:
            session.rollback()
            try:
                file_record = session.query(FileModel).filter(FileModel.id == file_id).first()
                if file_record:
                    file_record.filestate = "failed"
                    file_record.error_message = str(e)
                    session.commit()
            except Exception:
                pass
            print(f"处理异常: {e}")
        finally:
            session.close()

    def run(self):
        print("离线处理Worker启动，等待消息...")
        for message in self.consumer:
            try:
                self.process_message(message.value)
            except Exception as e:
                print(f"消息处理异常: {e}")


if __name__ == "__main__":
    worker = OfflineWorker()
    worker.run()
