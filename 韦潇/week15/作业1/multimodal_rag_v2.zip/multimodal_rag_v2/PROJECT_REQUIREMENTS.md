# 多模态RAG聊天机器人 - 项目需求文档

## 1. 项目背景与目标

### 1.1 项目背景
在信息爆炸的时代，大量有价值的信息以图文混排的文档、PDF、网页等形式存在。传统的问答系统基于纯文本，难以处理需要结合图像内容进行推理的复杂问题。

### 1.2 项目目标
构建一个**多模态检索增强生成（Multi-modal RAG）聊天机器人系统**，能够：
- 理解用户提出的自然语言问题
- 从知识库中检索相关的文本和图像
- 综合多模态信息进行推理和回答
- 清晰指出信息来源

### 1.3 核心价值
- **跨模态理解**：同时理解文本和图像内容
- **智能检索**：从海量多模态文档中精准检索相关内容
- **深度推理**：将图文信息关联融合，进行逻辑推理
- **可解释性**：明确标注信息来源，提升答案可信度

---

## 2. 系统架构设计

### 2.1 整体架构
```
┌─────────────────────────────────────────────────────┐
│                    Web UI (Streamlit)               │
│         - 文档上传界面                              │
│         - 聊天问答界面                              │
└─────────────────────────────────────────────────────┘
                         ↓ ↑
┌─────────────────────────────────────────────────────┐
│                  FastAPI Backend                     │
│         - RESTful API 接口                           │
│         - 业务逻辑层                                 │
└─────────────────────────────────────────────────────┘
                         ↓ ↑
        ┌────────────────┼────────────────┐
        ↓                ↓                ↓
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│   Parser     │ │   Vector     │ │   QA Chain   │
│   Service    │ │   Store      │ │   Service    │
└──────────────┘ └──────────────┘ └──────────────┘
        ↓                ↓                ↓
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│ MinerU/OCR   │ │  Milvus      │ │ Qwen-VL      │
│ DeepSeek-OCR│ │  Zilliz Cloud│ │ Qwen-plus    │
└──────────────┘ └──────────────┘ └──────────────┘
```

### 2.2 模块划分

#### 2.2.1 文档解析模块（Parser Service）
- **功能**：将PDF文档解析为文本和图片
- **技术栈**：MinerU / DeepSeek-OCR
- **输出**：Markdown文档 + 图片文件
- **特点**：离线异步处理，耗时较长

#### 2.2.2 多模态向量存储模块（Vector Store）
- **功能**：文本分块、向量编码、向量存储
- **技术栈**：
  - BGE模型：文本向量编码
  - CLIP模型：多模态向量编码
  - Milvus：向量数据库
- **输出**：带向量的结构化数据

#### 2.2.3 多模态检索模块（Retriever）
- **功能**：基于用户问题检索相关文本和图片
- **技术栈**：
  - BGE向量检索：文本相似度
  - CLIP向量检索：跨模态检索
- **输出**：Top-K 相关文档块

#### 2.2.4 问答链模块（QA Chain）
- **功能**：整合检索结果，生成最终答案
- **技术栈**：Qwen-VL / Qwen-plus
- **输出**：包含图片引用的Markdown答案

### 2.3 数据流设计

#### 文档上传流程：
```
用户上传PDF
    ↓
FastAPI接收文件 → 保存到本地
    ↓
插入文件记录到SQLite（状态：上传成功）
    ↓
发送Kafka消息到"rag-data" topic
    ↓
离线Worker消费消息
    ↓
调用MinerU解析PDF → Markdown + 图片
    ↓
文本分块（chunk）
    ↓
使用BGE+CLIP编码 → 向量
    ↓
存储到Milvus（状态：解析完成）
```

#### 问答流程：
```
用户输入问题
    ↓
FastAPI接收问题
    ↓
使用BGE编码问题 → 向量
    ↓
Milvus检索 → Top-K 相关块
    ↓
组装Prompt（文本+图片）
    ↓
调用Qwen-plus生成答案
    ↓
Streamlit渲染Markdown + 图片
    ↓
返回答案给用户
```

---

## 3. 功能需求

### 3.1 文档管理功能

#### 3.1.1 文档上传
- **接口**：`POST /upload/document`
- **参数**：
  - `file`: PDF文件（必填）
  - `knowledge_base_id`: 知识库ID（可选，默认为default）
- **功能**：
  - 文件类型验证（仅支持PDF）
  - 文件大小限制（建议≤50MB）
  - 文件存储（本地路径：`./uploads/{uuid}.pdf`）
  - 元信息写入SQLite
  - Kafka消息发送
- **返回**：
  ```json
  {
    "success": true,
    "file_id": 123,
    "filename": "example.pdf",
    "message": "文件上传成功，正在解析中..."
  }
  ```

#### 3.1.2 文档列表查询
- **接口**：`GET /documents`
- **参数**：
  - `status`: 过滤状态（可选）：uploading, processing, completed, failed
  - `page`: 页码（默认1）
  - `page_size`: 每页数量（默认10）
- **返回**：
  ```json
  {
    "total": 100,
    "page": 1,
    "page_size": 10,
    "documents": [
      {
        "id": 123,
        "filename": "example.pdf",
        "status": "completed",
        "upload_time": "2024-01-01 12:00:00",
        "chunk_count": 50
      }
    ]
  }
  ```

#### 3.1.3 文档删除
- **接口**：`DELETE /documents/{file_id}`
- **功能**：
  - 删除SQLite记录
  - 删除本地文件
  - 删除Milvus中的向量数据
- **返回**：
  ```json
  {
    "success": true,
    "message": "文档删除成功"
  }
  ```

### 3.2 多模态问答功能

#### 3.2.1 问答接口
- **接口**：`POST /chat`
- **参数**：
  - `question`: 用户问题（必填）
  - `knowledge_base_id`: 知识库ID（可选）
  - `top_k`: 返回结果数量（默认5）
  - `rerank`: 是否重排序（默认false）
- **返回**：
  ```json
  {
    "answer": "根据文档描述，图1显示了产品A的销售趋势...",
    "sources": [
      {
        "content": "![](images/fig1.png)\n产品A销售额变化",
        "file_name": "example.pdf",
        "page": 3,
        "score": 0.95
      }
    ],
    "images": [
      {
        "url": "http://example.com/images/fig1.png",
        "description": "图1：产品A销售趋势图"
      }
    ]
  }
  ```

#### 3.2.2 多轮对话
- **接口**：`POST /chat/stream`
- **功能**：支持流式输出，实时显示答案生成过程
- **返回**：Server-Sent Events (SSE) 流

### 3.3 离线处理功能

#### 3.3.1 文档解析Worker
- **功能**：
  - 消费Kafka消息
  - 调用MinerU解析PDF
  - 文本分块（chunk_size=256字符）
  - 向量编码（BGE + CLIP）
  - 存储到Milvus
  - 更新SQLite状态
- **并发控制**：单进程，多线程处理

#### 3.3.2 批量处理接口
- **接口**：`POST /admin/batch-process`
- **功能**：批量重新处理失败的文档

---

## 4. 非功能需求

### 4.1 性能需求
- **文档上传响应时间**：≤ 2秒（不含解析时间）
- **问答响应时间**：≤ 5秒（不含模型调用时间）
- **并发支持**：支持10个并发用户
- **解析吞吐量**：1个文档/分钟（取决于文档大小）

### 4.2 可用性需求
- **系统可用性**：99.9%
- **错误恢复**：支持断点重试
- **日志记录**：完整的操作日志和错误日志

### 4.3 数据需求
- **数据持久化**：SQLite存储元信息，Milvus存储向量
- **数据备份**：定期备份SQLite数据库
- **存储容量**：支持至少1000个PDF文档

### 4.4 安全需求
- **文件上传安全**：文件类型白名单、大小限制
- **API认证**：可选的API Key认证
- **数据隔离**：不同知识库的数据隔离

---

## 5. 技术选型

### 5.1 核心技术栈
| 组件 | 技术选型 | 说明 |
|------|---------|------|
| **编程语言** | Python 3.10+ | 主要开发语言 |
| **Web框架** | FastAPI + Streamlit | API + Web界面 |
| **数据库** | SQLite | 轻量级元数据存储 |
| **向量数据库** | Milvus (Zilliz Cloud) | 向量存储和检索 |
| **消息队列** | Kafka | 异步任务队列 |
| **文档解析** | MinerU / pdfplumber | PDF解析 |
| **文本向量** | BGE-small-zh-v1.5 | 文本编码 |
| **多模态向量** | Jina-CLIP-v2 | 跨模态编码 |
| **大模型** | Qwen-plus / Qwen-VL | 问答生成 |

### 5.2 依赖库
```
fastapi>=0.104.0
uvicorn>=0.24.0
streamlit>=1.28.0
sqlalchemy>=2.0.0
pymilvus>=2.3.0
kafka-python>=2.0.0
pymupdf>=1.23.0
mineru>=0.1.0
sentence-transformers>=2.2.0
openai>=1.0.0
python-multipart>=0.0.6
pydantic>=2.0.0
```

---

## 6. 数据库设计

### 6.1 SQLite表结构

#### files表
```sql
CREATE TABLE files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename VARCHAR(255) NOT NULL,           -- 原始文件名
    filepath VARCHAR(1000) NOT NULL,          -- 存储路径
    filestate VARCHAR(20) NOT NULL,            -- 状态: uploading/processing/completed/failed
    file_size INTEGER,                         -- 文件大小（字节）
    chunk_count INTEGER DEFAULT 0,              -- 分块数量
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    error_message TEXT                          -- 错误信息（如果有）
);
```

### 6.2 Milvus Collection设计

#### Collection: rag_data_new
```python
{
    "fields": [
        {"name": "id", "type": "int64", "is_primary": True},
        {"name": "text", "type": "varchar", "max_length": 65535},
        {"name": "text_vector", "type": "float32", "dim": 512},        # BGE向量
        {"name": "clip_text_vector", "type": "float32", "dim": 1024},  # CLIP文本向量
        {"name": "clip_image_vector", "type": "float32", "dim": 1024}, # CLIP图像向量
        {"name": "db_id", "type": "int64"},                            # 关联文件ID
        {"name": "file_name", "type": "varchar", "max_length": 255},
        {"name": "file_path", "type": "varchar", "max_length": 1000},
        {"name": "page_num", "type": "int32"},                          # 页码
        {"name": "chunk_index", "type": "int32"}                       # 块索引
    ],
    "indexes": [
        {"field": "text_vector", "index_type": "HNSW", "params": {"M": 16, "efConstruction": 200}},
        {"field": "clip_text_vector", "index_type": "HNSW", "params": {"M": 16, "efConstruction": 200}},
        {"field": "clip_image_vector", "index_type": "HNSW", "params": {"M": 16, "efConstruction": 200}}
    ]
}
```

---

## 7. API接口规范

### 7.1 统一响应格式
```python
class ResponseModel(BaseModel):
    success: bool = True
    message: str = "操作成功"
    data: Any = None
    error_code: str = None
```

### 7.2 错误码定义
| 错误码 | 说明 |
|--------|------|
| ERR_FILE_NOT_FOUND | 文件不存在 |
| ERR_FILE_TYPE_INVALID | 文件类型不支持 |
| ERR_FILE_SIZE_EXCEED | 文件大小超限 |
| ERR_UPLOAD_FAILED | 上传失败 |
| ERR_PROCESS_FAILED | 处理失败 |
| ERR_DB_OPERATION | 数据库操作失败 |
| ERR_MODEL_LOAD | 模型加载失败 |
| ERR_QA_FAILED | 问答生成失败 |

### 7.3 接口列表
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /upload/document | 上传文档 |
| GET | /documents | 查询文档列表 |
| GET | /documents/{id} | 查询单个文档 |
| DELETE | /documents/{id} | 删除文档 |
| POST | /chat | 问答接口 |
| POST | /chat/stream | 流式问答 |
| GET | /health | 健康检查 |
| GET | /stats | 统计信息 |

---

## 8. 配置管理

### 8.1 配置文件结构
```yaml
# config.yaml
app:
  name: "Multi-modal RAG Chatbot"
  version: "1.0.0"
  debug: false
  host: "0.0.0.0"
  port: 8000

database:
  type: "sqlite"
  path: "./db.db"

milvus:
  uri: "https://xxx.zillizcloud.com"
  token: "your-token"
  collection_name: "rag_data_new"

kafka:
  bootstrap_servers: "localhost:9092"
  topic: "rag-data"
  consumer_group: "rag-consumer"

models:
  bge_model: "/path/to/bge-small-zh-v1.5"
  clip_model: "/path/to/jina-clip-v2"
  qwen_api_key: "your-api-key"
  qwen_base_url: "https://dashscope.aliyuncs.com/compatible-mode/v1"

storage:
  upload_dir: "./uploads"
  processed_dir: "./processed"
  max_file_size: 52428800  # 50MB

chunk:
  chunk_size: 256
  overlap: 50

retrieval:
  top_k: 5
  rerank: false
```

---

## 9. 测试策略

### 9.1 测试类型

#### 单元测试
- 文档解析模块测试
- 向量编码测试
- 分块算法测试
- API接口测试

#### 集成测试
- 完整流程测试（上传→解析→检索→问答）
- 多模态检索准确性测试
- 并发处理测试

#### 性能测试
- 大文档处理性能
- 高并发问答性能
- 向量检索性能

### 9.2 测试用例示例
```python
# test_parser.py
def test_pdf_parser():
    """测试PDF文档解析功能"""
    # 1. 准备测试PDF
    # 2. 调用解析器
    # 3. 验证输出：Markdown + 图片
    pass

def test_text_chunking():
    """测试文本分块功能"""
    # 1. 准备测试文本
    # 2. 调用分块函数
    # 3. 验证块大小和重叠
    pass

def test_vector_encoding():
    """测试向量编码功能"""
    # 1. 准备测试文本和图片
    # 2. 调用编码器
    # 3. 验证向量维度
    pass

def test_multimodal_retrieval():
    """测试多模态检索功能"""
    # 1. 准备知识库
    # 2. 执行检索
    # 3. 验证返回结果的相关性
    pass

def test_qa_generation():
    """测试问答生成功能"""
    # 1. 准备问题和上下文
    # 2. 调用问答链
    # 3. 验证答案质量
    pass
```

---

## 10. 部署架构

### 10.1 开发环境
- Python 3.10+
- 8GB+ RAM
- GPU: NVIDIA RTX 3060+ (可选，用于本地模型推理)

### 10.2 生产环境建议
- **Web服务**：Uvicorn + FastAPI，单机部署
- **Worker服务**：独立进程，部署在GPU服务器
- **数据库**：SQLite（单机）或 MySQL（分布式）
- **向量数据库**：Zilliz Cloud（托管Milvus）
- **消息队列**：Kafka（单节点或集群）

### 10.3 Docker部署（可选）
```dockerfile
FROM python:3.10-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

---

## 11. 项目目录结构

```
05-multimodal-rag-chatbot/
├── config.yaml                    # 配置文件
├── requirements.txt                # 依赖列表
├── README.md                       # 项目说明
├── main.py                         # FastAPI主程序
├── app/
│   ├── __init__.py
│   ├── api/
│   │   ├── __init__.py
│   │   ├── upload.py              # 上传接口
│   │   ├── chat.py                # 问答接口
│   │   └── admin.py               # 管理接口
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py              # 配置管理
│   │   ├── database.py            # 数据库连接
│   │   └── models.py              # 数据模型
│   ├── services/
│   │   ├── __init__.py
│   │   ├── parser.py              # 文档解析服务
│   │   ├── vector_store.py        # 向量存储服务
│   │   ├── retriever.py           # 检索服务
│   │   └── qa_chain.py            # 问答链服务
│   └── utils/
│       ├── __init__.py
│       ├── file_utils.py          # 文件工具
│       └── text_utils.py          # 文本工具
├── worker/
│   ├── __init__.py
│   └── offline_worker.py          # 离线处理worker
├── web/
│   ├── __init__.py
│   ├── page_upload.py             # Streamlit上传页面
│   ├── page_chat.py               # Streamlit聊天页面
│   └── web_demo.py                # Web演示主程序
├── tests/
│   ├── __init__.py
│   ├── test_parser.py             # 解析模块测试
│   ├── test_vector.py             # 向量模块测试
│   ├── test_retriever.py          # 检索模块测试
│   └── test_qa.py                 # 问答模块测试
├── uploads/                        # 上传文件目录
├── processed/                      # 处理后文件目录
└── db.db                           # SQLite数据库
```

---

## 12. 风险与挑战

### 12.1 技术风险
1. **PDF解析质量**：复杂PDF（表格、多栏）解析可能不完整
2. **向量检索准确性**：多模态向量空间融合的挑战
3. **模型推理成本**：Qwen-VL调用成本较高
4. **长文档处理**：超长文档的分块和检索策略

### 12.2 解决方案
1. **PDF解析**：使用MinerU进行深度解析，结合OCR提升表格识别
2. **检索优化**：采用混合检索策略，结合关键词和向量检索
3. **成本控制**：实施缓存策略，减少重复调用
4. **长文档优化**：采用递归分块 + 层次索引策略

---

## 13. 后续优化方向

### 13.1 功能增强
- 支持更多文档格式（Word、PPT、图片）
- 多知识库管理
- 用户权限管理
- 答案质量评估

### 13.2 性能优化
- 模型量化加速
- 批量推理优化
- 缓存机制优化
- 分布式部署

### 13.3 用户体验
- 对话历史管理
- 答案来源可视化
- 文档预览功能
- 移动端适配

---

**文档版本**：v1.0
**创建日期**：2024年
**维护团队**：AI大模型课程组
